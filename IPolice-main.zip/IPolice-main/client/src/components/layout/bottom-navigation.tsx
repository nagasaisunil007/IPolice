import { Home, FileText, Camera, Gift, User } from "lucide-react";
import { Link, useLocation } from "wouter";

interface BottomNavigationProps {
  onReportClick?: () => void;
  onEvidenceClick?: () => void;
}

export default function BottomNavigation({ onReportClick, onEvidenceClick }: BottomNavigationProps) {
  const [location] = useLocation();

  const navItems = [
    { path: "/dashboard", icon: Home, label: "Home" },
    { path: "/view-reports", icon: FileText, label: "Reports" },
    { path: "/report", icon: Camera, label: "Report", isCenter: true },
    { path: "/rewards", icon: Gift, label: "Rewards" },
    { path: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      <div className="max-w-md mx-auto relative">
        {/* Center button elevated above the nav bar */}
        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 z-10">
          {navItems.filter(item => item.isCenter).map((item) => {
            const Icon = item.icon;
            
            const handleCameraClick = () => {
              if (onReportClick) {
                onReportClick();
              } else if (onEvidenceClick) {
                onEvidenceClick();
              }
            };

            return (
              <button 
                key={item.path}
                onClick={handleCameraClick}
                className="flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 active:scale-95"
                style={{
                  boxShadow: '0 4px 20px rgba(99, 102, 241, 0.3), 0 8px 32px rgba(99, 102, 241, 0.15)'
                }}
              >
                <Icon className="h-6 w-6" />
              </button>
            );
          })}
        </div>
        
        {/* Main navigation bar with smooth curve that encompasses camera button */}
        <div 
          className="bg-white/95 backdrop-blur-sm relative rounded-t-3xl"
          style={{
            boxShadow: '0 -8px 32px rgba(0, 0, 0, 0.1), 0 -4px 16px rgba(0, 0, 0, 0.06), 0 -2px 8px rgba(0, 0, 0, 0.04)'
          }}
        >
          {/* Large semi-circular cutout with soft shadow */}
          <div 
            className="absolute -top-10 left-1/2 transform -translate-x-1/2 w-24 bg-white/95"
            style={{
              height: '72px',
              borderRadius: '48px 48px 0 0',
              boxShadow: '0 -4px 16px rgba(0, 0, 0, 0.08), 0 -2px 8px rgba(0, 0, 0, 0.04)'
            }}
          ></div>
          
          <div className="flex items-center justify-between px-8 py-2 pt-4">
            {navItems.filter(item => !item.isCenter).map((item, index) => {
              const Icon = item.icon;
              const isActive = location === item.path;
              
              // Add extra margin for items adjacent to center button (Reports and Rewards)
              const isAdjacentToCenter = index === 1 || index === 2; // Reports and Rewards positions
              
              return (
                <Link key={item.path} href={item.path}>
                  <button
                    className={`flex flex-col items-center transition-all transform active:scale-95 py-2 rounded-xl ${
                      isAdjacentToCenter ? 'mx-12' : 'mx-2'
                    } ${
                      isActive 
                        ? "text-blue-600" 
                        : "text-gray-400 hover:text-gray-600"
                    }`}
                  >
                    <Icon className="h-6 w-6 mb-1" />
                    <span className="text-xs font-medium">{item.label}</span>
                  </button>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}
