import { Bell, Shield } from "lucide-react";
import { useLocation } from "wouter";

export default function TopHUD() {
  const [, setLocation] = useLocation();

  const handleNotificationClick = () => {
    setLocation('/notifications');
  };

  return (
    <header className="sticky top-0 z-50">
      <div className="max-w-md mx-auto bg-police-blue text-white px-4 py-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span className="text-lg font-semibold">iPolice Bengaluru</span>
          </div>
          <div className="relative">
            <Bell 
              className="h-5 w-5 cursor-pointer hover:text-blue-200 transition-colors" 
              onClick={handleNotificationClick}
            />
            <span className="absolute -top-1 -right-1 bg-error text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              3
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
