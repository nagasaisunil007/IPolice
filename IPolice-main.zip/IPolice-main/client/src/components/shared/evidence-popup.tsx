import React from "react";
import { Button } from "@/components/ui/button";
import { Camera, Image } from "lucide-react";
import { useLocation } from "wouter";

interface EvidencePopupProps {
  isOpen: boolean;
  onClose: () => void;
  onCameraSelect?: () => void;
  onGallerySelect?: () => void;
}

export default function EvidencePopup({ isOpen, onClose, onCameraSelect, onGallerySelect }: EvidencePopupProps) {
  const [, setLocation] = useLocation();
  
  if (!isOpen) return null;

  const handleCameraClick = async () => {
    onClose();
    if (onCameraSelect) {
      onCameraSelect();
    } else {
      // Navigate to report page which will handle camera permission
      setLocation('/report?camera=true');
    }
  };

  const handleGalleryClick = () => {
    onClose();
    if (onGallerySelect) {
      onGallerySelect();
    } else {
      // Create a temporary file input to trigger file picker
      const fileInput = document.createElement('input');
      fileInput.type = 'file';
      fileInput.accept = 'image/*,video/*';
      fileInput.onchange = (event: any) => {
        const file = event.target.files?.[0];
        if (file) {
          // Store file in sessionStorage temporarily and navigate
          const reader = new FileReader();
          reader.onload = (e) => {
            sessionStorage.setItem('selectedFile', JSON.stringify({
              name: file.name,
              type: file.type,
              data: e.target?.result
            }));
            setLocation('/report?gallery=true');
          };
          reader.readAsDataURL(file);
        }
      };
      fileInput.click();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end justify-center"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-md mx-4 bg-white rounded-t-3xl shadow-2xl animate-in slide-in-from-bottom duration-300 ease-out"
        style={{ paddingBottom: 'calc(6rem + env(safe-area-inset-bottom))' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Handle Bar */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-12 h-1.5 bg-gray-300 rounded-full"></div>
        </div>
        
        <div className="px-6 pb-8">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              Add Evidence
            </h3>
            <p className="text-sm text-gray-600">
              Choose how to provide evidence for your report
            </p>
          </div>
          
          <div className="space-y-4">
            <Button
              onClick={handleCameraClick}
              className="w-full h-20 text-lg bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 hover:from-blue-600 hover:via-blue-700 hover:to-indigo-700 text-white flex items-center justify-between px-8 shadow-xl rounded-2xl transform hover:scale-[1.02] transition-all duration-200 border border-blue-400/20"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <Camera className="h-6 w-6 text-white" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">Open Camera</div>
                  <div className="text-xs text-blue-100 opacity-90">Capture live evidence</div>
                </div>
              </div>
              <div className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center">
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </Button>
            
            <Button
              onClick={handleGalleryClick}
              variant="outline"
              className="w-full h-20 text-lg border-2 border-purple-300/40 bg-gradient-to-br from-purple-50 via-purple-100 to-pink-50 hover:from-purple-100 hover:via-purple-150 hover:to-pink-100 text-purple-800 flex items-center justify-between px-8 rounded-2xl transform hover:scale-[1.02] transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-200/60 rounded-full flex items-center justify-center">
                  <Image className="h-6 w-6 text-purple-700" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-purple-800">Open Gallery</div>
                  <div className="text-xs text-purple-600 opacity-80">Select existing photos</div>
                </div>
              </div>
              <div className="w-8 h-8 bg-purple-200/40 rounded-full flex items-center justify-center">
                <svg className="w-4 h-4 text-purple-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}