import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Camera, Video, Upload, X } from "lucide-react";

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  accept?: string;
  maxSize?: number; // in MB
  className?: string;
}

export default function FileUpload({
  onFileSelect,
  accept = "image/*,video/*",
  maxSize = 10,
  className = "",
}: FileUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file size
    if (file.size > maxSize * 1024 * 1024) {
      alert(`File size must be less than ${maxSize}MB`);
      return;
    }

    setSelectedFile(file);
    onFileSelect(file);

    // Create preview for images
    if (file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setPreview("");
    }
  };

  const handleClearFile = () => {
    setSelectedFile(null);
    setPreview("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept={accept}
        onChange={handleFileChange}
        className="hidden"
      />

      {!selectedFile && (
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
          <div className="text-center space-y-4">
            <div className="flex justify-center space-x-4">
              <div className="p-3 bg-blue-50 rounded-lg">
                <Camera className="h-8 w-8 text-blue-600" />
              </div>
              <div className="p-3 bg-purple-50 rounded-lg">
                <Video className="h-8 w-8 text-purple-600" />
              </div>
            </div>
            <div>
              <p className="text-lg font-medium text-gray-700">Upload Evidence</p>
              <p className="text-sm text-gray-500">
                Take a photo or video of the violation
              </p>
            </div>
            <Button onClick={triggerFileInput} className="w-full">
              <Upload className="h-4 w-4 mr-2" />
              Choose File
            </Button>
          </div>
        </div>
      )}

      {selectedFile && (
        <div className="relative border rounded-lg p-4 bg-gray-50">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              {selectedFile.type.startsWith("image/") ? (
                <Camera className="h-5 w-5 text-blue-600" />
              ) : (
                <Video className="h-5 w-5 text-purple-600" />
              )}
              <span className="text-sm font-medium text-gray-700">
                {selectedFile.name}
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearFile}
              className="text-red-600 hover:text-red-700"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {preview && (
            <div className="mt-3">
              <img
                src={preview}
                alt="Preview"
                className="max-w-full h-48 object-cover rounded-lg"
              />
            </div>
          )}

          <p className="text-xs text-gray-500 mt-2">
            File size: {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
          </p>
        </div>
      )}
    </div>
  );
}
