// APK Environment Fixes
// This module provides utilities to detect and handle APK-specific behaviors

interface APKEnvironment {
  isCordova: boolean;
  isAPK: boolean;
  deviceInfo: {
    platform?: string;
    version?: string;
    model?: string;
  };
}

export class APKEnvironmentManager {
  private static instance: APKEnvironmentManager;
  private environment: APKEnvironment;

  private constructor() {
    this.environment = this.detectEnvironment();
  }

  static getInstance(): APKEnvironmentManager {
    if (!APKEnvironmentManager.instance) {
      APKEnvironmentManager.instance = new APKEnvironmentManager();
    }
    return APKEnvironmentManager.instance;
  }

  private detectEnvironment(): APKEnvironment {
    const isCordova = !!(
      (window as any).cordova || 
      (window as any).PhoneGap || 
      (window as any).phonegap ||
      location.protocol === 'file:'
    );

    const isAPK = isCordova || 
      navigator.userAgent.includes('wv') || // WebView
      (window as any).Android !== undefined;

    return {
      isCordova,
      isAPK,
      deviceInfo: {
        platform: (window as any).device?.platform,
        version: (window as any).device?.version,
        model: (window as any).device?.model
      }
    };
  }

  isAPKEnvironment(): boolean {
    return this.environment.isAPK;
  }

  isCordovaEnvironment(): boolean {
    return this.environment.isCordova;
  }

  getDeviceInfo(): APKEnvironment['deviceInfo'] {
    return this.environment.deviceInfo;
  }

  // Wait for device ready in Cordova environment
  waitForDeviceReady(): Promise<void> {
    return new Promise((resolve) => {
      if (!this.environment.isCordova) {
        resolve();
        return;
      }

      if (document.readyState === 'complete') {
        resolve();
      } else {
        document.addEventListener('deviceready', () => {
          console.log('Cordova device ready');
          resolve();
        }, false);
      }
    });
  }

  // Get appropriate base URL for API calls
  getAPIBaseURL(): string {
    if (this.environment.isAPK) {
      // For APK, use the server URL (adjust as needed)
      return 'https://your-server-domain.com';
    }
    return ''; // Relative URLs for web
  }

  // Handle storage differently for APK
  getStoragePrefix(): string {
    return this.environment.isAPK ? 'apk_' : 'web_';
  }

  // Check if network is available
  isNetworkAvailable(): boolean {
    if (this.environment.isCordova && (window as any).Connection) {
      const networkState = (window as any).navigator.connection.type;
      return networkState !== (window as any).Connection.NONE;
    }
    return navigator.onLine;
  }

  // Log environment information
  logEnvironmentInfo(): void {
    console.log('APK Environment Info:', {
      isCordova: this.environment.isCordova,
      isAPK: this.environment.isAPK,
      deviceInfo: this.environment.deviceInfo,
      userAgent: navigator.userAgent,
      location: location.href
    });
  }
}

// Export singleton instance
export const apkEnvironment = APKEnvironmentManager.getInstance();