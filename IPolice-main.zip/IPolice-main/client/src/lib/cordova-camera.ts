// Cordova Camera Implementation for APK
// This replaces the web camera API with proper Cordova camera plugin

interface CordovaCamera {
  getPicture: (
    successCallback: (imageData: string) => void,
    errorCallback: (error: string) => void,
    options: CameraOptions
  ) => void;
}

interface CameraOptions {
  quality?: number;
  destinationType?: number;
  sourceType?: number;
  encodingType?: number;
  targetWidth?: number;
  targetHeight?: number;
  mediaType?: number;
  allowEdit?: boolean;
  correctOrientation?: boolean;
  saveToPhotoAlbum?: boolean;
}

declare global {
  interface Window {
    Camera?: {
      DestinationType: {
        DATA_URL: number;
        FILE_URI: number;
      };
      PictureSourceType: {
        CAMERA: number;
        PHOTOLIBRARY: number;
        SAVEDPHOTOALBUM: number;
      };
      EncodingType: {
        JPEG: number;
        PNG: number;
      };
      MediaType: {
        PICTURE: number;
        VIDEO: number;
        ALLMEDIA: number;
      };
    };
    navigator: {
      camera?: CordovaCamera;
    } & Navigator;
  }
}

export class CordovaCameraManager {
  private isCordovaAvailable(): boolean {
    return !!(window.navigator?.camera && window.Camera);
  }

  private isDeviceReady(): Promise<void> {
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        resolve();
      } else {
        document.addEventListener('deviceready', () => resolve(), false);
      }
    });
  }

  async takePicture(): Promise<string> {
    if (!this.isCordovaAvailable()) {
      throw new Error('Cordova camera plugin not available');
    }

    await this.isDeviceReady();

    return new Promise((resolve, reject) => {
      const options: CameraOptions = {
        quality: 80,
        destinationType: window.Camera!.DestinationType.DATA_URL,
        sourceType: window.Camera!.PictureSourceType.CAMERA,
        encodingType: window.Camera!.EncodingType.JPEG,
        targetWidth: 800,
        targetHeight: 600,
        mediaType: window.Camera!.MediaType.PICTURE,
        allowEdit: false,
        correctOrientation: true,
        saveToPhotoAlbum: false
      };

      window.navigator.camera!.getPicture(
        (imageData: string) => {
          const base64Image = `data:image/jpeg;base64,${imageData}`;
          resolve(base64Image);
        },
        (error: string) => {
          console.error('Camera error:', error);
          reject(new Error(`Camera failed: ${error}`));
        },
        options
      );
    });
  }

  async selectFromGallery(): Promise<string> {
    if (!this.isCordovaAvailable()) {
      throw new Error('Cordova camera plugin not available');
    }

    await this.isDeviceReady();

    return new Promise((resolve, reject) => {
      const options: CameraOptions = {
        quality: 80,
        destinationType: window.Camera!.DestinationType.DATA_URL,
        sourceType: window.Camera!.PictureSourceType.PHOTOLIBRARY,
        encodingType: window.Camera!.EncodingType.JPEG,
        targetWidth: 800,
        targetHeight: 600,
        mediaType: window.Camera!.MediaType.PICTURE,
        allowEdit: false,
        correctOrientation: true
      };

      window.navigator.camera!.getPicture(
        (imageData: string) => {
          const base64Image = `data:image/jpeg;base64,${imageData}`;
          resolve(base64Image);
        },
        (error: string) => {
          console.error('Gallery selection error:', error);
          reject(new Error(`Gallery selection failed: ${error}`));
        },
        options
      );
    });
  }

  // Fallback for web environment during development - tries camera first
  async webCameraFallback(): Promise<string> {
    return new Promise((resolve, reject) => {
      // Try getUserMedia first for true camera access
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const video = document.createElement('video');
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'environment',
            width: { ideal: 1920 },
            height: { ideal: 1080 }
          }
        })
        .then(stream => {
          video.srcObject = stream;
          video.autoplay = true;
          video.muted = true;
          video.playsInline = true;
          
          // Create a simple camera interface
          const cameraContainer = document.createElement('div');
          cameraContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: black;
            z-index: 10000;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
          `;
          
          video.style.cssText = `
            width: 100%;
            height: 80%;
            object-fit: cover;
          `;
          
          const captureButton = document.createElement('button');
          captureButton.innerText = 'Capture Photo';
          captureButton.style.cssText = `
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            padding: 15px 30px;
            background: #3b82f6;
            color: white;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
          `;
          
          const closeButton = document.createElement('button');
          closeButton.innerText = '×';
          closeButton.style.cssText = `
            position: absolute;
            top: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            background: rgba(0,0,0,0.5);
            color: white;
            border: none;
            border-radius: 50%;
            font-size: 24px;
            cursor: pointer;
          `;
          
          cameraContainer.appendChild(video);
          cameraContainer.appendChild(captureButton);
          cameraContainer.appendChild(closeButton);
          document.body.appendChild(cameraContainer);
          
          video.addEventListener('loadedmetadata', () => {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
          });
          
          const cleanup = () => {
            stream.getTracks().forEach(track => track.stop());
            document.body.removeChild(cameraContainer);
          };
          
          captureButton.onclick = () => {
            if (context && video.videoWidth && video.videoHeight) {
              canvas.width = video.videoWidth;
              canvas.height = video.videoHeight;
              context.drawImage(video, 0, 0);
              const imageData = canvas.toDataURL('image/jpeg', 0.8);
              cleanup();
              resolve(imageData);
            }
          };
          
          closeButton.onclick = () => {
            cleanup();
            reject(new Error('Camera cancelled'));
          };
        })
        .catch(error => {
          console.log('Camera access failed, falling back to file input:', error);
          this.useFileInputFallback(resolve, reject);
        });
      } else {
        // No camera API available, use file input
        this.useFileInputFallback(resolve, reject);
      }
    });
  }
  
  private useFileInputFallback(resolve: (value: string) => void, reject: (reason: any) => void): void {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.capture = 'environment'; // Prefer camera if available
    
    input.onchange = (event) => {
      const file = (event.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          if (result) {
            resolve(result);
          } else {
            reject(new Error('Failed to read image file'));
          }
        };
        reader.onerror = () => {
          reject(new Error('Failed to read image file'));
        };
        reader.readAsDataURL(file);
      } else {
        reject(new Error('No file selected'));
      }
    };
    
    (input as any).oncancel = () => {
      reject(new Error('File selection cancelled'));
    };
    
    input.click();
  }

  // Universal camera method that works in both Cordova and web
  async capturePhoto(): Promise<string> {
    try {
      if (this.isCordovaAvailable()) {
        console.log('Using Cordova camera for photo capture');
        return await this.takePicture();
      } else {
        console.log('Using web camera fallback');
        return await this.webCameraFallback();
      }
    } catch (error) {
      console.error('Photo capture failed:', error);
      throw error;
    }
  }

  // Universal gallery method
  async selectPhoto(): Promise<string> {
    try {
      if (this.isCordovaAvailable()) {
        console.log('Using Cordova gallery selection');
        return await this.selectFromGallery();
      } else {
        // Web fallback for gallery selection
        return new Promise((resolve, reject) => {
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = 'image/*';
          
          input.onchange = (event) => {
            const file = (event.target as HTMLInputElement).files?.[0];
            if (file) {
              const reader = new FileReader();
              reader.onload = (e) => {
                resolve(e.target?.result as string);
              };
              reader.readAsDataURL(file);
            } else {
              reject(new Error('No file selected'));
            }
          };
          
          input.click();
        });
      }
    } catch (error) {
      console.error('Photo selection failed:', error);
      throw error;
    }
  }
}

// Export singleton instance
export const cordovaCamera = new CordovaCameraManager();