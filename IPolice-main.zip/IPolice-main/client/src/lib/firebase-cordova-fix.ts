// Firebase Configuration Fix for Cordova APK
// This ensures Firebase works properly in both web and APK environments

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getDatabase, connectDatabaseEmulator } from 'firebase/database';

// Firebase configuration from environment variables
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN, 
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

// Check if we're in a Cordova environment
const isCordovaEnvironment = (): boolean => {
  return !!(window as any).cordova || 
         !!(window as any).PhoneGap || 
         !!(window as any).phonegap ||
         location.protocol === 'file:';
};

// Initialize Firebase with proper error handling
let app: any;
let database: any;

export const initializeFirebaseForCordova = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    try {
      // Check if Firebase is already initialized
      if (getApps().length === 0) {
        app = initializeApp(firebaseConfig);
        console.log('Firebase initialized for Cordova APK');
      } else {
        app = getApp();
        console.log('Firebase already initialized');
      }

      // Initialize Realtime Database
      database = getDatabase(app);
      
      // For Cordova APK, ensure proper connection
      if (isCordovaEnvironment()) {
        console.log('Cordova environment detected - configuring Firebase for APK');
        
        // Wait for device ready if in Cordova
        if ((window as any).cordova) {
          document.addEventListener('deviceready', () => {
            console.log('Device ready - Firebase configured for Cordova');
            resolve();
          }, false);
        } else {
          resolve();
        }
      } else {
        console.log('Web environment - Firebase configured for browser');
        resolve();
      }
      
    } catch (error) {
      console.error('Firebase initialization failed:', error);
      reject(error);
    }
  });
};

// Export database instance
export { database };

// Initialize on module load
initializeFirebaseForCordova().catch(console.error);