import { initializeApp } from 'firebase/app';
import { 
  getDatabase, 
  ref, 
  push, 
  set, 
  get, 
  update, 
  remove, 
  onValue, 
  off,
  serverTimestamp,
  query,
  orderByChild,
  equalTo,
  limitToLast,
  DatabaseReference,
  DataSnapshot
} from 'firebase/database';
import type { User, Report, Reward, Activity, InsertUser, InsertReport, InsertReward, InsertActivity } from '@shared/types';
import { apkEnvironment } from './apk-environment-fix';

// Check if we're in browser environment and have Firebase secrets
const isFirebaseAvailable = () => {
  return !!(import.meta.env.VITE_FIREBASE_API_KEY && import.meta.env.VITE_FIREBASE_PROJECT_ID);
};

// Firebase configuration using provided secrets
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

// Initialize Firebase only if configuration is available
let app: any = null;
let database: any = null;

if (isFirebaseAvailable()) {
  try {
    app = initializeApp(firebaseConfig);
    database = getDatabase(app);
    console.log('Firebase Realtime Database initialized for mobile APK');
  } catch (error) {
    console.warn('Firebase initialization failed:', error);
  }
} else {
  console.warn('Firebase configuration not available - using local storage fallback');
}

// Type definitions for enhanced mobile functionality
interface MobileReport extends Omit<Report, 'id'> {
  id?: string;
  deviceInfo?: {
    userAgent: string;
    platform: string;
    cordova?: boolean;
  };
  syncStatus: 'pending' | 'synced' | 'failed';
  localTimestamp: number;
}

interface MobileUser extends Omit<User, 'id'> {
  id?: string;
  lastSync?: number;
  deviceId?: string;
}

class FirebaseRealtimeManager {
  private listeners: Map<string, () => void> = new Map();

  // Check if Firebase is available
  private isFirebaseReady(): boolean {
    return !!(database && app);
  }

  // Fallback to mobile storage when Firebase is not available
  private async getFallbackStorage() {
    const { mobileStorage } = await import('./mobile-storage');
    return mobileStorage;
  }

  // User management
  async createUser(userData: Omit<MobileUser, 'id'>): Promise<MobileUser> {
    if (!this.isFirebaseReady()) {
      const storage = await this.getFallbackStorage();
      return storage.createUser(userData);
    }

    try {
      const usersRef = ref(database, 'users');
      const newUserRef = push(usersRef);
      const userId = newUserRef.key!;
      
      const userWithTimestamp = {
        ...userData,
        id: userId,
        lastSync: Date.now(),
        deviceId: this.getDeviceId(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      await set(newUserRef, userWithTimestamp);
      console.log('User created in Firebase:', userId);
      
      return { ...userWithTimestamp, id: userId };
    } catch (error) {
      console.error('Error creating user in Firebase:', error);
      throw error;
    }
  }

  async getUser(userId: number | string): Promise<MobileUser | null> {
    if (!this.isFirebaseReady()) {
      const storage = await this.getFallbackStorage();
      return storage.getUser(Number(userId));
    }

    try {
      const userRef = ref(database, `users/${userId}`);
      const snapshot = await get(userRef);
      
      if (snapshot.exists()) {
        const userData = snapshot.val();
        return { ...userData, id: userId.toString() };
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching user from Firebase:', error);
      throw error;
    }
  }

  async updateUser(userId: number | string, updates: Partial<MobileUser>): Promise<MobileUser> {
    if (!this.isFirebaseReady()) {
      const storage = await this.getFallbackStorage();
      return storage.updateUser(Number(userId), updates);
    }

    try {
      const userRef = ref(database, `users/${userId}`);
      const updateData = {
        ...updates,
        lastSync: Date.now(),
        updatedAt: serverTimestamp()
      };
      
      await update(userRef, updateData);
      
      // Return updated user
      const updatedUser = await this.getUser(userId);
      if (!updatedUser) {
        throw new Error('User not found after update');
      }
      
      console.log('User updated in Firebase:', userId);
      return updatedUser;
    } catch (error) {
      console.error('Error updating user in Firebase:', error);
      throw error;
    }
  }

  // Report management with mobile-specific features
  async createReport(reportData: Omit<MobileReport, 'id'>): Promise<MobileReport> {
    if (!this.isFirebaseReady()) {
      const storage = await this.getFallbackStorage();
      return storage.saveReport({
        title: reportData.title || "Traffic Violation Report",
        description: reportData.description,
        location: reportData.location,
        coordinates: reportData.coordinates,
        violationType: reportData.violationType,
        userId: reportData.userId,
        mediaFile: undefined // Base64 data would be in mediaUrl
      });
    }

    try {
      const reportsRef = ref(database, 'reports');
      const newReportRef = push(reportsRef);
      const reportId = newReportRef.key!;
      
      const reportWithMetadata = {
        ...reportData,
        id: reportId,
        syncStatus: 'synced' as const,
        localTimestamp: Date.now(),
        deviceInfo: this.getDeviceInfo(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      await set(newReportRef, reportWithMetadata);
      console.log('Report created in Firebase:', reportId);
      
      // Update user stats
      await this.updateUserStats(reportData.userId);
      
      return reportWithMetadata;
    } catch (error) {
      console.error('Error creating report in Firebase:', error);
      throw error;
    }
  }

  async getUserReports(userId: number | string): Promise<MobileReport[]> {
    if (!this.isFirebaseReady()) {
      const storage = await this.getFallbackStorage();
      return storage.getUserReports(Number(userId));
    }

    try {
      const reportsRef = ref(database, 'reports');
      const userReportsQuery = query(
        reportsRef,
        orderByChild('userId'),
        equalTo(Number(userId))
      );
      
      const snapshot = await get(userReportsQuery);
      const reports: MobileReport[] = [];
      
      snapshot.forEach((childSnapshot) => {
        const reportData = childSnapshot.val();
        reports.push({
          ...reportData,
          id: childSnapshot.key
        });
      });
      
      // Sort by creation date (most recent first)
      return reports.sort((a, b) => (b.localTimestamp || 0) - (a.localTimestamp || 0));
    } catch (error) {
      console.error('Error fetching user reports from Firebase:', error);
      throw error;
    }
  }

  async getAllReports(): Promise<MobileReport[]> {
    if (!this.isFirebaseReady()) {
      const storage = await this.getFallbackStorage();
      return storage.getReports();
    }

    try {
      const reportsRef = ref(database, 'reports');
      const snapshot = await get(reportsRef);
      const reports: MobileReport[] = [];
      
      snapshot.forEach((childSnapshot) => {
        const reportData = childSnapshot.val();
        reports.push({
          ...reportData,
          id: childSnapshot.key
        });
      });
      
      return reports.sort((a, b) => (b.localTimestamp || 0) - (a.localTimestamp || 0));
    } catch (error) {
      console.error('Error fetching all reports from Firebase:', error);
      throw error;
    }
  }

  // User statistics
  async getUserStats(userId: number | string) {
    if (!this.isFirebaseReady()) {
      const storage = await this.getFallbackStorage();
      return storage.getUserStats(Number(userId));
    }

    try {
      const reports = await this.getUserReports(userId);
      const totalReports = reports.length;
      const verifiedReports = reports.filter(r => r.verificationStatus === 'verified').length;
      const pendingReports = reports.filter(r => r.verificationStatus === 'pending').length;
      
      // Calculate points based on reports
      const points = verifiedReports * 50 + pendingReports * 10;
      const rank = Math.floor(points / 100) + 1;
      
      return {
        totalReports,
        verifiedReports,
        pendingReports,
        points,
        rank
      };
    } catch (error) {
      console.error('Error calculating user stats:', error);
      throw error;
    }
  }

  private async updateUserStats(userId: number | string) {
    try {
      const stats = await this.getUserStats(userId);
      const userRef = ref(database, `users/${userId}`);
      
      await update(userRef, {
        points: stats.points,
        rank: stats.rank,
        level: Math.floor(stats.points / 200) + 1,
        lastSync: Date.now(),
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating user stats:', error);
    }
  }

  // Leaderboard
  async getLeaderboard(): Promise<MobileUser[]> {
    try {
      const usersRef = ref(database, 'users');
      const leaderboardQuery = query(
        usersRef,
        orderByChild('points'),
        limitToLast(50)
      );
      
      const snapshot = await get(leaderboardQuery);
      const users: MobileUser[] = [];
      
      snapshot.forEach((childSnapshot) => {
        const userData = childSnapshot.val();
        if (userData.points > 0) {
          users.push({
            ...userData,
            id: childSnapshot.key
          });
        }
      });
      
      // Sort by points (highest first)
      return users.sort((a, b) => (b.points || 0) - (a.points || 0));
    } catch (error) {
      console.error('Error fetching leaderboard from Firebase:', error);
      throw error;
    }
  }

  // Rewards
  async getRewards(): Promise<Reward[]> {
    try {
      const rewardsRef = ref(database, 'rewards');
      const snapshot = await get(rewardsRef);
      const rewards: Reward[] = [];
      
      snapshot.forEach((childSnapshot) => {
        const rewardData = childSnapshot.val();
        rewards.push({
          ...rewardData,
          id: childSnapshot.key
        });
      });
      
      return rewards;
    } catch (error) {
      console.error('Error fetching rewards from Firebase:', error);
      throw error;
    }
  }

  // Real-time listeners for mobile app
  listenToUserReports(userId: number | string, callback: (reports: MobileReport[]) => void): () => void {
    const reportsRef = ref(database, 'reports');
    const userReportsQuery = query(
      reportsRef,
      orderByChild('userId'),
      equalTo(Number(userId))
    );
    
    const unsubscribe = onValue(userReportsQuery, (snapshot) => {
      const reports: MobileReport[] = [];
      snapshot.forEach((childSnapshot) => {
        const reportData = childSnapshot.val();
        reports.push({
          ...reportData,
          id: childSnapshot.key
        });
      });
      
      callback(reports.sort((a, b) => (b.localTimestamp || 0) - (a.localTimestamp || 0)));
    });
    
    const listenerId = `user-reports-${userId}`;
    this.listeners.set(listenerId, () => off(userReportsQuery));
    
    return () => {
      off(userReportsQuery);
      this.listeners.delete(listenerId);
    };
  }

  listenToLeaderboard(callback: (users: MobileUser[]) => void): () => void {
    const usersRef = ref(database, 'users');
    
    const unsubscribe = onValue(usersRef, (snapshot) => {
      const users: MobileUser[] = [];
      snapshot.forEach((childSnapshot) => {
        const userData = childSnapshot.val();
        if (userData.points > 0) {
          users.push({
            ...userData,
            id: childSnapshot.key
          });
        }
      });
      
      callback(users.sort((a, b) => (b.points || 0) - (a.points || 0)));
    });
    
    this.listeners.set('leaderboard', () => off(usersRef));
    
    return () => {
      off(usersRef);
      this.listeners.delete('leaderboard');
    };
  }

  // Utility methods for mobile
  private getDeviceInfo() {
    return {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      cordova: !!(window as any).cordova
    };
  }

  private getDeviceId(): string {
    // Generate or retrieve device-specific ID
    let deviceId = localStorage.getItem('deviceId');
    if (!deviceId) {
      deviceId = 'device_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
      localStorage.setItem('deviceId', deviceId);
    }
    return deviceId;
  }

  // Cleanup method for component unmounting
  cleanup() {
    this.listeners.forEach((unsubscribe) => {
      unsubscribe();
    });
    this.listeners.clear();
  }

  // Network status monitoring for mobile
  isOnline(): boolean {
    return navigator.onLine;
  }

  onNetworkChange(callback: (isOnline: boolean) => void) {
    const handleOnline = () => callback(true);
    const handleOffline = () => callback(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }
}

export const firebaseRealtime = new FirebaseRealtimeManager();
export default firebaseRealtime;