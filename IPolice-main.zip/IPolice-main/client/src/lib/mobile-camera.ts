// Mobile camera and file handling utilities
export class MobileFileManager {
  private maxImageSize = 1920; // Max width/height
  private compressionQuality = 0.8;

  // Detect if running in mobile environment
  isMobile(): boolean {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
           window.innerWidth <= 768;
  }

  // Detect if running in mobile app (WebView)
  isMobileApp(): boolean {
    return (window.navigator as any).standalone === true || // iOS PWA
           window.matchMedia('(display-mode: standalone)').matches || // PWA
           document.referrer.includes('android-app://'); // Android WebView
  }

  // Enhanced camera access with mobile fallbacks
  async accessCamera(): Promise<MediaStream | null> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      console.warn('Camera API not available');
      return null;
    }

    try {
      // Try high-quality camera first
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // Back camera
          width: { ideal: 1920, max: 1920 },
          height: { ideal: 1080, max: 1080 }
        }
      });
      return stream;
    } catch (error) {
      console.warn('High-quality camera failed, trying basic:', error);
      
      try {
        // Fallback to basic camera
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });
        return stream;
      } catch (basicError) {
        console.warn('Basic camera failed, trying minimal:', basicError);
        
        try {
          // Minimal camera requirements
          const stream = await navigator.mediaDevices.getUserMedia({
            video: true
          });
          return stream;
        } catch (minimalError) {
          console.error('All camera attempts failed:', minimalError);
          return null;
        }
      }
    }
  }

  // Enhanced file picker with mobile support
  async pickFile(accept = 'image/*'): Promise<File | null> {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = accept;
      
      // Mobile-specific attributes
      if (this.isMobile()) {
        (input as any).capture = 'environment'; // Try to open camera directly
        input.multiple = false;
      }
      
      input.onchange = (event) => {
        const file = (event.target as HTMLInputElement).files?.[0];
        resolve(file || null);
      };
      
      input.oncancel = () => resolve(null);
      
      // Trigger file picker
      input.click();
    });
  }

  // Compress image for mobile storage
  async compressImage(file: File): Promise<File> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();
      
      img.onload = () => {
        // Calculate new dimensions
        const { width, height } = this.calculateDimensions(img.width, img.height);
        
        canvas.width = width;
        canvas.height = height;
        
        // Draw and compress
        ctx.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const compressedFile = new File([blob], file.name, {
              type: 'image/jpeg',
              lastModified: Date.now()
            });
            resolve(compressedFile);
          } else {
            resolve(file); // Fallback to original
          }
        }, 'image/jpeg', this.compressionQuality);
      };
      
      img.onerror = () => resolve(file); // Fallback to original
      img.src = URL.createObjectURL(file);
    });
  }

  // Convert file to base64 for IndexedDB storage
  async fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  }

  // Convert base64 back to file
  async base64ToFile(base64: string, filename: string): Promise<File> {
    const response = await fetch(base64);
    const blob = await response.blob();
    return new File([blob], filename, { type: blob.type });
  }

  // Calculate optimal dimensions for mobile
  private calculateDimensions(originalWidth: number, originalHeight: number): { width: number; height: number } {
    const maxSize = this.maxImageSize;
    
    if (originalWidth <= maxSize && originalHeight <= maxSize) {
      return { width: originalWidth, height: originalHeight };
    }
    
    const ratio = Math.min(maxSize / originalWidth, maxSize / originalHeight);
    
    return {
      width: Math.round(originalWidth * ratio),
      height: Math.round(originalHeight * ratio)
    };
  }

  // Capture photo from video stream
  capturePhotoFromVideo(video: HTMLVideoElement): string | null {
    if (!video || video.videoWidth === 0) {
      return null;
    }

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    
    // Set canvas dimensions to video dimensions
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw video frame to canvas
    ctx.drawImage(video, 0, 0);
    
    // Convert to base64
    return canvas.toDataURL('image/jpeg', this.compressionQuality);
  }

  // Stop all camera streams
  stopCameraStream(stream: MediaStream | null): void {
    if (stream) {
      stream.getTracks().forEach(track => {
        track.stop();
      });
    }
  }

  // Check camera permissions
  async checkCameraPermissions(): Promise<boolean> {
    if (!navigator.permissions) {
      return true; // Assume available if permissions API not supported
    }

    try {
      const result = await navigator.permissions.query({ name: 'camera' as PermissionName });
      return result.state === 'granted' || result.state === 'prompt';
    } catch (error) {
      console.warn('Could not check camera permissions:', error);
      return true; // Assume available
    }
  }

  // Request camera permissions
  async requestCameraPermissions(): Promise<boolean> {
    try {
      const stream = await this.accessCamera();
      if (stream) {
        this.stopCameraStream(stream);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Camera permission denied:', error);
      return false;
    }
  }
}

// Singleton instance
export const mobileFileManager = new MobileFileManager();