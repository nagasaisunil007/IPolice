// IndexedDB wrapper for mobile compatibility
export interface Report {
  id?: number;
  title: string;
  description: string;
  location: string;
  coordinates?: string;
  violationType: string;
  userId: number;
  mediaUrl?: string;
  mediaType?: string;
  status: string;
  createdAt: Date;
}

export interface User {
  id: number;
  name: string;
  location: string;
  email?: string;
  points: number;
  level: number;
  profilePicture?: string;
}

export class MobileDatabase {
  private db: IDBDatabase | null = null;
  private dbName = 'iPoliceDB';
  private version = 1;

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);
      
      request.onerror = () => reject(request.error);
      
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };
      
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        // Create reports store
        if (!db.objectStoreNames.contains('reports')) {
          const reportStore = db.createObjectStore('reports', { keyPath: 'id', autoIncrement: true });
          reportStore.createIndex('userId', 'userId', { unique: false });
          reportStore.createIndex('status', 'status', { unique: false });
          reportStore.createIndex('createdAt', 'createdAt', { unique: false });
        }
        
        // Create users store
        if (!db.objectStoreNames.contains('users')) {
          const userStore = db.createObjectStore('users', { keyPath: 'id' });
        }
        
        // Create activities store
        if (!db.objectStoreNames.contains('activities')) {
          const activityStore = db.createObjectStore('activities', { keyPath: 'id', autoIncrement: true });
          activityStore.createIndex('userId', 'userId', { unique: false });
          activityStore.createIndex('createdAt', 'createdAt', { unique: false });
        }
      };
    });
  }

  async saveReport(report: Omit<Report, 'id'>): Promise<Report> {
    if (!this.db) throw new Error('Database not initialized');
    
    const transaction = this.db.transaction(['reports'], 'readwrite');
    const store = transaction.objectStore('reports');
    
    const reportWithDate = {
      ...report,
      createdAt: new Date(),
      status: 'pending'
    };
    
    const request = store.add(reportWithDate);
    
    return new Promise((resolve, reject) => {
      request.onsuccess = () => {
        const savedReport = { ...reportWithDate, id: request.result as number };
        resolve(savedReport);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async getReports(userId?: number): Promise<Report[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    const transaction = this.db.transaction(['reports'], 'readonly');
    const store = transaction.objectStore('reports');
    
    let request: IDBRequest;
    if (userId) {
      const index = store.index('userId');
      request = index.getAll(userId);
    } else {
      request = store.getAll();
    }
    
    return new Promise((resolve, reject) => {
      request.onsuccess = () => {
        const reports = request.result.sort((a: Report, b: Report) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        resolve(reports);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async updateUser(userId: number, updates: Partial<User>): Promise<User> {
    if (!this.db) throw new Error('Database not initialized');
    
    const transaction = this.db.transaction(['users'], 'readwrite');
    const store = transaction.objectStore('users');
    
    return new Promise((resolve, reject) => {
      const getRequest = store.get(userId);
      
      getRequest.onsuccess = () => {
        const existingUser = getRequest.result || { 
          id: userId, 
          name: 'User', 
          location: 'Bengaluru', 
          points: 0, 
          level: 1 
        };
        
        const updatedUser = { ...existingUser, ...updates };
        
        const putRequest = store.put(updatedUser);
        putRequest.onsuccess = () => resolve(updatedUser);
        putRequest.onerror = () => reject(putRequest.error);
      };
      
      getRequest.onerror = () => reject(getRequest.error);
    });
  }

  async getUser(userId: number): Promise<User | null> {
    if (!this.db) throw new Error('Database not initialized');
    
    const transaction = this.db.transaction(['users'], 'readonly');
    const store = transaction.objectStore('users');
    const request = store.get(userId);
    
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async createActivity(activity: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const transaction = this.db.transaction(['activities'], 'readwrite');
    const store = transaction.objectStore('activities');
    
    const activityWithDate = {
      ...activity,
      createdAt: new Date()
    };
    
    store.add(activityWithDate);
  }

  async getActivities(userId: number, limit = 10): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    const transaction = this.db.transaction(['activities'], 'readonly');
    const store = transaction.objectStore('activities');
    const index = store.index('userId');
    const request = index.getAll(userId);
    
    return new Promise((resolve, reject) => {
      request.onsuccess = () => {
        const activities = request.result
          .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, limit);
        resolve(activities);
      };
      request.onerror = () => reject(request.error);
    });
  }
}

// Singleton instance
export const mobileDB = new MobileDatabase();