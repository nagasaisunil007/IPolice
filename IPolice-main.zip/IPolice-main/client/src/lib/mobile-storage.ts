// Mobile storage service that handles offline-first data management
import { mobileDB, type Report, type User } from './mobile-database';
import { mobileFileManager } from './mobile-camera';

export class MobileStorageService {
  private isInitialized = false;

  async initialize(): Promise<void> {
    if (this.isInitialized) return;
    
    try {
      await mobileDB.init();
      this.isInitialized = true;
      console.log('Mobile storage initialized successfully');
    } catch (error) {
      console.error('Failed to initialize mobile storage:', error);
      throw error;
    }
  }

  // Report management
  async saveReport(reportData: {
    title: string;
    description: string;
    location: string;
    coordinates?: string;
    violationType: string;
    userId: number;
    mediaFile?: File;
  }): Promise<Report> {
    await this.initialize();

    let mediaUrl = '';
    let mediaType = '';

    // Handle media file if provided
    if (reportData.mediaFile) {
      try {
        // Compress image for mobile storage
        const compressedFile = await mobileFileManager.compressImage(reportData.mediaFile);
        
        // Convert to base64 for storage
        const base64Data = await mobileFileManager.fileToBase64(compressedFile);
        mediaUrl = base64Data;
        mediaType = compressedFile.type.startsWith('image/') ? 'image' : 'video';
      } catch (error) {
        console.warn('Failed to process media file:', error);
        // Continue without media
      }
    }

    const report = await mobileDB.saveReport({
      title: reportData.title,
      description: reportData.description,
      location: reportData.location,
      coordinates: reportData.coordinates,
      violationType: reportData.violationType,
      userId: reportData.userId,
      mediaUrl,
      mediaType,
      status: 'pending',
      createdAt: new Date()
    });

    // Create activity entry
    await mobileDB.createActivity({
      userId: reportData.userId,
      type: 'report_submitted',
      title: 'Report Submitted',
      description: `Your report "${reportData.title}" has been submitted for review.`,
      points: 10, // Award points for submission
      metadata: JSON.stringify({ reportId: report.id, location: reportData.location })
    });

    // Update user points
    await this.addUserPoints(reportData.userId, 10);

    return report;
  }

  async getReports(userId?: number): Promise<Report[]> {
    await this.initialize();
    return mobileDB.getReports(userId);
  }

  async getUserReports(userId: number): Promise<Report[]> {
    return this.getReports(userId);
  }

  // User management
  async updateUser(userId: number, updates: Partial<User>): Promise<User> {
    await this.initialize();
    return mobileDB.updateUser(userId, updates);
  }

  async getUser(userId: number): Promise<User | null> {
    await this.initialize();
    let user = await mobileDB.getUser(userId);
    
    // Create default user if not exists
    if (!user) {
      user = await mobileDB.updateUser(userId, {
        id: userId,
        name: 'User',
        location: 'Koramangala, Bengaluru',
        points: 0,
        level: 1
      });
    }
    
    return user;
  }

  async addUserPoints(userId: number, points: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error('User not found');

    const newPoints = user.points + points;
    const newLevel = Math.floor(newPoints / 500) + 1; // Level up every 500 points

    return this.updateUser(userId, {
      points: newPoints,
      level: newLevel
    });
  }

  async updateProfilePicture(userId: number, imageFile: File): Promise<string> {
    await this.initialize();
    
    try {
      // Compress and convert to base64
      const compressedFile = await mobileFileManager.compressImage(imageFile);
      const base64Data = await mobileFileManager.fileToBase64(compressedFile);
      
      // Update user profile
      await this.updateUser(userId, { profilePicture: base64Data });
      
      return base64Data;
    } catch (error) {
      console.error('Failed to update profile picture:', error);
      throw error;
    }
  }

  // Activities management
  async getUserActivities(userId: number, limit = 10): Promise<any[]> {
    await this.initialize();
    return mobileDB.getActivities(userId, limit);
  }

  // Statistics
  async getUserStats(userId: number): Promise<{
    totalReports: number;
    verifiedReports: number;
    pendingReports: number;
    points: number;
    rank: number;
    level: number;
    pointsToNextLevel: number;
  }> {
    await this.initialize();
    
    const user = await this.getUser(userId);
    const reports = await this.getUserReports(userId);
    
    const totalReports = reports.length;
    const verifiedReports = reports.filter(r => r.status === 'verified').length;
    const pendingReports = reports.filter(r => r.status === 'pending').length;
    
    const points = user?.points || 0;
    const level = user?.level || 1;
    const pointsToNextLevel = (level * 500) - points;
    
    // For rank, we'll use a simple calculation based on points
    // In a real app, this would query all users and calculate actual rank
    const rank = Math.max(1, Math.floor(points / 100) + 1);

    return {
      totalReports,
      verifiedReports,
      pendingReports,
      points,
      rank,
      level,
      pointsToNextLevel: Math.max(0, pointsToNextLevel)
    };
  }

  // Leaderboard (simplified for offline mode)
  async getLeaderboard(limit = 10): Promise<User[]> {
    await this.initialize();
    
    // In offline mode, we can only show the current user
    // In a real app, this would sync with server data
    const currentUser = await this.getUser(1); // Assuming user ID 1
    
    return currentUser ? [currentUser] : [];
  }

  // Rewards (static data for offline mode)
  async getRewards(): Promise<any[]> {
    return [
      {
        id: 1,
        title: "Reflective Vest",
        description: "High-visibility safety vest for traffic reporting",
        points: 500,
        category: "safety",
        available: true,
        image: "/api/placeholder/100/100"
      },
      {
        id: 2,
        title: "Traffic Cone",
        description: "Professional traffic cone for marking violations",
        points: 750,
        category: "equipment",
        available: true,
        image: "/api/placeholder/100/100"
      },
      {
        id: 3,
        title: "Digital Camera",
        description: "High-quality camera for documentation",
        points: 2000,
        category: "equipment",
        available: true,
        image: "/api/placeholder/100/100"
      }
    ];
  }

  // Sync status (for future server sync implementation)
  hasPendingSync(): boolean {
    // Check if there are any reports that need to be synced to server
    // For now, always return false (pure offline mode)
    return false;
  }

  async syncWithServer(): Promise<void> {
    // Future implementation for syncing local data with server
    console.log('Server sync not implemented in offline mode');
  }
}

// Singleton instance
export const mobileStorage = new MobileStorageService();