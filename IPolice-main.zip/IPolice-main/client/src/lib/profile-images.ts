// Dynamic AI-Style Profile Avatar Generator for Leaderboard
export class ProfileImageGenerator {
  private static colors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
    '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
    '#FF7675', '#74B9FF', '#00B894', '#FDCB6E', '#E17055',
    '#FD79A8', '#6C5CE7', '#A29BFE', '#00CEC9', '#55A3FF'
  ];

  private static gradientPairs = [
    ['#667eea', '#764ba2'], ['#f093fb', '#f5576c'], ['#4facfe', '#00f2fe'],
    ['#43e97b', '#38f9d7'], ['#fa709a', '#fee140'], ['#a8edea', '#fed6e3'],
    ['#ff9a9e', '#fecfef'], ['#ffecd2', '#fcb69f'], ['#ff8a80', '#ff5722'],
    ['#81c784', '#4caf50'], ['#64b5f6', '#2196f3'], ['#ba68c8', '#9c27b0']
  ];

  private static avatarStyles = [
    'geometric', 'abstract', 'minimal', 'gradient', 'artistic', 'modern', 'vibrant', 'elegant'
  ];

  private static backgroundPatterns = [
    'circles', 'waves', 'triangles', 'hexagons', 'diamonds', 'dots', 'lines', 'spiral'
  ];

  // Generate dynamic AI-style profile avatar based on user data
  static generateProfileImage(userId: number, userName: string, userRank?: number): string {
    const canvas = document.createElement('canvas');
    canvas.width = 120;
    canvas.height = 120;
    const ctx = canvas.getContext('2d');

    if (!ctx) return this.getFallbackAvatar(userName, userRank);

    // Create more sophisticated selection based on user data
    const nameHash = this.getStringHash(userName);
    const combinedSeed = userId + nameHash;
    
    const gradientIndex = combinedSeed % this.gradientPairs.length;
    const styleIndex = combinedSeed % this.avatarStyles.length;
    const patternIndex = combinedSeed % this.backgroundPatterns.length;
    
    const [primaryColor, secondaryColor] = this.gradientPairs[gradientIndex];
    const style = this.avatarStyles[styleIndex];
    const pattern = this.backgroundPatterns[patternIndex];

    // Create sophisticated gradient background
    this.createDynamicBackground(ctx, primaryColor, secondaryColor, style, pattern, combinedSeed);

    // Add rank-based enhancements for top users
    if (userRank && userRank <= 3) {
      this.addRankEnhancements(ctx, userRank, combinedSeed);
    }

    // Add dynamic pattern overlay
    this.addDynamicPattern(ctx, pattern, combinedSeed, style);

    // Add styled initials with rank-based customization
    this.addStyledInitials(ctx, userName, userRank, style);

    // Add subtle highlight effects
    this.addHighlightEffects(ctx, combinedSeed, userRank);

    return canvas.toDataURL('image/png');
  }

  // Create dynamic background with multiple gradient styles
  private static createDynamicBackground(ctx: CanvasRenderingContext2D, primary: string, secondary: string, style: string, pattern: string, seed: number) {
    const centerX = 60, centerY = 60, radius = 60;
    
    switch (style) {
      case 'modern':
        // Angular gradient
        const angleGradient = ctx.createLinearGradient(0, 0, 120, 120);
        angleGradient.addColorStop(0, primary);
        angleGradient.addColorStop(0.5, this.blendColors(primary, secondary));
        angleGradient.addColorStop(1, secondary);
        ctx.fillStyle = angleGradient;
        break;
        
      case 'vibrant':
        // Multiple color stops
        const vibrantGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
        vibrantGradient.addColorStop(0, this.lightenColor(primary, 20));
        vibrantGradient.addColorStop(0.3, primary);
        vibrantGradient.addColorStop(0.7, secondary);
        vibrantGradient.addColorStop(1, this.darkenColor(secondary, 15));
        ctx.fillStyle = vibrantGradient;
        break;
        
      case 'elegant':
        // Subtle gradient with metallic effect
        const elegantGradient = ctx.createLinearGradient(0, 0, 0, 120);
        elegantGradient.addColorStop(0, this.lightenColor(primary, 30));
        elegantGradient.addColorStop(0.5, primary);
        elegantGradient.addColorStop(1, this.darkenColor(primary, 20));
        ctx.fillStyle = elegantGradient;
        break;
        
      default:
        // Standard radial gradient
        const standardGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
        standardGradient.addColorStop(0, primary);
        standardGradient.addColorStop(1, secondary);
        ctx.fillStyle = standardGradient;
    }
    
    ctx.fillRect(0, 0, 120, 120);
  }

  // Add rank-based visual enhancements
  private static addRankEnhancements(ctx: CanvasRenderingContext2D, rank: number, seed: number) {
    ctx.globalAlpha = 0.3;
    
    switch (rank) {
      case 1:
        // Gold crown effect
        ctx.strokeStyle = '#FFD700';
        ctx.lineWidth = 3;
        for (let i = 0; i < 8; i++) {
          const angle = (i / 8) * Math.PI * 2;
          const x1 = 60 + Math.cos(angle) * 45;
          const y1 = 60 + Math.sin(angle) * 45;
          const x2 = 60 + Math.cos(angle) * 50;
          const y2 = 60 + Math.sin(angle) * 50;
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }
        break;
        
      case 2:
        // Silver shimmer
        ctx.strokeStyle = '#C0C0C0';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(60, 60, 48, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(60, 60, 52, 0, Math.PI * 2);
        ctx.stroke();
        break;
        
      case 3:
        // Bronze accent
        ctx.strokeStyle = '#CD7F32';
        ctx.lineWidth = 2;
        const sides = 6;
        ctx.beginPath();
        for (let i = 0; i < sides; i++) {
          const angle = (i / sides) * Math.PI * 2 - Math.PI / 2;
          const x = 60 + Math.cos(angle) * 50;
          const y = 60 + Math.sin(angle) * 50;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.stroke();
        break;
    }
    
    ctx.globalAlpha = 1;
  }

  // Add dynamic patterns based on background pattern type
  private static addDynamicPattern(ctx: CanvasRenderingContext2D, pattern: string, seed: number, style: string) {
    ctx.globalAlpha = 0.15;
    ctx.strokeStyle = '#FFFFFF';
    ctx.fillStyle = '#FFFFFF';
    ctx.lineWidth = 1.5;
    
    const centerX = 60, centerY = 60;
    const variation = seed % 10;
    
    switch (pattern) {
      case 'circles':
        for (let i = 0; i < 4; i++) {
          const radius = 15 + (i * 8) + (variation * 2);
          ctx.beginPath();
          ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
          ctx.stroke();
        }
        break;
        
      case 'waves':
        for (let y = 20; y < 100; y += 15) {
          ctx.beginPath();
          for (let x = 0; x <= 120; x += 2) {
            const waveY = y + Math.sin((x + variation * 10) * 0.1) * 8;
            if (x === 0) ctx.moveTo(x, waveY);
            else ctx.lineTo(x, waveY);
          }
          ctx.stroke();
        }
        break;
        
      case 'triangles':
        const triangleSize = 12 + (variation * 2);
        for (let i = 0; i < 6; i++) {
          const angle = (i / 6) * Math.PI * 2;
          const x = centerX + Math.cos(angle) * 30;
          const y = centerY + Math.sin(angle) * 30;
          this.drawTriangle(ctx, x, y, triangleSize);
        }
        break;
        
      case 'hexagons':
        this.drawHexagon(ctx, centerX, centerY, 25 + variation);
        this.drawHexagon(ctx, centerX, centerY, 35 + variation);
        break;
        
      case 'diamonds':
        for (let i = 0; i < 8; i++) {
          const angle = (i / 8) * Math.PI * 2;
          const x = centerX + Math.cos(angle) * (25 + variation * 2);
          const y = centerY + Math.sin(angle) * (25 + variation * 2);
          this.drawDiamond(ctx, x, y, 8);
        }
        break;
        
      case 'dots':
        for (let i = 0; i < 12; i++) {
          const angle = (i / 12) * Math.PI * 2;
          const radius = 30 + (variation * 3);
          const x = centerX + Math.cos(angle) * radius;
          const y = centerY + Math.sin(angle) * radius;
          ctx.beginPath();
          ctx.arc(x, y, 3, 0, Math.PI * 2);
          ctx.fill();
        }
        break;
        
      case 'lines':
        for (let i = 0; i < 12; i++) {
          const angle = (i / 12) * Math.PI * 2;
          const x1 = centerX + Math.cos(angle) * 20;
          const y1 = centerY + Math.sin(angle) * 20;
          const x2 = centerX + Math.cos(angle) * (40 + variation * 2);
          const y2 = centerY + Math.sin(angle) * (40 + variation * 2);
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }
        break;
        
      case 'spiral':
        ctx.beginPath();
        let angle = 0;
        let radius = 5;
        ctx.moveTo(centerX + radius, centerY);
        while (radius < 45) {
          angle += 0.3;
          radius += 0.5;
          const x = centerX + Math.cos(angle) * radius;
          const y = centerY + Math.sin(angle) * radius;
          ctx.lineTo(x, y);
        }
        ctx.stroke();
        break;
    }
    
    ctx.globalAlpha = 1;
  }

  // Add styled initials with dynamic effects
  private static addStyledInitials(ctx: CanvasRenderingContext2D, userName: string, userRank?: number, style?: string) {
    const initials = this.getInitials(userName);
    
    // Rank-based text styling
    if (userRank && userRank <= 3) {
      ctx.shadowColor = 'rgba(0,0,0,0.3)';
      ctx.shadowBlur = 4;
      ctx.shadowOffsetY = 2;
      
      switch (userRank) {
        case 1:
          ctx.fillStyle = '#FFFFFF';
          ctx.strokeStyle = '#FFD700';
          ctx.lineWidth = 2;
          break;
        case 2:
          ctx.fillStyle = '#FFFFFF';
          ctx.strokeStyle = '#C0C0C0';
          ctx.lineWidth = 1.5;
          break;
        case 3:
          ctx.fillStyle = '#FFFFFF';
          ctx.strokeStyle = '#CD7F32';
          ctx.lineWidth = 1.5;
          break;
      }
    } else {
      ctx.fillStyle = '#FFFFFF';
      ctx.shadowColor = 'rgba(0,0,0,0.2)';
      ctx.shadowBlur = 2;
      ctx.shadowOffsetY = 1;
    }

    // Dynamic font size based on initials length
    const fontSize = initials.length === 1 ? 36 : 32;
    ctx.font = `bold ${fontSize}px Arial, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    // Add text with stroke for top ranks
    if (userRank && userRank <= 3) {
      ctx.strokeText(initials, 60, 60);
    }
    ctx.fillText(initials, 60, 60);
    
    // Reset shadow
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;
  }

  // Add subtle highlight effects
  private static addHighlightEffects(ctx: CanvasRenderingContext2D, seed: number, userRank?: number) {
    ctx.globalAlpha = 0.2;
    
    // Add subtle rim light
    const gradient = ctx.createRadialGradient(60, 60, 50, 60, 60, 58);
    gradient.addColorStop(0, 'transparent');
    gradient.addColorStop(1, '#FFFFFF');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 120, 120);
    
    // Add sparkle effects for top ranks
    if (userRank && userRank <= 3) {
      ctx.fillStyle = '#FFFFFF';
      for (let i = 0; i < 5; i++) {
        const angle = (seed + i) * 0.5;
        const distance = 35 + (i * 5);
        const x = 60 + Math.cos(angle) * distance;
        const y = 60 + Math.sin(angle) * distance;
        this.drawStar(ctx, x, y, 2);
      }
    }
    
    ctx.globalAlpha = 1;
  }

  // Helper function to get string hash for consistent randomization
  private static getStringHash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }

  // Color manipulation utilities
  private static lightenColor(color: string, percent: number): string {
    const rgb = this.hexToRgb(color);
    if (!rgb) return color;
    
    const factor = 1 + (percent / 100);
    return `rgb(${Math.min(255, Math.round(rgb.r * factor))}, ${Math.min(255, Math.round(rgb.g * factor))}, ${Math.min(255, Math.round(rgb.b * factor))})`;
  }

  private static darkenColor(color: string, percent: number): string {
    const rgb = this.hexToRgb(color);
    if (!rgb) return color;
    
    const factor = 1 - (percent / 100);
    return `rgb(${Math.round(rgb.r * factor)}, ${Math.round(rgb.g * factor)}, ${Math.round(rgb.b * factor)})`;
  }

  private static blendColors(color1: string, color2: string): string {
    const rgb1 = this.hexToRgb(color1);
    const rgb2 = this.hexToRgb(color2);
    if (!rgb1 || !rgb2) return color1;
    
    return `rgb(${Math.round((rgb1.r + rgb2.r) / 2)}, ${Math.round((rgb1.g + rgb2.g) / 2)}, ${Math.round((rgb1.b + rgb2.b) / 2)})`;
  }

  private static hexToRgb(hex: string): {r: number, g: number, b: number} | null {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  }

  // Geometric shape helpers
  private static drawTriangle(ctx: CanvasRenderingContext2D, x: number, y: number, size: number) {
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x - size, y + size);
    ctx.lineTo(x + size, y + size);
    ctx.closePath();
    ctx.stroke();
  }

  private static drawHexagon(ctx: CanvasRenderingContext2D, x: number, y: number, size: number) {
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2 - Math.PI / 2;
      const px = x + Math.cos(angle) * size;
      const py = y + Math.sin(angle) * size;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.stroke();
  }

  private static drawDiamond(ctx: CanvasRenderingContext2D, x: number, y: number, size: number) {
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x + size, y);
    ctx.lineTo(x, y + size);
    ctx.lineTo(x - size, y);
    ctx.closePath();
    ctx.stroke();
  }

  private static drawStar(ctx: CanvasRenderingContext2D, x: number, y: number, size: number) {
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const angle = (i / 5) * Math.PI * 2 - Math.PI / 2;
      const px = x + Math.cos(angle) * size;
      const py = y + Math.sin(angle) * size;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
      
      const innerAngle = ((i + 0.5) / 5) * Math.PI * 2 - Math.PI / 2;
      const innerPx = x + Math.cos(innerAngle) * (size * 0.4);
      const innerPy = y + Math.sin(innerAngle) * (size * 0.4);
      ctx.lineTo(innerPx, innerPy);
    }
    ctx.closePath();
    ctx.fill();
  }

  private static addPattern(ctx: CanvasRenderingContext2D, patternIndex: number, userId: number) {
    ctx.globalAlpha = 0.3;
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;

    switch (patternIndex) {
      case 0: // Geometric circles
        for (let i = 0; i < 3; i++) {
          const radius = 15 + (i * 10);
          ctx.beginPath();
          ctx.arc(60, 60, radius, 0, Math.PI * 2);
          ctx.stroke();
        }
        break;
      
      case 1: // Abstract lines
        for (let i = 0; i < 5; i++) {
          const angle = (userId + i) * 0.5;
          ctx.beginPath();
          ctx.moveTo(60 + Math.cos(angle) * 20, 60 + Math.sin(angle) * 20);
          ctx.lineTo(60 + Math.cos(angle + 0.5) * 40, 60 + Math.sin(angle + 0.5) * 40);
          ctx.stroke();
        }
        break;
      
      case 2: // Minimal squares
        const size = 15;
        ctx.strokeRect(60 - size, 60 - size, size * 2, size * 2);
        ctx.strokeRect(60 - size/2, 60 - size/2, size, size);
        break;
      
      case 3: // Gradient overlay (already applied)
        break;
      
      case 4: // Artistic curves
        ctx.beginPath();
        ctx.arc(40, 40, 20, 0, Math.PI);
        ctx.arc(80, 80, 20, Math.PI, Math.PI * 2);
        ctx.stroke();
        break;
    }
    
    ctx.globalAlpha = 1;
  }

  private static getInitials(name: string): string {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .slice(0, 2)
      .join('')
      .toUpperCase();
  }

  private static getFallbackAvatar(userName: string, userRank?: number): string {
    // Enhanced SVG fallback with dynamic features
    const initials = this.getInitials(userName);
    const nameHash = this.getStringHash(userName);
    const gradientIndex = nameHash % this.gradientPairs.length;
    const [primaryColor, secondaryColor] = this.gradientPairs[gradientIndex];
    
    // Rank-based enhancements
    const rankEnhancement = userRank && userRank <= 3 ? 
      `<circle cx="60" cy="60" r="52" fill="none" stroke="${
        userRank === 1 ? '#FFD700' : userRank === 2 ? '#C0C0C0' : '#CD7F32'
      }" stroke-width="2" opacity="0.7"/>` : '';
    
    const sparkles = userRank && userRank <= 3 ? 
      `<text x="45" y="35" font-size="12" fill="white" opacity="0.8">✨</text>
       <text x="75" y="40" font-size="10" fill="white" opacity="0.6">⭐</text>
       <text x="40" y="85" font-size="8" fill="white" opacity="0.7">✨</text>` : '';
    
    const svg = `
      <svg width="120" height="120" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="grad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" style="stop-color:${primaryColor};stop-opacity:1" />
            <stop offset="100%" style="stop-color:${secondaryColor};stop-opacity:1" />
          </radialGradient>
          <filter id="shadow">
            <feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity="0.3"/>
          </filter>
        </defs>
        <circle cx="60" cy="60" r="60" fill="url(#grad)" />
        ${rankEnhancement}
        <text x="60" y="60" font-family="Arial" font-size="32" font-weight="bold" 
              text-anchor="middle" dominant-baseline="central" fill="white" filter="url(#shadow)">
          ${initials}
        </text>
        ${sparkles}
      </svg>
    `;
    
    return `data:image/svg+xml;base64,${btoa(svg)}`;
  }

  // Generate reward item images
  static generateRewardImage(rewardTitle: string, category: string): string {
    const canvas = document.createElement('canvas');
    canvas.width = 200;
    canvas.height = 150;
    const ctx = canvas.getContext('2d');

    if (!ctx) return this.getFallbackRewardImage(rewardTitle, category);

    // Category-based colors and icons
    const categoryConfig = this.getRewardCategoryConfig(category);
    
    // Create gradient background
    const gradient = ctx.createLinearGradient(0, 0, 200, 150);
    gradient.addColorStop(0, categoryConfig.primaryColor);
    gradient.addColorStop(1, categoryConfig.secondaryColor);
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 200, 150);

    // Add subtle pattern
    ctx.globalAlpha = 0.1;
    ctx.fillStyle = '#FFFFFF';
    for (let i = 0; i < 10; i++) {
      for (let j = 0; j < 8; j++) {
        if ((i + j) % 2 === 0) {
          ctx.fillRect(i * 20, j * 18, 10, 9);
        }
      }
    }
    ctx.globalAlpha = 1;

    // Add category icon
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 40px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(categoryConfig.icon, 100, 60);

    // Add title
    ctx.font = 'bold 14px Arial';
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    const words = rewardTitle.split(' ');
    const maxWidth = 180;
    let y = 110;
    
    if (words.length <= 2) {
      ctx.fillText(rewardTitle, 100, y);
    } else {
      const line1 = words.slice(0, 2).join(' ');
      const line2 = words.slice(2).join(' ');
      ctx.fillText(line1, 100, y - 8);
      ctx.fillText(line2, 100, y + 8);
    }

    return canvas.toDataURL('image/png');
  }

  private static getRewardCategoryConfig(category: string) {
    const configs = {
      safety: {
        primaryColor: '#FF6B6B',
        secondaryColor: '#FF8E8E',
        icon: '🦺'
      },
      emergency: {
        primaryColor: '#E74C3C',
        secondaryColor: '#F1948A',
        icon: '🚨'
      },
      education: {
        primaryColor: '#3498DB',
        secondaryColor: '#85C1E9',
        icon: '📚'
      },
      tools: {
        primaryColor: '#2ECC71',
        secondaryColor: '#82E5AA',
        icon: '🔧'
      },
      default: {
        primaryColor: '#9B59B6',
        secondaryColor: '#BB8FCE',
        icon: '🎁'
      }
    };

    return configs[category as keyof typeof configs] || configs.default;
  }

  private static getFallbackRewardImage(title: string, category: string): string {
    const config = this.getRewardCategoryConfig(category);
    const svg = `
      <svg width="200" height="150" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="rewardGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:${config.primaryColor};stop-opacity:1" />
            <stop offset="100%" style="stop-color:${config.secondaryColor};stop-opacity:1" />
          </linearGradient>
        </defs>
        <rect width="200" height="150" fill="url(#rewardGrad)" />
        <text x="100" y="60" font-family="Arial" font-size="40" text-anchor="middle" fill="white">
          ${config.icon}
        </text>
        <text x="100" y="110" font-family="Arial" font-size="14" font-weight="bold" 
              text-anchor="middle" fill="white">
          ${title.length > 20 ? title.substring(0, 20) + '...' : title}
        </text>
      </svg>
    `;
    
    return `data:image/svg+xml;base64,${btoa(svg)}`;
  }
}

// Export singleton instance
export const profileImageGenerator = ProfileImageGenerator;