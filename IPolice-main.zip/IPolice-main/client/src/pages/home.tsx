import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import TopHUD from "@/components/layout/top-hud";
import BottomNavigation from "@/components/layout/bottom-navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Camera, 
  FileText, 
  Gift, 
  Trophy, 
  MapPin, 
  CheckCircle, 
  Clock,
  ArrowRight,
  Image,
  RotateCcw,
  Check,
  X,
  AlertTriangle,
  Navigation,
  Send
} from "lucide-react";
import { Link } from "wouter";
import { profileImageGenerator } from "@/lib/profile-images";
import { cordovaCamera } from "@/lib/cordova-camera";

// Mock current user ID for demo
const CURRENT_USER_ID = 1;

// Report form schema
const reportSchema = z.object({
  description: z.string().min(10, "Description must be at least 10 characters"),
  location: z.string().min(3, "Location is required"),
  coordinates: z.string().optional(),
  violationType: z.string().min(1, "Violation type is required"),
});

type ReportFormData = z.infer<typeof reportSchema>;
type ReportStep = 'selection' | 'camera' | 'preview' | 'form';

export default function Home() {
  // Report overlay states
  const [showReportOverlay, setShowReportOverlay] = useState<boolean>(false);
  const [currentStep, setCurrentStep] = useState<ReportStep>('selection');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<string>('');
  const [userCoordinates, setUserCoordinates] = useState<string>('');
  const [currentTime, setCurrentTime] = useState<string>('');
  const [showAllActivities, setShowAllActivities] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Report form
  const form = useForm<ReportFormData>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      description: "",
      location: userLocation,
      coordinates: userCoordinates,
      violationType: "",
    },
  });

  const { data: userStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/users", CURRENT_USER_ID, "stats"],
  });

  const { data: user, isLoading: isLoadingUser, refetch: refetchUser } = useQuery({
    queryKey: ["/api/users", CURRENT_USER_ID],
    refetchOnMount: 'always',
    refetchOnWindowFocus: true,
  });

  const { data: leaderboard, isLoading: isLoadingLeaderboard } = useQuery({
    queryKey: ["/api/leaderboard"],
    queryFn: () => fetch("/api/leaderboard?limit=10").then(res => res.json()),
  });

  const { data: rewards, isLoading: isLoadingRewards } = useQuery({
    queryKey: ["/api/rewards"],
  });

  const { data: activities, isLoading: isLoadingActivities } = useQuery({
    queryKey: ["/api/activities/user", CURRENT_USER_ID, showAllActivities ? 'all' : 'limited'],
    queryFn: () => fetch(`/api/activities/user/${CURRENT_USER_ID}?limit=${showAllActivities ? 10 : 3}`).then(res => res.json()),
  });

  // Report submission mutation
  const createReportMutation = useMutation({
    mutationFn: async (data: ReportFormData) => {
      const formData = new FormData();
      formData.append("title", "Traffic Violation Report");
      formData.append("description", data.description);
      formData.append("location", data.location);
      if (data.coordinates) {
        formData.append("coordinates", data.coordinates);
      }
      formData.append("violationType", data.violationType);
      formData.append("userId", CURRENT_USER_ID.toString());
      
      if (selectedFile) {
        formData.append("media", selectedFile);
      }

      const response = await fetch("/api/reports", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to submit report");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Report Submitted!",
        description: "Your violation report has been submitted for review. You'll earn points once verified.",
      });
      
      // Reset form and overlay state
      form.reset();
      setSelectedFile(null);
      setCapturedImage(null);
      setShowReportOverlay(false);
      setCurrentStep('selection');
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID, "stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Failed to submit report. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Bengaluru coordinate boundaries and areas
  const BENGALURU_BOUNDS = {
    north: 13.1394, // North boundary
    south: 12.7348, // South boundary  
    east: 77.8746,  // East boundary
    west: 77.4106   // West boundary
  };

  const BENGALURU_AREAS = [
    'Koramangala, Bengaluru',
    'Indiranagar, Bengaluru', 
    'Whitefield, Bengaluru',
    'Electronic City, Bengaluru',
    'Marathahalli, Bengaluru',
    'HSR Layout, Bengaluru',
    'BTM Layout, Bengaluru',
    'Jayanagar, Bengaluru',
    'Rajajinagar, Bengaluru',
    'Malleshwaram, Bengaluru',
    'Yelahanka, Bengaluru',
    'Sarjapur Road, Bengaluru',
    'Bannerghatta Road, Bengaluru',
    'Hebbal, Bengaluru',
    'JP Nagar, Bengaluru',
    'Kengeri, Bengaluru',
    'Majestic, Bengaluru',
    'MG Road, Bengaluru',
    'Brigade Road, Bengaluru',
    'Commercial Street, Bengaluru'
  ];

  const isLocationInBengaluru = (lat: number, lng: number): boolean => {
    return lat >= BENGALURU_BOUNDS.south && 
           lat <= BENGALURU_BOUNDS.north && 
           lng >= BENGALURU_BOUNDS.west && 
           lng <= BENGALURU_BOUNDS.east;
  };

  const getBengaluruAreaFromCoordinates = (lat: number, lng: number): string => {
    // Map coordinate ranges to specific Bengaluru areas for better accuracy
    if (lat >= 12.9200 && lat <= 12.9800 && lng >= 77.6000 && lng <= 77.6500) {
      return 'Koramangala, Bengaluru';
    } else if (lat >= 12.9600 && lat <= 13.0200 && lng >= 77.6200 && lng <= 77.6800) {
      return 'Indiranagar, Bengaluru';
    } else if (lat >= 12.9400 && lat <= 13.0000 && lng >= 77.7000 && lng <= 77.7600) {
      return 'Whitefield, Bengaluru';
    } else if (lat >= 12.8400 && lat <= 12.8800 && lng >= 77.6500 && lng <= 77.7000) {
      return 'Electronic City, Bengaluru';
    } else if (lat >= 12.9400 && lat <= 12.9800 && lng >= 77.6800 && lng <= 77.7300) {
      return 'Marathahalli, Bengaluru';
    } else if (lat >= 12.9000 && lat <= 12.9400 && lng >= 77.6300 && lng <= 77.6800) {
      return 'HSR Layout, Bengaluru';
    } else {
      // Fallback to random Bengaluru area if coordinates don't match specific ranges
      return BENGALURU_AREAS[Math.floor(Math.random() * BENGALURU_AREAS.length)];
    }
  };

  // Camera and location functions
  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          
          // Check if location is within Bengaluru boundaries
          if (isLocationInBengaluru(latitude, longitude)) {
            setUserCoordinates(`${latitude.toFixed(6)},${longitude.toFixed(6)}`);
            
            // Get specific Bengaluru area based on coordinates
            const bengaluruArea = getBengaluruAreaFromCoordinates(latitude, longitude);
            setUserLocation(bengaluruArea);
            
            toast({
              title: "Location Captured",
              description: `Location detected in ${bengaluruArea}`,
            });
          } else {
            // Location is outside Bengaluru
            const defaultArea = 'Koramangala, Bengaluru';
            const defaultCoords = '12.935000,77.625000';
            setUserLocation(defaultArea);
            setUserCoordinates(defaultCoords);
            
            toast({
              title: "Location Restricted",
              description: "iPolice is available only in Bengaluru. Using default location.",
              variant: "destructive",
            });
          }
        },
        (error) => {
          console.error("Error getting location:", error);
          
          // Fallback to default Bengaluru location
          const defaultArea = 'Koramangala, Bengaluru';
          const defaultCoords = '12.935000,77.625000';
          setUserLocation(defaultArea);
          setUserCoordinates(defaultCoords);
          
          toast({
            title: "Location Access Required",
            description: "Using default Bengaluru location. You can update it manually.",
          });
        }
      );
    }
  };

  const startCamera = async () => {
    try {
      // Use Cordova camera for APK, web camera for development
      const imageData = await cordovaCamera.capturePhoto();
      
      if (imageData) {
        // Set the captured image directly without conversion for now
        setCapturedImage(imageData);
        setCurrentStep('form');
        
        // Create a simple blob from base64 for file submission
        try {
          const base64Data = imageData.split(',')[1] || imageData;
          const byteCharacters = atob(base64Data);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          const blob = new Blob([byteArray], { type: 'image/jpeg' });
          const file = new File([blob], 'evidence.jpg', { type: 'image/jpeg' });
          setSelectedFile(file);
        } catch (conversionError) {
          console.warn("Direct file conversion failed, using base64 string:", conversionError);
          // Create a minimal file-like object for form submission
          const mockFile = new File([''], 'evidence.jpg', { type: 'image/jpeg' });
          setSelectedFile(mockFile);
        }
        
        toast({
          title: "Photo Captured",
          description: "Photo captured successfully. Add details to submit your report.",
        });
      } else {
        throw new Error('No image data received');
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      toast({
        title: "Camera Error",
        description: "Could not access camera. Please try selecting a photo instead.",
        variant: "destructive",
      });
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext('2d');
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context?.drawImage(video, 0, 0);
      
      canvas.toBlob((blob) => {
        if (blob) {
          const file = new File([blob], 'evidence.jpg', { type: 'image/jpeg' });
          setSelectedFile(file);
          setCapturedImage(canvas.toDataURL());
          setCurrentStep('form');
          
          // Stop camera stream
          const stream = video.srcObject as MediaStream;
          stream?.getTracks().forEach(track => track.stop());
        }
      }, 'image/jpeg', 0.8);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setCurrentStep('form');
    }
  };

  const selectFromGallery = async () => {
    try {
      const imageData = await cordovaCamera.selectPhoto();
      
      // Convert to File object for form submission
      const response = await fetch(imageData);
      const blob = await response.blob();
      const file = new File([blob], 'evidence.jpg', { type: 'image/jpeg' });
      
      setSelectedFile(file);
      setCapturedImage(imageData);
      setCurrentStep('form');
      
      toast({
        title: "Photo Selected",
        description: "Photo selected from gallery. Add details to submit your report.",
      });
    } catch (error) {
      console.error("Error selecting from gallery:", error);
      toast({
        title: "Gallery Error",
        description: "Could not select photo from gallery.",
        variant: "destructive",
      });
    }
  };

  const onSubmit = (data: ReportFormData) => {
    createReportMutation.mutate(data);
  };

  const violationTypes = [
    { value: "parking", label: "Illegal Parking" },
    { value: "signal", label: "Signal Violation" },
    { value: "speeding", label: "Over Speeding" },
    { value: "lane", label: "Wrong Lane" },
    { value: "helmet", label: "No Helmet" },
    { value: "seatbelt", label: "No Seatbelt" },
    { value: "phone", label: "Phone Usage" },
    { value: "other", label: "Other" },
  ];

  if (isLoadingUser || isLoadingStats) {
    return (
      <div className="min-h-screen bg-gray-50">
        <TopHUD />
        <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
          <div className="animate-pulse space-y-4 p-4">
            <div className="h-32 bg-gray-200 rounded-lg"></div>
            <div className="h-48 bg-gray-200 rounded-lg"></div>
            <div className="h-32 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
        <BottomNavigation />
      </div>
    );
  }

  const progressPercentage = userStats ? 
    (((userStats as any).points % 500) / 500) * 100 : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <TopHUD />
      
      <main className="max-w-md mx-auto bg-white min-h-screen pb-20">
        {/* User Welcome Section with Arc Design */}
        <section className="relative overflow-hidden bg-gradient-to-br from-[var(--police-blue)] via-blue-600 to-indigo-700">
          {/* Content */}
          <div className="relative px-4 py-6 pb-12">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <img
                    src={(user as any)?.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100"}
                    alt="User profile"
                    className="w-12 h-12 rounded-full border-2 border-white shadow-lg"
                  />
                  <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-green-400 rounded-full border-2 border-white"></div>
                </div>
                <div>
                  <h2 className="font-bold text-lg text-white">{(user as any)?.name || "User"}</h2>
                  <p className="text-blue-100 text-sm">Level {(userStats as any)?.level || 1} Contributor</p>
                </div>
              </div>
              <div className="bg-white/15 backdrop-blur-sm rounded-xl p-2 text-center">
                <div className="text-lg font-bold text-white">#{(userStats as any)?.rank || 0}</div>
                <div className="text-xs text-blue-200">Rank</div>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-center">
                <div className="text-xl font-bold text-white">{(userStats as any)?.points || 0}</div>
                <div className="text-xs text-blue-200">Points</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-center">
                <div className="text-xl font-bold text-white">{(userStats as any)?.verifiedReports || 0}</div>
                <div className="text-xs text-blue-200">Verified</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-center">
                <div className="text-xl font-bold text-white">{(userStats as any)?.totalReports || 0}</div>
                <div className="text-xs text-blue-200">Reports</div>
              </div>
            </div>
          </div>
          
          {/* Outward Arc Bottom using SVG */}
          <div className="absolute bottom-0 left-0 w-full overflow-hidden">
            <svg 
              viewBox="0 0 400 50" 
              className="w-full h-8"
              preserveAspectRatio="none"
            >
              <path 
                d="M0,0 Q200,40 400,0 L400,50 L0,50 Z" 
                fill="white"
              />
            </svg>
          </div>
        </section>

        {/* Compact Progress Section */}
        <section className="px-4 py-4">
          <Card className="border border-gray-100 shadow-sm bg-gradient-to-r from-blue-50 to-indigo-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-semibold text-gray-800">Progress to Level {((userStats as any)?.level || 1) + 1}</h3>
                <span className="text-sm text-[var(--police-blue)] font-medium">
                  {(userStats as any)?.points || 0} / {(((userStats as any)?.level || 1) + 1) * 500}
                </span>
              </div>
              <Progress value={progressPercentage} className="h-3 mb-2" />
              <p className="text-xs text-gray-600">
                {(userStats as any)?.pointsToNextLevel || 500} points to next level
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Quick Actions */}
        <section className="px-4 pb-6">
          <h3 className="text-base font-semibold text-gray-800 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            {/* Primary Action - Report */}
            <Card 
              className="bg-gradient-to-r from-blue-500 to-indigo-600 border-0 hover:shadow-lg transition-all cursor-pointer transform hover:scale-[1.02] active:scale-95"
              onClick={() => setShowReportOverlay(true)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                      <Camera className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-white text-lg">Report Violation</div>
                      <div className="text-blue-100 text-sm">Capture evidence now</div>
                    </div>
                  </div>
                  <ArrowRight className="h-5 w-5 text-white/70" />
                </div>
              </CardContent>
            </Card>
            
            {/* Secondary Actions Grid */}
            <div className="grid grid-cols-3 gap-3">
              <Link href="/view-reports">
                <Card className="bg-white border border-gray-200 hover:shadow-md transition-all cursor-pointer hover:border-blue-300">
                  <CardContent className="p-3 text-center">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <FileText className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="font-medium text-gray-800 text-sm">Reports</div>
                    <div className="text-xs text-gray-500">{(userStats as any)?.totalReports || 0} total</div>
                  </CardContent>
                </Card>
              </Link>
              
              <Link href="/rewards">
                <Card className="bg-white border border-gray-200 hover:shadow-md transition-all cursor-pointer hover:border-purple-300">
                  <CardContent className="p-3 text-center">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <Gift className="h-5 w-5 text-purple-600" />
                    </div>
                    <div className="font-medium text-gray-800 text-sm">Rewards</div>
                    <div className="text-xs text-gray-500">{(userStats as any)?.points || 0} pts</div>
                  </CardContent>
                </Card>
              </Link>
              
              <Link href="/rewards">
                <Card className="bg-white border border-gray-200 hover:shadow-md transition-all cursor-pointer hover:border-orange-300">
                  <CardContent className="p-3 text-center">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <Trophy className="h-5 w-5 text-orange-600" />
                    </div>
                    <div className="font-medium text-gray-800 text-sm">Rank</div>
                    <div className="text-xs text-gray-500">#{(userStats as any)?.rank || 0}</div>
                  </CardContent>
                </Card>
              </Link>
            </div>
          </div>
        </section>

        {/* Top Contributors */}
        <section className="px-4 pb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-semibold text-gray-800">Top Contributors</h3>
            <Link href="/rewards#leaderboard">
              <Button variant="ghost" size="sm" className="text-[var(--police-blue)] p-0 text-sm">
                Leaderboard
              </Button>
            </Link>
          </div>
          
          <Card className="border border-gray-100 shadow-sm">
            <CardContent className="p-0">
              {isLoadingLeaderboard ? (
                <div className="h-56 overflow-hidden">
                  {[1, 2, 3, 4].map((i) => (
                    <div 
                      key={i} 
                      className="animate-pulse flex items-center space-x-3 p-3 border-b border-gray-100"
                      style={{ opacity: i === 4 ? 0.5 : 1 }}
                    >
                      <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                      <div className="h-4 bg-gray-200 rounded w-16"></div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="max-h-56 overflow-y-scroll scroll-smooth scrollbar-hide">
                  {leaderboard?.slice(0, 8).map((contributor: any, index: number) => (
                    <div 
                      key={contributor.id} 
                      className="flex items-center justify-between p-3 border-b border-gray-100 last:border-b-0"
                      style={{ opacity: index === 3 ? 0.7 : 1 }}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <img
                            src={profileImageGenerator.generateProfileImage(contributor.id, contributor.name, index + 1)}
                            alt={contributor.name}
                            className="w-10 h-10 rounded-full border border-gray-200"
                          />
                          <div className={`absolute -top-1 -right-1 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold ${
                            index === 0 ? 'bg-[var(--warning)]' : 
                            index === 1 ? 'bg-gray-400' : 'bg-orange-500'
                          }`}>
                            {index + 1}
                          </div>
                        </div>
                        <div>
                          <div className="font-medium text-gray-800 text-sm">{contributor.name}</div>
                          <div className="text-xs text-gray-500">{contributor.location}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-[var(--police-blue)] text-sm">{contributor.points}</div>
                        <div className="text-xs text-gray-500">{contributor.reportCount || 0} reports</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </section>

        {/* Rewards Store Snippets */}
        <section className="px-4 pb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Rewards Store</h3>
            <Link href="/rewards">
              <Button variant="ghost" size="sm" className="text-[var(--police-blue)] p-0">
                View Store
              </Button>
            </Link>
          </div>
          
          <div className="flex space-x-3 overflow-x-auto pb-2 pr-4 scrollbar-hide">
            {isLoadingRewards ? (
              [1, 2, 3, 4].map((i) => (
                <div 
                  key={i} 
                  className="flex-shrink-0 w-28 animate-pulse"
                  style={{ opacity: i === 4 ? 0.5 : 1 }}
                >
                  <div className="bg-gray-200 rounded-xl h-32"></div>
                </div>
              ))
            ) : (
              (rewards as any)?.slice(0, 5).map((reward: any, index: number) => (
                <Card 
                  key={reward.id} 
                  className="flex-shrink-0 w-28 shadow-md border border-gray-100 hover:shadow-lg transition-all cursor-pointer"
                  style={{ opacity: index >= 3 ? (index === 3 ? 0.7 : 0.4) : 1 }}
                >
                  <CardContent className="p-2">
                    <img
                      src={profileImageGenerator.generateRewardImage(reward.name, reward.category)}
                      alt={reward.name}
                      className="w-full h-14 object-cover rounded-lg mb-2"
                    />
                    <div className="text-xs font-medium text-gray-800 line-clamp-1">{reward.name}</div>
                    <div className="text-xs text-[var(--police-blue)] font-semibold">
                      {reward.pointsCost} pts
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </section>

        {/* Recent Activity */}
        <section className="px-4 pb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-gray-800">Recent Activity</h3>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-[var(--police-blue)] p-0 text-sm"
              onClick={() => setShowAllActivities(!showAllActivities)}
            >
              {showAllActivities ? 'Show Less' : 'View All Activity'}
            </Button>
          </div>
          
          <div className={`space-y-3 transition-all duration-300 ${showAllActivities ? 'max-h-96 overflow-y-auto' : ''}`}>
            {isLoadingActivities ? (
              Array.from({ length: showAllActivities ? 6 : 3 }, (_, i) => (
                <Card key={i} className="shadow-sm border border-gray-100">
                  <CardContent className="p-3">
                    <div className="animate-pulse flex space-x-3">
                      <div className="w-8 h-8 bg-gray-200 rounded-lg"></div>
                      <div className="flex-1">
                        <div className="h-3 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-1"></div>
                        <div className="h-2 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              activities?.map((activity: any) => {
                const getActivityIcon = (type: string) => {
                  switch (type) {
                    case 'report_verified':
                      return { icon: CheckCircle, color: 'bg-[var(--success)]' };
                    case 'report_submitted':
                      return { icon: Clock, color: 'bg-[var(--warning)]' };
                    case 'rank_achieved':
                      return { icon: Trophy, color: 'bg-purple-600' };
                    default:
                      return { icon: CheckCircle, color: 'bg-gray-500' };
                  }
                };

                const { icon: Icon, color } = getActivityIcon(activity.type);
                const timeAgo = new Date(activity.createdAt).toLocaleString();

                return (
                  <Card key={activity.id} className="shadow-sm border border-gray-100">
                    <CardContent className="p-3">
                      <div className="flex items-start space-x-3">
                        <div className={`w-8 h-8 ${color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                          <Icon className="h-3 w-3 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-gray-800">{activity.title}</span>
                            <span className="text-xs text-gray-500">{timeAgo}</span>
                          </div>
                          <p className="text-xs text-gray-600 mb-2">{activity.description}</p>
                          <div className="flex items-center space-x-4 text-xs">
                            {activity.points > 0 && (
                              <span className="text-[var(--success)] font-medium">+{activity.points} points</span>
                            )}
                            {activity.metadata && JSON.parse(activity.metadata).location && (
                              <span className="text-gray-500">{JSON.parse(activity.metadata).location}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        </section>
      </main>

      {/* Report Bottom Sheet Overlay */}
      {showReportOverlay && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end justify-center"
          onClick={() => setShowReportOverlay(false)}
        >
          <div 
            className="w-full max-w-md mx-4 bg-white rounded-t-3xl shadow-2xl animate-in slide-in-from-bottom duration-300 ease-out"
            style={{ paddingBottom: 'calc(6rem + env(safe-area-inset-bottom))' }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Handle Bar */}
            <div className="flex justify-center pt-3 pb-2">
              <div className="w-12 h-1.5 bg-gray-300 rounded-full"></div>
            </div>
            
            <div className="px-6 pb-8">
              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">
                  Add Evidence
                </h3>
                <p className="text-sm text-gray-600">
                  Choose how to provide evidence for your report
                </p>
              </div>
              
              <div className="space-y-4">
                <Button
                  onClick={() => {
                    setShowReportOverlay(false);
                    // Navigate to camera functionality
                    window.location.href = '/report';
                  }}
                  className="w-full h-20 text-lg bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 hover:from-blue-600 hover:via-blue-700 hover:to-indigo-700 text-white flex items-center justify-between px-8 shadow-xl rounded-2xl transform hover:scale-[1.02] transition-all duration-200 border border-blue-400/20"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <Camera className="h-6 w-6 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold">Open Camera</div>
                      <div className="text-xs text-blue-100 opacity-90">Capture live evidence</div>
                    </div>
                  </div>
                  <div className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </Button>
                
                <Button
                  onClick={() => {
                    setShowReportOverlay(false);
                    // Navigate to gallery functionality
                    window.location.href = '/report';
                  }}
                  variant="outline"
                  className="w-full h-20 text-lg border-2 border-purple-300/40 bg-gradient-to-br from-purple-50 via-purple-100 to-pink-50 hover:from-purple-100 hover:via-purple-150 hover:to-pink-100 text-purple-800 flex items-center justify-between px-8 rounded-2xl transform hover:scale-[1.02] transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-200/60 rounded-full flex items-center justify-center">
                      <Image className="h-6 w-6 text-purple-700" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold text-purple-800">Open Gallery</div>
                      <div className="text-xs text-purple-600 opacity-80">Select existing photos</div>
                    </div>
                  </div>
                  <div className="w-8 h-8 bg-purple-200/40 rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-purple-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </Button>
                
                <Button
                  onClick={() => setShowReportOverlay(false)}
                  variant="ghost"
                  className="w-full h-12 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-xl"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <BottomNavigation onReportClick={() => setShowReportOverlay(true)} />
    </div>
  );
}
