import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Shield, Smartphone } from 'lucide-react';

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendOtp = async () => {
    if (!phoneNumber || phoneNumber.length !== 10) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid 10-digit mobile number",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      setIsLoading(false);
      setStep('otp');
      toast({
        title: "OTP Sent!",
        description: `Verification code sent to +91 ${phoneNumber}`,
      });
    }, 1500);
  };

  const handleVerifyOtp = async () => {
    if (!otp || otp.length !== 6) {
      toast({
        title: "Invalid OTP",
        description: "Please enter the 6-digit OTP sent to your phone",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    
    // Store user session data
    localStorage.setItem('userSession', JSON.stringify({
      phone: phoneNumber,
      loginTime: new Date().toISOString()
    }));
    
    // Simulate verification delay
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Login Successful!",
        description: "Welcome to iPolice! Redirecting to dashboard...",
      });
      
      // Redirect to dashboard after successful verification
      setTimeout(() => {
        setLocation('/dashboard');
      }, 1000);
    }, 1000);
  };

  const handleBackToPhone = () => {
    setStep('phone');
    setOtp('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 flex items-center justify-center relative overflow-hidden">
      {/* Mobile-safe container with proper padding */}
      <div className="w-full max-w-sm mx-auto px-4 py-6 space-y-4 sm:space-y-6 relative z-10">
        {/* Header - Mobile responsive */}
        <div className="text-center space-y-3">
          <div className="w-14 h-14 sm:w-16 sm:h-16 mx-auto bg-white rounded-full flex items-center justify-center shadow-lg">
            <Shield className="w-7 h-7 sm:w-8 sm:h-8 text-blue-600" />
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-white">Welcome to iPolice</h1>
          <p className="text-sm sm:text-base text-blue-100">
            Secure login with mobile verification
          </p>
        </div>

        {/* Login Card - Mobile optimized */}
        <Card className="shadow-2xl border-0 w-full">
          <CardHeader className="text-center pb-3 px-4 sm:px-6">
            <CardTitle className="text-lg sm:text-xl flex items-center justify-center gap-2">
              <Smartphone className="w-4 h-4 sm:w-5 sm:h-5" />
              {step === 'phone' ? 'Enter Mobile Number' : 'Verify OTP'}
            </CardTitle>
            <CardDescription className="text-sm">
              {step === 'phone' 
                ? 'We\'ll send you a verification code' 
                : `Code sent to +91 ${phoneNumber}`
              }
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4 px-4 sm:px-6">
            {step === 'phone' ? (
              <>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-sm font-medium">Mobile Number</Label>
                  <div className="flex w-full">
                    <div className="flex items-center bg-gray-50 border border-r-0 border-gray-300 rounded-l-md px-3 text-sm text-gray-600 shrink-0">
                      +91
                    </div>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="Enter 10-digit number"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      className="rounded-l-none flex-1 text-base h-10"
                      maxLength={10}
                    />
                  </div>
                </div>
                
                <Button 
                  onClick={handleSendOtp}
                  disabled={isLoading || phoneNumber.length !== 10}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Sending OTP...
                    </div>
                  ) : (
                    'Send OTP'
                  )}
                </Button>
              </>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="otp" className="text-sm font-medium">Enter 6-Digit OTP</Label>
                  <Input
                    id="otp"
                    type="text"
                    placeholder="000000"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className="text-center text-lg tracking-widest h-12"
                    maxLength={6}
                  />
                  <p className="text-xs text-gray-500 text-center">
                    Enter the 6-digit code sent to your mobile number
                  </p>
                </div>

                <div className="space-y-3">
                  <Button 
                    onClick={handleVerifyOtp}
                    disabled={isLoading || otp.length !== 6}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        Verifying...
                      </div>
                    ) : (
                      'Verify OTP'
                    )}
                  </Button>

                  <Button 
                    variant="ghost" 
                    onClick={handleBackToPhone}
                    className="w-full text-gray-600 hover:text-gray-800"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Change Number
                  </Button>
                </div>

                <div className="text-center">
                  <p className="text-sm text-gray-500">
                    Didn't receive the code?{' '}
                    <button 
                      onClick={handleSendOtp}
                      className="text-blue-600 hover:text-blue-700 font-medium"
                    >
                      Resend OTP
                    </button>
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-blue-200/80">
          <p>Secure • Fast • Reliable</p>
          <p className="text-xs mt-1">Powered by Bengaluru Traffic Police</p>
        </div>
      </div>
    </div>
  );
}