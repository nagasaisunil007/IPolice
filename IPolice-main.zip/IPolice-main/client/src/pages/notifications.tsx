import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import TopHUD from "@/components/layout/top-hud";
import BottomNavigation from "@/components/layout/bottom-navigation";
import EvidencePopup from "@/components/shared/evidence-popup";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Bell, 
  CheckCircle, 
  AlertTriangle, 
  Award, 
  MessageCircle,
  ArrowLeft,
  Clock,
  Trash2,
  Circle
} from "lucide-react";

interface Notification {
  id: number;
  title: string;
  message: string;
  type: 'report_verified' | 'report_rejected' | 'reward_earned' | 'system' | 'achievement';
  isRead: boolean;
  createdAt: string;
  data?: any;
}

export default function Notifications() {
  const [, setLocation] = useLocation();
  const [showEvidencePopup, setShowEvidencePopup] = useState(false);
  const { toast } = useToast();

  // Mock notifications data - in real app this would come from API
  const notifications: Notification[] = [
    {
      id: 1,
      title: "Report Verified!",
      message: "Your illegal parking report has been verified and you earned 15 points!",
      type: "report_verified",
      isRead: false,
      createdAt: "2025-01-21T10:30:00Z"
    },
    {
      id: 2,
      title: "New Achievement Unlocked",
      message: "Congratulations! You've reached Level 3 - Community Guardian",
      type: "achievement",
      isRead: false,
      createdAt: "2025-01-21T09:15:00Z"
    },
    {
      id: 3,
      title: "Reward Available",
      message: "You have enough points to redeem a Reflective Vest! Visit the rewards store.",
      type: "reward_earned",
      isRead: true,
      createdAt: "2025-01-20T16:45:00Z"
    },
    {
      id: 4,
      title: "Report Under Review",
      message: "Your traffic violation report is being reviewed by authorities.",
      type: "system",
      isRead: true,
      createdAt: "2025-01-20T14:20:00Z"
    },
    {
      id: 5,
      title: "Report Rejected",
      message: "Your noise pollution report was rejected due to insufficient evidence.",
      type: "report_rejected",
      isRead: true,
      createdAt: "2025-01-19T11:30:00Z"
    }
  ];

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'report_verified':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'report_rejected':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'reward_earned':
      case 'achievement':
        return <Award className="h-5 w-5 text-yellow-500" />;
      default:
        return <Bell className="h-5 w-5 text-blue-500" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'report_verified':
        return "border-l-green-500 bg-green-50";
      case 'report_rejected':
        return "border-l-red-500 bg-red-50";
      case 'reward_earned':
      case 'achievement':
        return "border-l-yellow-500 bg-yellow-50";
      default:
        return "border-l-blue-500 bg-blue-50";
    }
  };

  const markAsRead = (id: number) => {
    toast({
      title: "Marked as Read",
      description: "Notification marked as read",
    });
  };

  const deleteNotification = (id: number) => {
    toast({
      title: "Notification Deleted",
      description: "Notification has been removed",
    });
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d ago`;
    return date.toLocaleDateString();
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100">
      <TopHUD />
      
      <main className="max-w-md mx-auto bg-white min-h-screen pb-20 shadow-xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-[var(--police-blue)] to-blue-600 text-white px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20 p-2"
                onClick={() => setLocation('/dashboard')}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Notifications</h1>
                <p className="text-blue-100 text-sm">Stay updated on your reports</p>
              </div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 flex items-center space-x-2">
              <Bell className="h-6 w-6" />
              {unreadCount > 0 && (
                <Badge className="bg-red-500 text-white text-xs px-2 py-1">
                  {unreadCount}
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="px-4 -mt-4 mb-6">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-4">
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center">
                <div className="text-xl font-bold text-gray-800">{notifications.length}</div>
                <div className="text-xs text-gray-500 flex items-center justify-center">
                  <Bell className="h-3 w-3 mr-1 text-blue-500" />
                  Total
                </div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-red-600">{unreadCount}</div>
                <div className="text-xs text-gray-500 flex items-center justify-center">
                  <Circle className="h-3 w-3 mr-1 text-red-500" />
                  Unread
                </div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-green-600">
                  {notifications.filter(n => n.type === 'report_verified').length}
                </div>
                <div className="text-xs text-gray-500 flex items-center justify-center">
                  <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                  Verified
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Notifications List */}
        <div className="px-4 space-y-3">
          {notifications.length === 0 ? (
            <Card className="bg-gradient-to-br from-gray-50 to-gray-100 border-2 border-dashed border-gray-300">
              <CardContent className="p-8 text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bell className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">No notifications</h3>
                <p className="text-gray-600">You're all caught up! New notifications will appear here.</p>
              </CardContent>
            </Card>
          ) : (
            notifications.map((notification) => (
              <Card 
                key={notification.id} 
                className={`shadow-md hover:shadow-lg transition-all duration-200 border-l-4 ${getNotificationColor(notification.type)} ${
                  !notification.isRead ? 'ring-2 ring-blue-100' : ''
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 mt-1">
                      {getNotificationIcon(notification.type)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className={`text-sm font-semibold ${!notification.isRead ? 'text-gray-900' : 'text-gray-700'}`}>
                            {notification.title}
                          </h3>
                          <p className={`text-sm mt-1 ${!notification.isRead ? 'text-gray-700' : 'text-gray-600'}`}>
                            {notification.message}
                          </p>
                          <div className="flex items-center space-x-4 mt-2">
                            <div className="flex items-center text-xs text-gray-500">
                              <Clock className="h-3 w-3 mr-1" />
                              {formatTimeAgo(notification.createdAt)}
                            </div>
                            {!notification.isRead && (
                              <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                                New
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col space-y-1">
                      {!notification.isRead && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="p-1 h-8 w-8"
                          onClick={() => markAsRead(notification.id)}
                        >
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-1 h-8 w-8"
                        onClick={() => deleteNotification(notification.id)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Action Buttons */}
        {notifications.length > 0 && (
          <div className="px-4 pt-6 pb-4">
            <div className="flex space-x-3">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => toast({ title: "Marked All as Read", description: "All notifications marked as read" })}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Mark All Read
              </Button>
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => toast({ title: "All Cleared", description: "All notifications deleted" })}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All
              </Button>
            </div>
          </div>
        )}
      </main>

      <BottomNavigation onEvidenceClick={() => setShowEvidencePopup(true)} />
      {showEvidencePopup && <EvidencePopup isOpen={showEvidencePopup} onClose={() => setShowEvidencePopup(false)} />}
    </div>
  );
}