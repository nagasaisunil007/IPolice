import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import TopHUD from "@/components/layout/top-hud";
import BottomNavigation from "@/components/layout/bottom-navigation";
import EvidencePopup from "@/components/shared/evidence-popup";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { 
  User, 
  MapPin, 
  Star, 
  Trophy, 
  FileText, 
  CheckCircle, 
  Clock,
  Settings,
  LogOut,
  Edit,
  Camera,
  Award,
  TrendingUp,
  Shield,
  Bell,
  Lock,
  HelpCircle,
  MessageSquare,
  Smartphone,
  Eye,
  Download,
  Trash2,
  ExternalLink
} from "lucide-react";
import type { User as UserType, Report } from "@shared/types";
import { mobileStorage } from "@/lib/mobile-storage";
import { mobileFileManager } from "@/lib/mobile-camera";

// Mock current user ID
const CURRENT_USER_ID = 1;

type UserStats = {
  totalReports: number;
  verifiedReports: number;
  pendingReports: number;
  points: number;
  rank: number;
  level: number;
  pointsToNextLevel: number;
};

// Profile edit form schema
const profileEditSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  location: z.string().min(3, "Location must be at least 3 characters"),
});

type ProfileEditData = z.infer<typeof profileEditSchema>;

export default function Profile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [showEvidencePopup, setShowEvidencePopup] = useState(false);
  
  // Settings state
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(false);
  const [reportStatusUpdates, setReportStatusUpdates] = useState(true);
  const [publicProfile, setPublicProfile] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);
  const [activityVisibility, setActivityVisibility] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [language, setLanguage] = useState('English');
  const [autoSync, setAutoSync] = useState(true);
  
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ["/api/users", CURRENT_USER_ID],
    queryFn: () => mobileStorage.getUser(CURRENT_USER_ID),
  });

  // Profile edit form
  const profileForm = useForm<ProfileEditData>({
    resolver: zodResolver(profileEditSchema),
    defaultValues: {
      name: user?.name || "",
      location: user?.location || "",
    },
  });

  const { data: userStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/users", CURRENT_USER_ID, "stats"],
    queryFn: () => mobileStorage.getUserStats(CURRENT_USER_ID),
  });

  const { data: reports, isLoading: isLoadingReports } = useQuery({
    queryKey: ["/api/reports/user", CURRENT_USER_ID],
    queryFn: () => mobileStorage.getUserReports(CURRENT_USER_ID),
  });

  const { data: activities } = useQuery({
    queryKey: ["/api/activities/user", CURRENT_USER_ID],
    queryFn: () => mobileStorage.getUserActivities(CURRENT_USER_ID),
  });

  // Profile update mutation using mobile storage
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileEditData) => {
      const updatedUser = await mobileStorage.updateUser(CURRENT_USER_ID, {
        name: data.name,
        location: data.location,
      });
      return updatedUser;
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your profile has been successfully updated.",
      });
      setIsEditProfileOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID, "stats"] });
    },
    onError: (error) => {
      console.error('Profile update error:', error);
      toast({
        title: "Update Failed",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Initialize settings from localStorage on component mount
  useState(() => {
    if (typeof window !== 'undefined') {
      setDarkMode(localStorage.getItem('darkMode') === 'true');
      setLanguage(localStorage.getItem('language') || 'English');
      setAutoSync(localStorage.getItem('autoSync') !== 'false');
    }
  });

  // Update form default values when user data loads
  if (user && !profileForm.getValues().name) {
    profileForm.reset({
      name: user.name,
      location: user.location,
    });
  }

  // Handler functions
  const handleEditProfile = () => {
    setIsEditProfileOpen(true);
  };

  const handleSettings = () => {
    setIsSettingsOpen(true);
  };

  const handleSignOut = () => {
    // Clear user session data
    localStorage.removeItem('userSession');
    localStorage.removeItem('user');
    sessionStorage.clear();
    
    toast({
      title: "Signed out successfully",
      description: "You have been logged out. Redirecting to login...",
    });
    
    // Navigate to login page with delay
    setTimeout(() => {
      setLocation("/login");
    }, 1500);
  };

  const handleContactSupport = () => {
    toast({
      title: "Support Contact",
      description: "support@ipolice.com",
    });
  };

  const onProfileSubmit = (data: ProfileEditData) => {
    updateProfileMutation.mutate(data);
  };

  // Settings handlers
  const handlePushNotifications = (enabled: boolean) => {
    setPushNotifications(enabled);
    if (enabled) {
      // Request notification permission
      if ('Notification' in window) {
        Notification.requestPermission().then(permission => {
          if (permission === 'granted') {
            toast({
              title: "Push Notifications Enabled",
              description: "You'll now receive push notifications for important updates.",
            });
          } else {
            toast({
              title: "Permission Denied",
              description: "Please enable notifications in your browser settings.",
              variant: "destructive",
            });
            setPushNotifications(false);
          }
        });
      }
    } else {
      toast({
        title: "Push Notifications Disabled",
        description: "You'll no longer receive push notifications.",
      });
    }
  };

  const handleEmailNotifications = (enabled: boolean) => {
    setEmailNotifications(enabled);
    toast({
      title: enabled ? "Email Notifications Enabled" : "Email Notifications Disabled",
      description: enabled 
        ? "You'll receive important updates via email." 
        : "Email notifications have been turned off.",
    });
  };

  const handleReportStatusUpdates = (enabled: boolean) => {
    setReportStatusUpdates(enabled);
    toast({
      title: enabled ? "Report Status Updates Enabled" : "Report Status Updates Disabled",
      description: enabled 
        ? "You'll be notified when your reports are verified or updated." 
        : "Report status notifications have been turned off.",
    });
  };

  const handlePublicProfile = (enabled: boolean) => {
    setPublicProfile(enabled);
    toast({
      title: enabled ? "Public Profile Enabled" : "Public Profile Disabled",
      description: enabled 
        ? "Your profile will be visible on the leaderboard." 
        : "Your profile is now private and hidden from leaderboard.",
    });
  };

  const handleLocationSharing = (enabled: boolean) => {
    setLocationSharing(enabled);
    toast({
      title: enabled ? "Location Sharing Enabled" : "Location Sharing Disabled",
      description: enabled 
        ? "Your location will be shared with reports for better accuracy." 
        : "Location will not be shared with your reports.",
    });
  };

  const handleActivityVisibility = (enabled: boolean) => {
    setActivityVisibility(enabled);
    toast({
      title: enabled ? "Activity Visibility Enabled" : "Activity Visibility Disabled",
      description: enabled 
        ? "Your activities will be visible to other users." 
        : "Your activities are now private.",
    });
  };

  const handleTwoFactorAuth = () => {
    toast({
      title: "Two-Factor Authentication",
      description: "Setting up 2FA... This feature will be available soon with SMS verification.",
    });
  };

  const handleChangePassword = () => {
    toast({
      title: "Change Password",
      description: "Password change feature will be available soon. Contact support for assistance.",
    });
  };

  const handleDataExport = () => {
    // Simulate data export
    const exportData = {
      user: user,
      reports: reports,
      activities: activities,
      exportDate: new Date().toISOString(),
    };
    
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `ipolice-data-export-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    toast({
      title: "Data Export Complete",
      description: "Your data has been downloaded as a JSON file.",
    });
  };

  const handleDarkMode = (enabled: boolean) => {
    setDarkMode(enabled);
    if (enabled) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'false');
    }
    toast({
      title: enabled ? "Dark Mode Enabled" : "Dark Mode Disabled",
      description: enabled ? "App switched to dark theme." : "App switched to light theme.",
    });
  };

  const handleLanguageChange = (newLanguage: string) => {
    setLanguage(newLanguage);
    localStorage.setItem('language', newLanguage);
    toast({
      title: "Language Changed",
      description: `App language changed to ${newLanguage}. Restart the app to see changes.`,
    });
  };

  const handleAutoSync = (enabled: boolean) => {
    setAutoSync(enabled);
    localStorage.setItem('autoSync', enabled.toString());
    toast({
      title: enabled ? "Auto-Sync Enabled" : "Auto-Sync Disabled",
      description: enabled 
        ? "Data will sync automatically in the background." 
        : "Manual sync required for data updates.",
    });
  };

  const handleDeleteAccount = () => {
    const confirmed = window.confirm(
      "Are you sure you want to delete your account? This action cannot be undone and will permanently delete all your data including reports, activities, and profile information."
    );
    
    if (confirmed) {
      toast({
        title: "Account Deletion Requested",
        description: "Your account deletion request has been submitted. You'll receive a confirmation email within 24 hours.",
        variant: "destructive",
      });
    }
  };

  const handleAbout = () => {
    toast({
      title: "iPolice Bengaluru v2.1.0",
      description: "Empowering civic engagement and traffic safety in Bengaluru. Built with ❤️ for the community.",
    });
  };

  const handleProfilePictureChange = async () => {
    try {
      // Use mobile file manager for enhanced file picking
      const file = await mobileFileManager.pickFile('image/*');
      if (file) {
        try {
          // Update profile picture using mobile storage
          const profilePictureUrl = await mobileStorage.updateProfilePicture(CURRENT_USER_ID, file);
          
          toast({
            title: "Profile Picture Updated",
            description: "Your profile picture has been successfully updated.",
          });

          // Refresh user data to show new profile picture
          queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID] });
        } catch (error) {
          console.error('Error uploading profile picture:', error);
          toast({
            title: "Upload Failed",
            description: "Failed to update profile picture. Please try again.",
            variant: "destructive",
          });
        }
      }
    } catch (error) {
      console.error('Error accessing file picker:', error);
      toast({
        title: "File Access Error",
        description: "Unable to access file picker. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoadingUser || isLoadingStats || isLoadingReports) {
    return (
      <div className="min-h-screen bg-gray-50">
        <TopHUD />
        <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
          <div className="animate-pulse space-y-4 p-4">
            <div className="h-32 bg-gray-200 rounded-lg"></div>
            <div className="h-48 bg-gray-200 rounded-lg"></div>
            <div className="h-32 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
        <BottomNavigation onEvidenceClick={() => setShowEvidencePopup(true)} />
      </div>
    );
  }

  const progressPercentage = userStats ? 
    ((userStats.points % 500) / 500) * 100 : 0;

  const achievements = [
    {
      id: 1,
      title: "First Reporter",
      description: "Submitted your first violation report",
      icon: FileText,
      earned: true,
      date: "2024-01-15",
    },
    {
      id: 2,
      title: "Verified Contributor",
      description: "Had 2+ reports verified",
      icon: CheckCircle,
      earned: (userStats?.verifiedReports ?? 0) >= 2,
      date: (userStats?.verifiedReports ?? 0) >= 2 ? "2024-02-20" : null,
    },
    {
      id: 3,
      title: "Top 50 Contributor",
      description: "Reached top 50 in leaderboard",
      icon: Trophy,
      earned: (user?.rank || 999) <= 50,
      date: (user?.rank || 999) <= 50 ? "2024-03-10" : null,
    },
    {
      id: 4,
      title: "Safety Champion",
      description: "Earned 1000+ reward points",
      icon: Award,
      earned: (userStats?.points || 0) >= 1000,
      date: (userStats?.points || 0) >= 1000 ? "2024-03-25" : null,
    },
    {
      id: 5,
      title: "Community Guardian",
      description: "Submit 5+ violation reports",
      icon: Shield,
      earned: (userStats?.totalReports ?? 0) >= 5,
      date: (userStats?.totalReports ?? 0) >= 5 ? "2024-04-01" : null,
    },
    {
      id: 6,
      title: "Rapid Responder",
      description: "Submit 3 reports in one day",
      icon: TrendingUp,
      earned: false,
      date: null,
    },
    {
      id: 7,
      title: "Top 10 Elite",
      description: "Reach top 10 in leaderboard",
      icon: Star,
      earned: (user?.rank || 999) <= 10,
      date: (user?.rank || 999) <= 10 ? "2024-04-15" : null,
    },
    {
      id: 8,
      title: "Consistency King",
      description: "Report violations for 7 days straight",
      icon: Award,
      earned: false,
      date: null,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <TopHUD />
      
      <main className="max-w-md mx-auto bg-white min-h-screen pb-20">
        {/* Profile Header with Plain Background */}
        <section className="bg-[var(--police-blue)] text-white px-4 py-6 pb-8 relative overflow-hidden">
          <div className="text-center">
            <div className="relative inline-block mb-3">
              <div className="relative w-20 h-20">
                <img
                  src={user?.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100"}
                  alt="Profile"
                  className="w-full h-full rounded-full object-cover border-4 border-white shadow-lg"
                /></div>
              <Button 
                size="sm" 
                onClick={handleProfilePictureChange}
                className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-white text-[var(--police-blue)] hover:bg-gray-100 p-0 shadow-lg border-2 border-white"
              >
                <Camera className="h-3.5 w-3.5" />
              </Button>
            </div>
            <h1 className="text-xl font-semibold mb-1">{user?.name || "Loading..."}</h1>
            <p className="text-white/80 text-sm flex items-center justify-center mb-4">
              <MapPin className="h-4 w-4 mr-1" />
              {user?.location}
            </p>
            
            {/* Stats Row */}
            <div className="flex justify-center space-x-8 mt-4">
              <div className="text-center">
                <div className="text-xl font-bold text-white">{userStats?.points || 0}</div>
                <div className="text-xs text-white/80">Points</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-white">#{user?.rank || 0}</div>
                <div className="text-xs text-white/80">Rank</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-white">{user?.level || 1}</div>
                <div className="text-xs text-white/80">Level</div>
              </div>
            </div>
          </div>
        </section>

        <div className="px-4 pt-4 pb-6 space-y-6">
          {/* Enhanced Progress Card with Icons */}
          <Card className="border border-gray-200 shadow-sm bg-gradient-to-br from-gray-50 to-white">
            <CardContent className="p-4">
              <div className="space-y-4">
                {/* Modern Progress Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="flex items-center space-x-1 text-[var(--police-blue)]">
                      <TrendingUp className="h-4 w-4" />
                      <span className="text-sm font-semibold">Next - Level {(user?.level || 1) + 1}</span>
                    </div>
                  </div>
                  <div className="text-sm font-medium text-gray-600">
                    {userStats?.points || 0} / {((user?.level || 1) + 1) * 500}
                  </div>
                </div>
                
                {/* Modern Progress Bar */}
                <div className="relative">
                  <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-orange-400 via-orange-500 to-red-500 rounded-full transition-all duration-300 ease-out shadow-sm"
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                  {/* Subtle glow effect */}
                  <div 
                    className="absolute top-0 h-full bg-gradient-to-r from-orange-300 via-orange-400 to-red-400 rounded-full opacity-30 blur-sm transition-all duration-300"
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>
                
                {/* Progress Stats */}
                <div className="flex justify-between items-center text-xs">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <div className="w-5 h-5 rounded-full bg-[var(--police-blue)] flex items-center justify-center">
                        <Shield className="h-3 w-3 text-white" />
                      </div>
                      <span className="font-medium text-gray-700">Level {user?.level || 1}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center">
                        <Star className="h-3 w-3 text-white" />
                      </div>
                      <span className="text-gray-600">{userStats?.points || 0} points</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-5 h-5 rounded-full bg-orange-500 flex items-center justify-center">
                      <Trophy className="h-3 w-3 text-white" />
                    </div>
                    <span className="text-gray-600">{userStats?.pointsToNextLevel || 500} to next</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistics - Clean Grid */}
          <Card className="border border-gray-200 shadow-sm bg-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center text-gray-900">
                <FileText className="h-5 w-5 mr-2 text-[var(--police-blue)]" />
                Reporting Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-gray-50 rounded-lg border">
                  <div className="text-2xl font-bold text-gray-900">{userStats?.totalReports || 0}</div>
                  <div className="text-sm text-gray-600">Total Reports</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="text-2xl font-bold text-green-600">{userStats?.verifiedReports || 0}</div>
                  <div className="text-sm text-green-600">Verified</div>
                </div>
                <div className="text-center p-4 bg-amber-50 rounded-lg border border-amber-200">
                  <div className="text-2xl font-bold text-amber-600">{userStats?.pendingReports || 0}</div>
                  <div className="text-sm text-amber-600">Pending</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-2xl font-bold text-blue-600">
                    {userStats?.verifiedReports ? Math.round((userStats.verifiedReports / userStats.totalReports) * 100) : 0}%
                  </div>
                  <div className="text-sm text-blue-600">Success Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Achievements - Scrollable List */}
          <Card className="border border-gray-200 shadow-sm bg-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center justify-between text-gray-900">
                <div className="flex items-center">
                  <Award className="h-5 w-5 mr-2 text-[var(--police-blue)]" />
                  Achievements
                </div>
                <span className="text-sm text-gray-500">
                  {achievements.filter(a => a.earned).length}/{achievements.length}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-h-64 overflow-y-auto space-y-3 pr-2 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                {achievements.map((achievement) => {
                  const Icon = achievement.icon;
                  const isVerifiedContributor = achievement.id === 2;
                  
                  // Custom styling for Verified Contributor (bluish approach)
                  const bgColor = achievement.earned 
                    ? (isVerifiedContributor ? 'bg-blue-50 border-blue-200' : 'bg-green-50 border-green-200')
                    : 'bg-gray-50 border-gray-200';
                  
                  const iconBg = achievement.earned 
                    ? (isVerifiedContributor ? 'bg-[var(--police-blue)]' : 'bg-green-500')
                    : 'bg-gray-400';
                  
                  const dateColor = achievement.earned 
                    ? (isVerifiedContributor ? 'text-blue-600' : 'text-green-600')
                    : '';
                  
                  const checkIconColor = achievement.earned 
                    ? (isVerifiedContributor ? 'text-[var(--police-blue)]' : 'text-green-500')
                    : '';
                  
                  return (
                    <div 
                      key={achievement.id} 
                      className={`flex items-center space-x-3 p-3 rounded-lg border ${bgColor}`}
                    >
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${iconBg}`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-gray-800">{achievement.title}</div>
                        <div className="text-xs text-gray-600">{achievement.description}</div>
                        {achievement.earned && achievement.date && (
                          <div className={`text-xs mt-1 ${dateColor}`}>
                            Earned on {new Date(achievement.date).toLocaleDateString()}
                          </div>
                        )}
                      </div>
                      {achievement.earned && (
                        <CheckCircle className={`h-5 w-5 ${checkIconColor}`} />
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="border border-gray-200 shadow-sm bg-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center text-gray-900">
                <Clock className="h-5 w-5 mr-2 text-[var(--police-blue)]" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-h-48 overflow-y-auto space-y-3 pr-2 scrollbar-thin">
                {activities && activities.length > 0 ? (
                  activities.slice(0, 10).map((activity: any, index: number) => (
                    <div key={activity.id || index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-[var(--police-blue)] flex items-center justify-center mt-0.5">
                        {activity.type === 'report_verified' && <CheckCircle className="h-4 w-4 text-white" />}
                        {activity.type === 'report_submitted' && <FileText className="h-4 w-4 text-white" />}
                        {activity.type === 'rank_achieved' && <Trophy className="h-4 w-4 text-white" />}
                        {activity.type === 'reward_claimed' && <Award className="h-4 w-4 text-white" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm text-gray-900">{activity.title}</div>
                        <div className="text-xs text-gray-600 mt-1">{activity.description}</div>
                        <div className="text-xs text-gray-400 mt-1">
                          {new Date(activity.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                      {activity.points > 0 && (
                        <div className="text-xs text-[var(--police-blue)] font-medium">
                          +{activity.points} pts
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Clock className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                    <p>No recent activity</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Account Actions */}
          <Card className="border border-gray-200 shadow-sm bg-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center text-gray-900">
                <Settings className="h-5 w-5 mr-2 text-[var(--police-blue)]" />
                Account
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Dialog open={isEditProfileOpen} onOpenChange={setIsEditProfileOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full justify-start" onClick={handleEditProfile}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm w-[90vw] mx-auto max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Edit Profile</DialogTitle>
                      <DialogDescription>
                        Update your personal information and profile details.
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...profileForm}>
                      <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                        <FormField
                          control={profileForm.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Enter your full name" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={profileForm.control}
                          name="location"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Location</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Enter your location in Bengaluru" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="flex justify-end space-x-2">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsEditProfileOpen(false)}
                          >
                            Cancel
                          </Button>
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>

                <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full justify-start" onClick={handleSettings}>
                      <Settings className="h-4 w-4 mr-2" />
                      Settings
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm w-[90vw] mx-auto max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Settings</DialogTitle>
                      <DialogDescription>
                        Manage your app preferences, privacy settings, and account options.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-6">
                      {/* Notifications Section */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-900 border-b pb-2">Notifications</h4>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <Bell className="h-4 w-4 mr-2 text-gray-500" />
                                Push Notifications
                              </div>
                              <div className="text-xs text-gray-500">Receive notifications on your device</div>
                            </div>
                            <input 
                              type="checkbox" 
                              className="toggle flex-shrink-0" 
                              checked={pushNotifications}
                              onChange={(e) => handlePushNotifications(e.target.checked)} 
                            />
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <MessageSquare className="h-4 w-4 mr-2 text-gray-500" />
                                Email Notifications
                              </div>
                              <div className="text-xs text-gray-500">Get updates via email</div>
                            </div>
                            <input 
                              type="checkbox" 
                              className="toggle flex-shrink-0" 
                              checked={emailNotifications}
                              onChange={(e) => handleEmailNotifications(e.target.checked)} 
                            />
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <CheckCircle className="h-4 w-4 mr-2 text-gray-500" />
                                Report Status Updates
                              </div>
                              <div className="text-xs text-gray-500">Notify when reports are verified</div>
                            </div>
                            <input 
                              type="checkbox" 
                              className="toggle flex-shrink-0" 
                              checked={reportStatusUpdates}
                              onChange={(e) => handleReportStatusUpdates(e.target.checked)} 
                            />
                          </div>
                        </div>
                      </div>

                      {/* Privacy Section */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-900 border-b pb-2">Privacy</h4>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <User className="h-4 w-4 mr-2 text-gray-500" />
                                Public Profile
                              </div>
                              <div className="text-xs text-gray-500">Show your profile on leaderboard</div>
                            </div>
                            <input 
                              type="checkbox" 
                              className="toggle flex-shrink-0" 
                              checked={publicProfile}
                              onChange={(e) => handlePublicProfile(e.target.checked)} 
                            />
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <MapPin className="h-4 w-4 mr-2 text-gray-500" />
                                Location Sharing
                              </div>
                              <div className="text-xs text-gray-500">Share location with reports</div>
                            </div>
                            <input 
                              type="checkbox" 
                              className="toggle flex-shrink-0" 
                              checked={locationSharing}
                              onChange={(e) => handleLocationSharing(e.target.checked)} 
                            />
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <Eye className="h-4 w-4 mr-2 text-gray-500" />
                                Activity Visibility
                              </div>
                              <div className="text-xs text-gray-500">Show your activity to others</div>
                            </div>
                            <input 
                              type="checkbox" 
                              className="toggle flex-shrink-0" 
                              checked={activityVisibility}
                              onChange={(e) => handleActivityVisibility(e.target.checked)} 
                            />
                          </div>
                        </div>
                      </div>

                      {/* Account Section */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-900 border-b pb-2">Account</h4>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <Lock className="h-4 w-4 mr-2 text-gray-500" />
                                Two-Factor Authentication
                              </div>
                              <div className="text-xs text-gray-500">Add extra security to your account</div>
                            </div>
                            <Button size="sm" variant="outline" className="min-h-[36px] px-3" onClick={handleTwoFactorAuth}>
                              Enable
                            </Button>
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <Lock className="h-4 w-4 mr-2 text-gray-500" />
                                Change Password
                              </div>
                              <div className="text-xs text-gray-500">Update your account password</div>
                            </div>
                            <Button size="sm" variant="outline" className="min-h-[36px] px-3" onClick={handleChangePassword}>
                              Change
                            </Button>
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <Download className="h-4 w-4 mr-2 text-gray-500" />
                                Data Export
                              </div>
                              <div className="text-xs text-gray-500">Download your data</div>
                            </div>
                            <Button size="sm" variant="outline" className="min-h-[36px] px-3" onClick={handleDataExport}>
                              Export
                            </Button>
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center text-red-600">
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete Account
                              </div>
                              <div className="text-xs text-gray-500">Permanently delete your account</div>
                            </div>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="min-h-[36px] px-3 text-red-600 border-red-200 hover:bg-red-50" 
                              onClick={handleDeleteAccount}
                            >
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>

                      {/* App Preferences */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-900 border-b pb-2">App Preferences</h4>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <Eye className="h-4 w-4 mr-2 text-gray-500" />
                                Dark Mode
                              </div>
                              <div className="text-xs text-gray-500">Switch to dark theme</div>
                            </div>
                            <input 
                              type="checkbox" 
                              className="toggle flex-shrink-0" 
                              checked={darkMode}
                              onChange={(e) => handleDarkMode(e.target.checked)} 
                            />
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <ExternalLink className="h-4 w-4 mr-2 text-gray-500" />
                                Language
                              </div>
                              <div className="text-xs text-gray-500">App display language</div>
                            </div>
                            <select 
                              className="text-sm border rounded px-3 py-2 min-h-[36px] bg-white" 
                              value={language}
                              onChange={(e) => handleLanguageChange(e.target.value)}
                            >
                              <option value="English">English</option>
                              <option value="Hindi">Hindi</option>
                              <option value="Kannada">Kannada</option>
                            </select>
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <Smartphone className="h-4 w-4 mr-2 text-gray-500" />
                                Auto-sync
                              </div>
                              <div className="text-xs text-gray-500">Sync data automatically</div>
                            </div>
                            <input 
                              type="checkbox" 
                              className="toggle flex-shrink-0" 
                              checked={autoSync}
                              onChange={(e) => handleAutoSync(e.target.checked)} 
                            />
                          </div>
                        </div>
                      </div>

                      {/* Support & About Section */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-900 border-b pb-2">Support & About</h4>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <HelpCircle className="h-4 w-4 mr-2 text-gray-500" />
                                Help & FAQ
                              </div>
                              <div className="text-xs text-gray-500">Get help and find answers</div>
                            </div>
                            <Button size="sm" variant="outline" className="min-h-[36px] px-3" onClick={handleContactSupport}>
                              View
                            </Button>
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <MessageSquare className="h-4 w-4 mr-2 text-gray-500" />
                                Contact Support
                              </div>
                              <div className="text-xs text-gray-500">Get help from our team</div>
                            </div>
                            <Button size="sm" variant="outline" className="min-h-[36px] px-3" onClick={handleContactSupport}>
                              Contact
                            </Button>
                          </div>
                          <div className="flex items-center justify-between py-2">
                            <div className="flex-1 min-w-0 pr-4">
                              <div className="text-sm font-medium flex items-center">
                                <Shield className="h-4 w-4 mr-2 text-gray-500" />
                                About iPolice Bengaluru
                              </div>
                              <div className="text-xs text-gray-500">App version and info</div>
                            </div>
                            <Button size="sm" variant="outline" className="min-h-[36px] px-3" onClick={handleAbout}>
                              About
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end space-x-2 pt-4 border-t">
                        <Button variant="outline" onClick={() => setIsSettingsOpen(false)}>
                          Close
                        </Button>
                        <Button onClick={() => {
                          toast({
                            title: "Settings saved",
                            description: "Your preferences have been updated.",
                          });
                          setIsSettingsOpen(false);
                        }}>
                          Save Changes
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>

                <Button 
                  variant="outline" 
                  className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50"
                  onClick={handleSignOut}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Support */}
          <Card className="border border-gray-200 shadow-sm bg-gray-50">
            <CardContent className="p-4">
              <h3 className="font-medium text-gray-900 mb-2">Need Help?</h3>
              <p className="text-sm text-gray-600 mb-3">
                Contact our support team for assistance with the app or reporting issues.
              </p>
              <Button 
                size="sm" 
                className="bg-[var(--police-blue)] hover:bg-[var(--police-light)]"
                onClick={handleContactSupport}
              >
                Contact Support
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>

      <BottomNavigation onEvidenceClick={() => setShowEvidencePopup(true)} />
      
      <EvidencePopup 
        isOpen={showEvidencePopup} 
        onClose={() => setShowEvidencePopup(false)} 
      />
    </div>
  );
}
