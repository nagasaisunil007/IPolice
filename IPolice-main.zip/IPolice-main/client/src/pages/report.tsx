import { useState, useRef, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import TopHUD from "@/components/layout/top-hud";
import BottomNavigation from "@/components/layout/bottom-navigation";
import FileUpload from "@/components/ui/file-upload";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Send, Camera, Image, RotateCcw, Check, X, FileText, AlertTriangle, Navigation } from "lucide-react";
import { useLocation } from "wouter";
import { cordovaCamera } from "@/lib/cordova-camera";
import { firebaseRealtime } from "@/lib/firebase-realtime";

const reportSchema = z.object({
  description: z.string().min(10, "Description must be at least 10 characters"),
  location: z.string().min(3, "Location is required"),
  coordinates: z.string().optional(),
  violationType: z.string().min(1, "Violation type is required"),
});

type ReportFormData = z.infer<typeof reportSchema>;

// Mock current user ID
const CURRENT_USER_ID = 1;

type ReportStep = 'selection' | 'camera' | 'preview' | 'form';

export default function Report() {
  const [location, setLocation] = useLocation();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [currentStep, setCurrentStep] = useState<ReportStep>('selection');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<string>('');
  const [userCoordinates, setUserCoordinates] = useState<string>('');
  const [currentTime, setCurrentTime] = useState<string>('');
  const [showCameraOptions, setShowCameraOptions] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ReportFormData>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      description: "",
      location: userLocation,
      coordinates: userCoordinates,
      violationType: "",
    },
  });

  // Bengaluru coordinate boundaries and areas
  const BENGALURU_BOUNDS = {
    north: 13.1394, // North boundary
    south: 12.7348, // South boundary  
    east: 77.8746,  // East boundary
    west: 77.4106   // West boundary
  };

  const BENGALURU_AREAS = [
    'Koramangala, Bengaluru',
    'Indiranagar, Bengaluru', 
    'Whitefield, Bengaluru',
    'Electronic City, Bengaluru',
    'Marathahalli, Bengaluru',
    'HSR Layout, Bengaluru',
    'BTM Layout, Bengaluru',
    'Jayanagar, Bengaluru',
    'Rajajinagar, Bengaluru',
    'Malleshwaram, Bengaluru',
    'Yelahanka, Bengaluru',
    'Sarjapur Road, Bengaluru',
    'Bannerghatta Road, Bengaluru',
    'Hebbal, Bengaluru',
    'JP Nagar, Bengaluru',
    'Kengeri, Bengaluru',
    'Majestic, Bengaluru',
    'MG Road, Bengaluru',
    'Brigade Road, Bengaluru',
    'Commercial Street, Bengaluru',
    'Cunningham Road, Bengaluru',
    'UB City Mall, Bengaluru',
    'Forum Mall, Bengaluru',
    'Phoenix MarketCity, Bengaluru',
    'Orion Mall, Bengaluru'
  ];

  const isLocationInBengaluru = (lat: number, lng: number): boolean => {
    return lat >= BENGALURU_BOUNDS.south && 
           lat <= BENGALURU_BOUNDS.north && 
           lng >= BENGALURU_BOUNDS.west && 
           lng <= BENGALURU_BOUNDS.east;
  };

  const getBengaluruAreaFromCoordinates = (lat: number, lng: number): string => {
    // Map coordinate ranges to specific Bengaluru areas for better accuracy
    if (lat >= 12.9200 && lat <= 12.9800 && lng >= 77.6000 && lng <= 77.6500) {
      return 'Koramangala, Bengaluru';
    } else if (lat >= 12.9600 && lat <= 13.0200 && lng >= 77.6200 && lng <= 77.6800) {
      return 'Indiranagar, Bengaluru';
    } else if (lat >= 12.9400 && lat <= 13.0000 && lng >= 77.7000 && lng <= 77.7600) {
      return 'Whitefield, Bengaluru';
    } else if (lat >= 12.8400 && lat <= 12.8800 && lng >= 77.6500 && lng <= 77.7000) {
      return 'Electronic City, Bengaluru';
    } else if (lat >= 12.9400 && lat <= 12.9800 && lng >= 77.6800 && lng <= 77.7300) {
      return 'Marathahalli, Bengaluru';
    } else if (lat >= 12.9000 && lat <= 12.9400 && lng >= 77.6300 && lng <= 77.6800) {
      return 'HSR Layout, Bengaluru';
    } else {
      // Fallback to random Bengaluru area if coordinates don't match specific ranges
      return BENGALURU_AREAS[Math.floor(Math.random() * BENGALURU_AREAS.length)];
    }
  };

  // Get current location and time
  useEffect(() => {
    const getCurrentTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleString());
    };

    const getCurrentLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            
            // Check if location is within Bengaluru boundaries
            if (isLocationInBengaluru(latitude, longitude)) {
              const coordinates = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
              setUserCoordinates(coordinates);
              
              // Get specific Bengaluru area based on coordinates
              const bengaluruArea = getBengaluruAreaFromCoordinates(latitude, longitude);
              setUserLocation(bengaluruArea);
              
              toast({
                title: "Location Detected",
                description: `Location detected in ${bengaluruArea}`,
              });
            } else {
              // Location is outside Bengaluru
              toast({
                title: "Location Restricted",
                description: "iPolice is currently available only in Bengaluru. Please select a Bengaluru location manually.",
                variant: "destructive",
              });
              
              // Set default Bengaluru location
              const defaultArea = 'Koramangala, Bengaluru';
              const defaultCoords = '12.935000, 77.625000'; // Koramangala coordinates
              setUserLocation(defaultArea);
              setUserCoordinates(defaultCoords);
            }
          },
          (error) => {
            console.error('Error getting location:', error);
            
            // Fallback to default Bengaluru location
            const defaultArea = 'Koramangala, Bengaluru';
            const defaultCoords = '12.935000, 77.625000';
            setUserLocation(defaultArea);
            setUserCoordinates(defaultCoords);
            
            toast({
              title: "Location Access Required", 
              description: "Using default Bengaluru location. You can update it manually.",
              variant: "default",
            });
          }
        );
      } else {
        // Geolocation not supported - use default Bengaluru location
        const defaultArea = 'Koramangala, Bengaluru';
        const defaultCoords = '12.935000, 77.625000';
        setUserLocation(defaultArea);
        setUserCoordinates(defaultCoords);
        
        toast({
          title: "Geolocation Not Supported",
          description: "Using default Bengaluru location. You can update it manually.",
        });
      }
    };

    getCurrentTime();
    getCurrentLocation();
  }, []);

  // Update form location and coordinates when they change
  useEffect(() => {
    if (userLocation) {
      form.setValue('location', userLocation);
    }
  }, [userLocation, form]);

  useEffect(() => {
    if (userCoordinates) {
      form.setValue('coordinates', userCoordinates);
    }
  }, [userCoordinates, form]);

  const startCamera = async () => {
    try {
      console.log('Starting camera capture with Cordova...');
      const imageDataUrl = await cordovaCamera.capturePhoto();
      
      if (imageDataUrl) {
        // Set the captured image directly
        setCapturedImage(imageDataUrl);
        setCurrentStep('preview');
        
        // Create file from base64 data
        try {
          const base64Data = imageDataUrl.split(',')[1] || imageDataUrl;
          const byteCharacters = atob(base64Data);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          const blob = new Blob([byteArray], { type: 'image/jpeg' });
          const file = new File([blob], 'evidence.jpg', { type: 'image/jpeg' });
          setSelectedFile(file);
        } catch (conversionError) {
          console.warn("Direct file conversion failed, using base64 string:", conversionError);
          // Create a minimal file for form submission
          const mockFile = new File([''], 'evidence.jpg', { type: 'image/jpeg' });
          setSelectedFile(mockFile);
        }
        
        toast({
          title: "Photo Captured",
          description: "Photo captured successfully. Add details to complete your report.",
        });
      } else {
        throw new Error('No image captured');
      }
    } catch (error) {
      console.error('Camera error:', error);
      toast({
        title: "Camera Error",
        description: `Unable to capture photo: ${(error as Error).message}. Please try selecting from gallery.`,
        variant: "destructive",
      });
    }
  };

  const openGallery = async () => {
    try {
      console.log('Opening gallery with Cordova fallback...');
      const imageDataUrl = await cordovaCamera.selectPhoto();
      
      if (imageDataUrl) {
        // Set the captured image directly  
        setCapturedImage(imageDataUrl);
        setCurrentStep('preview');
        
        // Create file from base64 data
        try {
          const base64Data = imageDataUrl.split(',')[1] || imageDataUrl;
          const byteCharacters = atob(base64Data);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          const blob = new Blob([byteArray], { type: 'image/jpeg' });
          const file = new File([blob], 'evidence.jpg', { type: 'image/jpeg' });
          setSelectedFile(file);
        } catch (conversionError) {
          console.warn("File conversion failed, using base64 string:", conversionError);
          const mockFile = new File([''], 'evidence.jpg', { type: 'image/jpeg' });
          setSelectedFile(mockFile);
        }
        
        toast({
          title: "Image Selected", 
          description: "Image selected from gallery",
        });
      }
    } catch (error) {
      console.error('Gallery access error:', error);
      toast({
        title: "Gallery Error",
        description: "Unable to access gallery",
        variant: "destructive",
      });
    }
  };

  // Check URL parameters for auto-triggering camera or gallery
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const cameraParam = urlParams.get('camera');
    const galleryParam = urlParams.get('gallery');
    
    if (cameraParam === 'true') {
      // Auto-start camera
      startCamera();
      // Clear URL parameters
      window.history.replaceState({}, '', '/report');
    } else if (galleryParam === 'true') {
      // Check if file was selected from gallery
      const fileData = sessionStorage.getItem('selectedFile');
      if (fileData) {
        try {
          const { name, type, data } = JSON.parse(fileData);
          // Convert base64 back to file
          fetch(data)
            .then(res => res.blob())
            .then(blob => {
              const file = new File([blob], name, { type });
              setSelectedFile(file);
              setCurrentStep('form');
            });
          // Clear session storage
          sessionStorage.removeItem('selectedFile');
        } catch (error) {
          console.error('Error processing gallery file:', error);
        }
      } else {
        // Fallback: open gallery if no file in session storage
        setTimeout(() => openGallery(), 100);
      }
      // Clear URL parameters
      window.history.replaceState({}, '', '/report');
    }
  }, []);

  // Auto-show overlay when on report page and no file selected
  useEffect(() => {
    if (currentStep === 'selection' && !selectedFile) {
      const timer = setTimeout(() => {
        setShowCameraOptions(true);
      }, 500); // Small delay for better UX
      return () => clearTimeout(timer);
    }
  }, [currentStep, selectedFile]);

  const selectFromGallery = async () => {
    try {
      console.log('Selecting photo from gallery...');
      const imageDataUrl = await cordovaCamera.selectPhoto();
      
      if (imageDataUrl) {
        // Convert to File object for form submission
        const response = await fetch(imageDataUrl);
        const blob = await response.blob();
        const file = new File([blob], 'evidence.jpg', { type: 'image/jpeg' });
        
        setSelectedFile(file);
        setCapturedImage(imageDataUrl);
        setCurrentStep('preview');
        
        toast({
          title: "Photo Selected",
          description: "Photo selected from gallery. Add details to complete your report.",
        });
      } else {
        throw new Error('No image selected');
      }
    } catch (error) {
      console.error('Gallery selection error:', error);
      toast({
        title: "Gallery Error",
        description: `Unable to select photo: ${(error as Error).message}`,
        variant: "destructive",
      });
    }
  };

  const retakePhoto = () => {
    setCapturedImage(null);
    startCamera();
  };

  const usePhoto = async () => {
    if (capturedImage) {
      try {
        // Use mobile file manager to convert base64 to file
        const file = await mobileFileManager.base64ToFile(capturedImage, `violation-${Date.now()}.jpg`);
        setSelectedFile(file);
        setCurrentStep('form');
      } catch (error) {
        console.error('Error converting captured image:', error);
        toast({
          title: "Image Error",
          description: "Failed to process captured image. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        // Compress image for mobile storage
        const compressedFile = await mobileFileManager.compressImage(file);
        setSelectedFile(compressedFile);
        setCurrentStep('form');
      } catch (error) {
        console.error('Error processing selected file:', error);
        // Use original file if compression fails
        setSelectedFile(file);
        setCurrentStep('form');
      }
    }
  };

  const goBack = () => {
    if (currentStep === 'camera') {
      // Stop camera stream using mobile file manager
      const stream = videoRef.current?.srcObject as MediaStream;
      mobileFileManager.stopCameraStream(stream);
    }
    setCurrentStep('selection');
    setCapturedImage(null);
    setSelectedFile(null);
  };

  const createReportMutation = useMutation({
    mutationFn: async (data: ReportFormData) => {
      // Process media file for Firebase storage
      let mediaUrl = '';
      let mediaType = '';
      
      if (selectedFile) {
        try {
          // Compress image for mobile storage
          const compressedFile = await mobileFileManager.compressImage(selectedFile);
          // Convert to base64 for Firebase storage
          const base64Data = await mobileFileManager.fileToBase64(compressedFile);
          mediaUrl = base64Data;
          mediaType = compressedFile.type.startsWith('image/') ? 'image' : 'video';
        } catch (error) {
          console.warn('Failed to process media file:', error);
        }
      }

      // Use Firebase Realtime Database instead of mobile storage
      const report = await firebaseRealtime.createReport({
        title: "Traffic Violation Report Details",
        description: data.description,
        location: data.location,
        coordinates: data.coordinates,
        violationType: data.violationType,
        userId: CURRENT_USER_ID,
        mediaUrl,
        mediaType,
        verificationStatus: 'pending',
        timestamp: new Date().toISOString(),
        status: 'pending',
      });
      
      return report;
    },
    onSuccess: () => {
      toast({
        title: "Report Submitted",
        description: "Your violation report has been saved successfully.",
      });
      
      // Invalidate and refetch relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID, "stats"] });
      
      // Reset form and navigate to view reports
      form.reset();
      setSelectedFile(null);
      setCapturedImage(null);
      setCurrentStep('selection');
      setLocation("/view-reports");
    },
    onError: (error) => {
      console.error('Report submission error:', error);
      toast({
        title: "Error",
        description: "Failed to submit report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ReportFormData) => {
    createReportMutation.mutate(data);
  };

  const violationTypes = [
    { value: "parking", label: "Illegal Parking" },
    { value: "signal", label: "Signal Violation" },
    { value: "speeding", label: "Over Speeding" },
    { value: "lane", label: "Wrong Lane" },
    { value: "helmet", label: "No Helmet" },
    { value: "seatbelt", label: "No Seatbelt" },
    { value: "phone", label: "Phone Usage" },
    { value: "other", label: "Other" },
  ];

  // Render different steps
  const renderSelection = () => (
    <div className="px-4 py-6 flex flex-col justify-center items-center min-h-[calc(100vh-160px)]">
      <div className="text-center py-8">
        <AlertTriangle className="h-24 w-24 mx-auto text-red-500 mb-6" />
        <h1 className="text-2xl font-bold text-gray-800 mb-3">Report Traffic Violation</h1>
        <p className="text-gray-600 text-lg mb-2">Help make Bengaluru roads safer</p>
        <p className="text-gray-500 text-sm">Available only for Bengaluru locations</p>
      </div>
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );

  const renderCamera = () => (
    <div className="relative h-screen bg-black">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="w-full h-full object-cover"
        onLoadedMetadata={() => {
          console.log('Video metadata loaded');
        }}
        onError={(e) => {
          console.error('Video error:', e);
          toast({
            title: "Video Error",
            description: "There was an issue with the camera feed.",
            variant: "destructive",
          });
        }}
      />
      <canvas ref={canvasRef} className="hidden" />
      
      {/* Camera Overlay */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Top overlay */}
        <div className="bg-black/30 text-white p-4 text-center">
          <p className="text-sm">Position the violation in the frame and tap to capture</p>
        </div>
      </div>
      
      {/* Camera Controls */}
      <div className="absolute bottom-8 left-0 right-0 flex justify-center items-center space-x-6">
        <Button
          onClick={goBack}
          variant="outline"
          size="lg"
          className="bg-white/90 border-white text-gray-800 hover:bg-white pointer-events-auto"
        >
          <X className="h-5 w-5" />
        </Button>
        
        <Button
          onClick={capturePhoto}
          size="lg"
          className="w-16 h-16 rounded-full bg-white border-4 border-gray-300 hover:bg-gray-100 pointer-events-auto shadow-xl"
        >
          <div className="w-12 h-12 rounded-full bg-white border-2 border-gray-400"></div>
        </Button>
        
        <Button
          onClick={() => {
            // Switch camera if available
            toast({
              title: "Camera Switch",
              description: "Camera switching not available in this device.",
            });
          }}
          variant="outline"
          size="lg"
          className="bg-white/90 border-white text-gray-800 hover:bg-white pointer-events-auto"
        >
          <RotateCcw className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );

  const renderPreview = () => (
    <div className="relative h-screen">
      {capturedImage && (
        <img
          src={capturedImage}
          alt="Captured"
          className="w-full h-full object-cover"
        />
      )}
      
      {/* Preview Controls */}
      <div className="absolute bottom-8 left-0 right-0 flex justify-center items-center space-x-6">
        <Button
          onClick={retakePhoto}
          variant="outline"
          size="lg"
          className="bg-white/90 border-white text-gray-800 hover:bg-white flex items-center space-x-2"
        >
          <RotateCcw className="h-5 w-5" />
          <span>Retake</span>
        </Button>
        
        <Button
          onClick={usePhoto}
          size="lg"
          className="bg-[#115cc5] hover:bg-[#0d4a9f] text-white flex items-center space-x-2"
        >
          <Check className="h-5 w-5" />
          <span>Use Photo</span>
        </Button>
      </div>
    </div>
  );

  const renderForm = () => (
    <div className="px-4 py-6">
      <Card className="border border-gray-100 shadow-md">
        <CardHeader className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-t-lg">
          <CardTitle className="text-xl font-semibold flex items-center">
            <FileText className="h-6 w-6 mr-2" />
            Report Details
          </CardTitle>
          {currentTime && (
            <p className="text-green-100">Time: {currentTime}</p>
          )}
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Evidence Thumbnail */}
              {selectedFile && (
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-700">Evidence</label>
                  <div className="relative">
                    {selectedFile.type.startsWith('image/') ? (
                      <img
                        src={URL.createObjectURL(selectedFile)}
                        alt="Evidence"
                        className="w-full h-48 object-cover rounded-lg border border-gray-200"
                      />
                    ) : (
                      <div className="w-full h-48 bg-gray-100 rounded-lg border border-gray-200 flex items-center justify-center">
                        <div className="text-center">
                          <Camera className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                          <p className="text-sm text-gray-600">Video Evidence</p>
                          <p className="text-xs text-gray-500">{selectedFile.name}</p>
                        </div>
                      </div>
                    )}
                    <div className="absolute top-2 right-2 bg-green-500 text-white p-1 rounded-full">
                      <Check className="h-3 w-3" />
                    </div>
                  </div>
                </div>
              )}

              {/* Location */}
              {selectedFile && (
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center text-orange-700">
                          <MapPin className="h-4 w-4 mr-1" />
                          Area Name
                        </FormLabel>
                        <FormControl>
                          <div className="space-y-2">
                            <Input 
                              placeholder="Enter Bengaluru location (e.g., Koramangala, Bengaluru)"
                              {...field}
                              className="border-orange-200 focus:border-orange-400"
                              list="bengaluru-areas"
                            />
                            <datalist id="bengaluru-areas">
                              {BENGALURU_AREAS.map((area, index) => (
                                <option key={index} value={area} />
                              ))}
                            </datalist>
                            <p className="text-xs text-orange-600">
                              iPolice is currently available only in Bengaluru areas
                            </p>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Coordinates Display */}
                  {userCoordinates && (
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                      <label className="flex items-center text-sm font-medium text-orange-700 mb-1">
                        <Navigation className="h-4 w-4 mr-1" />
                        Coordinates
                      </label>
                      <p className="text-sm text-orange-600 font-mono">{userCoordinates}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Violation Type */}
              <FormField
                control={form.control}
                name="violationType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center text-red-700">
                      <AlertTriangle className="h-4 w-4 mr-1" />
                      Violation Type
                    </FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="border-red-200 focus:border-red-400">
                          <SelectValue placeholder="Select violation type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {violationTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Description */}
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center text-blue-700">
                      <FileText className="h-4 w-4 mr-1" />
                      Description
                    </FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe what happened in detail"
                        className="min-h-[100px] border-blue-200 focus:border-blue-400"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full bg-[var(--police-blue)] hover:bg-[var(--police-light)]"
                disabled={createReportMutation.isPending}
              >
                {createReportMutation.isPending ? (
                  "Submitting..."
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Submit Report
                  </>
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <TopHUD />
      
      <main className="max-w-md mx-auto bg-white min-h-screen pb-20">
        {currentStep === 'selection' && renderSelection()}
        {currentStep === 'camera' && renderCamera()}
        {currentStep === 'preview' && renderPreview()}
        {currentStep === 'form' && renderForm()}
      </main>

      {/* Camera Options Overlay - Fixed Centered Position */}
      {showCameraOptions && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={() => setShowCameraOptions(false)}
        >
          <div 
            className="w-full max-w-sm bg-white rounded-3xl shadow-2xl animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Handle Bar */}
            <div className="flex justify-center pt-4 pb-2">
              <div className="w-12 h-1.5 bg-gray-300 rounded-full"></div>
            </div>
            
            <div className="px-6 pb-8">
              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">
                  Add Evidence
                </h3>
                <p className="text-sm text-gray-600">
                  Choose how to provide evidence for your report
                </p>
              </div>
              
              <div className="space-y-4">
                <Button
                  onClick={() => {
                    setShowCameraOptions(false);
                    startCamera();
                  }}
                  className="w-full h-16 text-lg bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 hover:from-blue-600 hover:via-blue-700 hover:to-indigo-700 text-white flex items-center justify-between px-6 shadow-xl rounded-2xl transform hover:scale-[1.02] transition-all duration-200"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <Camera className="h-6 w-6 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold">Open Camera</div>
                      <div className="text-xs text-blue-100 opacity-90">Capture live evidence</div>
                    </div>
                  </div>
                  <div className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </Button>
                
                <Button
                  onClick={() => {
                    setShowCameraOptions(false);
                    openGallery();
                  }}
                  variant="outline"
                  className="w-full h-16 text-lg border-2 border-purple-300/40 bg-gradient-to-br from-purple-50 via-purple-100 to-pink-50 hover:from-purple-100 hover:via-purple-150 hover:to-pink-100 text-purple-800 flex items-center justify-between px-6 rounded-2xl transform hover:scale-[1.02] transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-200/60 rounded-full flex items-center justify-center">
                      <Image className="h-6 w-6 text-purple-700" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold text-purple-800">Open Gallery</div>
                      <div className="text-xs text-purple-600 opacity-80">Select existing photos</div>
                    </div>
                  </div>
                  <div className="w-8 h-8 bg-purple-200/40 rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-purple-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <BottomNavigation />
    </div>
  );
}
