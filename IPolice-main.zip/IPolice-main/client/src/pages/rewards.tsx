import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import TopHUD from "@/components/layout/top-hud";
import BottomNavigation from "@/components/layout/bottom-navigation";
import EvidencePopup from "@/components/shared/evidence-popup";
import { useToast } from "@/hooks/use-toast";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Gift, 
  Star, 
  Crown,
  Medal,
  Award,
  Shield,
  Target,
  Zap,
  Filter,
  Heart,
  Lock,
  Coins,
  FileText,
  Users,
  UserPlus
} from "lucide-react";
import { profileImageGenerator } from "@/lib/profile-images";

// Mock current user ID
const CURRENT_USER_ID = 1;

export default function Rewards() {
  const [activeTab, setActiveTab] = useState("store");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [showEvidencePopup, setShowEvidencePopup] = useState(false);
  const [favorites, setFavorites] = useState<number[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: rewards, isLoading: isLoadingRewards } = useQuery<any[]>({
    queryKey: ["/api/rewards"],
  });

  const { data: leaderboard, isLoading: isLoadingLeaderboard } = useQuery<any[]>({
    queryKey: ["/api/leaderboard"],
    queryFn: () => fetch("/api/leaderboard?limit=10").then(res => res.json()),
  });

  const { data: user, isLoading: isLoadingUser } = useQuery<any>({
    queryKey: ["/api/users", CURRENT_USER_ID],
  });

  const { data: userStats, isLoading: isLoadingStats } = useQuery<any>({
    queryKey: ["/api/users", CURRENT_USER_ID, "stats"],
  });

  // Reward redemption mutation
  const redeemRewardMutation = useMutation({
    mutationFn: async (rewardId: number) => {
      const response = await fetch("/api/rewards/redeem", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: CURRENT_USER_ID,
          rewardId: rewardId,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to redeem reward");
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Reward Redeemed!",
        description: `${data.rewardName} has been added to your account. Check your profile for details.`,
      });
      // Refresh user stats to reflect point deduction
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID, "stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", CURRENT_USER_ID] });
    },
    onError: (error) => {
      toast({
        title: "Redemption Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Toggle favorite function
  const toggleFavorite = (rewardId: number) => {
    setFavorites(prev => 
      prev.includes(rewardId) 
        ? prev.filter(id => id !== rewardId)
        : [...prev, rewardId]
    );
    
    toast({
      title: favorites.includes(rewardId) ? "Removed from Favorites" : "Added to Favorites",
      description: favorites.includes(rewardId) ? "Item removed from your favorites" : "Item saved to your favorites",
    });
  };

  // Handle reward redemption
  const handleRedeemReward = (reward: any) => {
    if ((userStats as any)?.points < reward.cost) {
      toast({
        title: "Insufficient Points",
        description: `You need ${reward.cost - (userStats as any)?.points} more points to redeem this item.`,
        variant: "destructive",
      });
      return;
    }

    redeemRewardMutation.mutate(reward.id);
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-5 w-5 text-yellow-500" />;
      case 2:
        return <Medal className="h-5 w-5 text-gray-400" />;
      case 3:
        return <Award className="h-5 w-5 text-orange-500" />;
      default:
        return <Trophy className="h-4 w-4 text-gray-500" />;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-yellow-500";
      case 2:
        return "bg-gray-400";
      case 3:
        return "bg-orange-500";
      default:
        return "bg-blue-500";
    }
  };

  const filteredRewards = selectedCategory === "all" 
    ? (rewards || []) 
    : (rewards || []).filter((reward: any) => reward.category === selectedCategory);

  const categories = ["all", "Electronics", "Vouchers", "Education", "Home & Living", "Safety", "Automotive", "Tools", "Health"];

  const progressPercentage = userStats ? 
    (((userStats as any).points % 500) / 500) * 100 : 0;

  // Function to get AI-generated image for reward items
  const getRewardImage = (category: string, name: string) => {
    return profileImageGenerator.generateRewardImage(name, category);
  };

  // Function to get colorful category badge colors
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Electronics':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Vouchers':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Education':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Home & Living':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Safety':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Automotive':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Tools':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'Health':
        return 'bg-pink-100 text-pink-800 border-pink-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (isLoadingRewards || isLoadingLeaderboard || isLoadingUser || isLoadingStats) {
    return (
      <div className="min-h-screen bg-gray-50">
        <TopHUD />
        <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
          <div className="animate-pulse space-y-4 p-4">
            <div className="h-12 bg-gray-200 rounded-lg"></div>
            <div className="h-48 bg-gray-200 rounded-lg"></div>
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
        <BottomNavigation onEvidenceClick={() => setShowEvidencePopup(true)} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <TopHUD />
      
      <main className="max-w-md mx-auto bg-white min-h-screen pb-20">
        {/* Header with Toggle Buttons - Celebrative Design */}
        <div className="px-4 pt-6 pb-4">
          <div className="relative">
            {/* Background decorative elements */}
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 via-orange-400/20 to-red-400/20 rounded-2xl blur-xl"></div>
            <div className="relative bg-gray-100 rounded-2xl p-1 shadow-lg">
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => setActiveTab("store")}
                  className={`flex-1 py-4 px-4 rounded-lg font-bold transition-all duration-300 transform ${
                    activeTab === "store"
                      ? "bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 text-white shadow-xl scale-105 hover:scale-110"
                      : "bg-transparent text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:scale-105"
                  }`}
                  variant="ghost"
                >
                  <Gift className={`h-5 w-5 mr-2 ${activeTab === "store" ? "animate-bounce" : ""} stroke-2`} />
                  <span className="text-sm">Reward Store</span>
                </Button>
                <Button
                  onClick={() => setActiveTab("leaderboard")}
                  className={`flex-1 py-4 px-4 rounded-lg font-bold transition-all duration-300 transform ${
                    activeTab === "leaderboard"
                      ? "bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 text-white shadow-xl scale-105 hover:scale-110"
                      : "bg-transparent text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:scale-105"
                  }`}
                  variant="ghost"
                >
                  <Trophy className={`h-5 w-5 mr-2 ${activeTab === "leaderboard" ? "animate-bounce" : ""} stroke-2`} />
                  <span className="text-sm">Leaderboard</span>
                </Button>
              </div>
            </div>
            
            {/* Floating celebration particles */}
            <div className="absolute -top-2 -left-2 w-3 h-3 bg-yellow-400 rounded-full animate-ping"></div>
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-pink-500 rounded-full animate-pulse"></div>
            <div className="absolute -bottom-2 left-1/4 w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
            <div className="absolute -bottom-1 right-1/4 w-3 h-3 bg-green-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
          </div>
        </div>

        {activeTab === "store" && (
          <div className="px-4 space-y-6">
            {/* Compact Enhanced User Profile Card */}
            <Card className="relative bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 text-white border-0 shadow-2xl sheen overflow-hidden">
              {/* Background decorative elements */}
              <div className="absolute top-0 right-0 w-20 h-20 bg-white/5 rounded-full -translate-y-10 translate-x-10"></div>
              <div className="absolute bottom-0 left-0 w-16 h-16 bg-white/5 rounded-full translate-y-8 -translate-x-8"></div>
              
              <CardContent className="p-4 relative z-10">
                {/* Header Section */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 p-0.5">
                        <img
                          src={(user as any)?.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100"}
                          alt="Profile"
                          className="w-full h-full rounded-full object-cover"
                        />
                      </div>
                      <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full border-2 border-white flex items-center justify-center shadow-lg animate-pulse">
                        <Shield className="h-2 w-2 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h2 className="text-lg font-black text-white">
                        Karan Shetty
                      </h2>
                      <div className="flex items-center space-x-2">
                        <Crown className="h-3 w-3 text-yellow-300" />
                        <span className="text-xs text-blue-100">Platinum</span>
                        <Star className="h-3 w-3 text-yellow-300 fill-yellow-300" />
                        <span className="text-xs text-blue-100">Star Contributor</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-1">
                    <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-2 py-0.5 text-xs font-bold shadow-lg">
                      <Star className="h-2.5 w-2.5 mr-1 animate-pulse" />
                      Elite
                    </Badge>
                  </div>
                </div>

                {/* Inline Stats - No Background */}
                <div className="flex justify-between items-center mb-4 px-2">
                  <div className="flex items-center space-x-1">
                    <Coins className="h-4 w-4 text-yellow-300" />
                    <span className="text-lg font-black text-yellow-300">{(userStats as any)?.points || 0}</span>
                    <span className="text-xs text-blue-100">points</span>
                  </div>
                  <div className="w-px h-6 bg-white/20"></div>
                  <div className="flex items-center space-x-1">
                    <FileText className="h-4 w-4 text-orange-300" />
                    <span className="text-lg font-black text-orange-300">{(userStats as any)?.totalReports || 0}</span>
                    <span className="text-xs text-blue-100">reports</span>
                  </div>
                  <div className="w-px h-6 bg-white/20"></div>
                  <div className="flex items-center space-x-1">
                    <Trophy className="h-4 w-4 text-green-300" />
                    <span className="text-lg font-black text-green-300">#{(userStats as any)?.rank || 0}</span>
                    <span className="text-xs text-blue-100">rank</span>
                  </div>
                </div>

                {/* Compact Progress Section */}
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center space-x-1">
                      <Zap className="h-3 w-3 text-yellow-300" />
                      <span className="text-xs font-bold">Next - Level 6</span>
                    </div>
                    <span className="text-xs text-blue-100">
                      {(userStats as any)?.points || 0} / {(((userStats as any)?.level || 1) + 1) * 500}
                    </span>
                  </div>
                  <div className="relative">
                    <Progress value={progressPercentage} className="h-2 bg-white/20" />
                    <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full opacity-80" style={{width: `${progressPercentage}%`}}></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Category Filter - Horizontal Scrollable */}
            <div className="flex space-x-2 overflow-x-auto pb-2 px-1 scrollbar-hide">
              {categories.map((category) => (
                <Button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  variant="outline"
                  size="sm"
                  className={`flex-shrink-0 text-xs px-4 py-2 ${
                    selectedCategory === category
                      ? "bg-[var(--police-blue)] text-white border-[var(--police-blue)]"
                      : "text-gray-600 hover:text-[var(--police-blue)] bg-white"
                  }`}
                >
                  {category === "all" ? "All" : category}
                </Button>
              ))}
            </div>

            {/* All Rewards Section */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Gift className="h-5 w-5 text-[var(--police-blue)]" />
                <h3 className="text-lg font-bold text-gray-900">All Rewards</h3>
              </div>
              
              <div className="max-h-96 overflow-y-auto scrollbar-hide">
                <div className="grid grid-cols-2 gap-4 pr-2">
                  {/* Favorites - iPhone 15 Pro */}
                  <div className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden border border-gray-100">
                    <div className="relative overflow-hidden">
                      <img
                        src="https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=300&h=200&fit=crop&auto=format"
                        alt="iPhone 15 Pro"
                        className="w-full h-32 object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      <div className="absolute top-3 right-3">
                        <Badge variant="secondary" className="text-xs px-2 py-1 font-medium backdrop-blur-sm shadow-sm bg-red-100 text-red-800 border-red-200">
                          Favourites
                        </Badge>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute top-3 left-3 h-8 w-8 p-0 bg-white/80 hover:bg-white"
                        onClick={() => toggleFavorite(999)}
                      >
                        <Heart className={`h-4 w-4 ${favorites.includes(999) ? 'text-red-500 fill-red-500' : 'text-gray-400'}`} />
                      </Button>
                    </div>
                    
                    <div className="p-4 space-y-3">
                      <div className="space-y-1">
                        <h3 className="font-bold text-gray-900 text-sm leading-tight line-clamp-1">
                          iPhone 15 Pro
                        </h3>
                        <p className="text-xs text-gray-500 line-clamp-1">
                          Latest flagship smartphone
                        </p>
                      </div>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            size="sm" 
                            className="w-full h-10 text-sm font-medium bg-gradient-to-r from-[var(--police-blue)] to-blue-600 hover:from-blue-600 hover:to-[var(--police-blue)] shadow-md hover:shadow-lg transition-all duration-300"
                            disabled={((userStats as any)?.points || 0) < 50000}
                          >
                            {((userStats as any)?.points || 0) >= 50000 ? (
                              <div className="flex items-center justify-center w-full space-x-2">
                                <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                                  50,000
                                </span>
                                <Zap className="h-3 w-3" />
                                <span>Redeem</span>
                              </div>
                            ) : (
                              <div className="flex items-center justify-center w-full space-x-2">
                                <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                                  50,000
                                </span>
                                <Lock className="h-3 w-3" />
                                <span>Locked</span>
                              </div>
                            )}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Redeem iPhone 15 Pro?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will deduct 50,000 points from your account. The iPhone 15 Pro will be added to your profile and shipped to your registered address.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleRedeemReward({id: 999, name: "iPhone 15 Pro", cost: 50000})}>
                              Redeem Now
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>

                  {/* Favorites - 4K Dash Cam */}
                  <div className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden border border-gray-100">
                    <div className="relative overflow-hidden">
                      <img
                        src="/attached_assets/image_1753102030444.png"
                        alt="4K Dash Cam"
                        className="w-full h-32 object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      <div className="absolute top-3 right-3">
                        <Badge variant="secondary" className="text-xs px-2 py-1 font-medium backdrop-blur-sm shadow-sm bg-red-100 text-red-800 border-red-200">
                          Favourites
                        </Badge>
                      </div>
                      <div className="absolute top-3 left-3">
                        <Heart className="h-4 w-4 text-red-500 fill-red-500" />
                      </div>
                    </div>
                    
                    <div className="p-4 space-y-3">
                      <div className="space-y-1">
                        <h3 className="font-bold text-gray-900 text-sm leading-tight line-clamp-1">
                          4K Dash Cam
                        </h3>
                        <p className="text-xs text-gray-500 line-clamp-1">
                          High-quality car security camera
                        </p>
                      </div>
                      
                      <Button 
                        size="sm" 
                        className="w-full h-10 text-sm font-medium bg-gradient-to-r from-[var(--police-blue)] to-blue-600 hover:from-blue-600 hover:to-[var(--police-blue)] shadow-md hover:shadow-lg transition-all duration-300"
                        disabled={((userStats as any)?.points || 0) < 15000}
                      >
                        {((userStats as any)?.points || 0) >= 15000 ? (
                          <div className="flex items-center justify-center w-full space-x-2">
                            <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                              15,000
                            </span>
                            <Zap className="h-3 w-3" />
                            <span>Redeem</span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center w-full space-x-2">
                            <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                              15,000
                            </span>
                            <Lock className="h-3 w-3" />
                            <span>Locked</span>
                          </div>
                        )}
                      </Button>
                    </div>
                  </div>
                {filteredRewards?.map((reward: any) => (
                  <div key={reward.id} className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden border border-gray-100">
                    {/* Image Section */}
                    <div className="relative overflow-hidden">
                      <img
                        src={reward.imageUrl || reward.image_url}
                        alt={reward.name}
                        className="w-full h-32 object-cover transition-transform duration-300 group-hover:scale-105"
                        onError={(e) => {
                          e.currentTarget.src = 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=300&h=200&fit=crop&auto=format';
                        }}
                      />
                      {/* Gradient Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      
                      {/* Category Badge - Floating */}
                      <div className="absolute top-3 right-3">
                        <Badge variant="secondary" className={`text-xs px-2 py-1 font-medium backdrop-blur-sm shadow-sm ${getCategoryColor(reward.category)}`}>
                          {reward.category}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Content Section */}
                    <div className="p-4 space-y-3">
                      {/* Title and Description - Close together */}
                      <div className="space-y-1">
                        <h3 className="font-bold text-gray-900 text-sm leading-tight line-clamp-1">
                          {reward.name}
                        </h3>
                        <p className="text-xs text-gray-500 line-clamp-1">
                          {reward.description}
                        </p>
                      </div>
                      
                      {/* Redeem Button with Points */}
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            size="sm" 
                            className="w-full h-10 text-sm font-medium bg-gradient-to-r from-[var(--police-blue)] to-blue-600 hover:from-blue-600 hover:to-[var(--police-blue)] shadow-md hover:shadow-lg transition-all duration-300"
                            disabled={((userStats as any)?.points || 0) < reward.pointsCost}
                          >
                            {((userStats as any)?.points || 0) >= reward.pointsCost ? (
                              <div className="flex items-center justify-center w-full space-x-2">
                                <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                                  {reward.pointsCost}
                                </span>
                                <Zap className="h-3 w-3" />
                                <span>Redeem</span>
                              </div>
                            ) : (
                              <div className="flex items-center justify-center w-full space-x-2">
                                <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                                  {reward.pointsCost}
                                </span>
                                <Shield className="h-3 w-3" />
                                <span>Need More</span>
                              </div>
                            )}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Redeem {reward.name}?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will deduct {reward.pointsCost} points from your account. The item will be added to your profile and processed for delivery.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleRedeemReward(reward)}>
                              {redeemRewardMutation.isPending ? "Processing..." : "Redeem Now"}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* How to Earn Points - Compact */}
            <Card className="border border-green-100 bg-green-50">
              <CardContent className="p-3">
                <h4 className="text-sm font-medium text-green-800 mb-2">How to Earn Points?</h4>
                <ul className="text-xs text-green-700 space-y-0.5">
                  <li>• Submit reports: +10 pts • Verified: +25 pts bonus</li>
                  <li>• Quality evidence: +5 pts • Regular use: Weekly bonus</li>
                </ul>
              </CardContent>
            </Card>
            </div>
          </div>
        )}

        {activeTab === "leaderboard" && (
          <div className="px-4 pb-0">
            {/* Compact Stats Header */}
            <div className="mb-4">
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-3 shadow-md">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-base font-bold text-blue-900 flex items-center space-x-1">
                    <Trophy className="h-4 w-4 text-blue-700" />
                    <span>Bengaluru Champions</span>
                  </h2>
                  <span className="text-xs text-blue-800 font-medium">Safety Heroes</span>
                </div>
                
                {/* Compact Stats Row */}
                <div className="flex justify-between gap-2">
                  <div className="bg-white/60 backdrop-blur-sm rounded-md px-2 py-1.5 text-center flex-1">
                    <div className="flex items-center justify-center space-x-1">
                      <Shield className="h-3 w-3 text-blue-700" />
                      <span className="text-sm font-bold text-blue-900">28.9k</span>
                    </div>
                    <div className="text-xs text-blue-700">Reports</div>
                  </div>
                  <div className="bg-white/60 backdrop-blur-sm rounded-md px-2 py-1.5 text-center flex-1">
                    <div className="flex items-center justify-center space-x-1">
                      <Target className="h-3 w-3 text-blue-700" />
                      <span className="text-sm font-bold text-blue-900">21.7k</span>
                    </div>
                    <div className="text-xs text-blue-700">Resolved</div>
                  </div>
                  <div className="bg-white/60 backdrop-blur-sm rounded-md px-2 py-1.5 text-center flex-1">
                    <div className="flex items-center justify-center space-x-1">
                      <Users className="h-3 w-3 text-blue-700" />
                      <span className="text-sm font-bold text-blue-900">2.8k</span>
                    </div>
                    <div className="text-xs text-blue-700">Heroes</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Enhanced Leaderboard with Top Contributors - Fluid to Bottom */}
            <div className="bg-white shadow-lg overflow-hidden border-2 border-yellow-200/50 rounded-t-xl -mx-4">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3">
                <h3 className="text-white font-bold text-center flex items-center justify-center space-x-2">
                  <Trophy className="h-5 w-5 text-yellow-300" />
                  <span>Leaderboard</span>
                  <Crown className="h-5 w-5 text-yellow-300" />
                </h3>
              </div>
              
              <div className="h-[calc(100vh-380px)] overflow-y-auto scrollbar-hide pb-20">
                {/* Enhanced Top 3 rankings */}
                {[
                  { rank: 1, name: "Rajesh Kumar", area: "Whitefield", points: 8750, reports: 185, isTopRank: true, id: 101 },
                  { rank: 2, name: "Priya Sharma", area: "Koramangala", points: 8420, reports: 168, isTopRank: true, id: 102 },
                  { rank: 3, name: "Sneha Reddy", area: "Indiranagar", points: 7980, reports: 159, isTopRank: true, id: 103 },
                ].map((contributor) => (
                  <div 
                    key={contributor.rank} 
                    className={`p-4 border-b-2 border-gray-200 transition-all hover:scale-[1.02] ${
                      contributor.rank === 1 ? 'bg-gradient-to-r from-yellow-50 via-yellow-100 to-orange-50 border-l-4 border-l-yellow-500' :
                      contributor.rank === 2 ? 'bg-gradient-to-r from-slate-50 via-slate-100 to-slate-50 border-l-4 border-l-slate-400' :
                      'bg-gradient-to-r from-orange-50 via-orange-100 to-orange-50 border-l-4 border-l-orange-500'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="relative">
                          <div className={`w-14 h-14 rounded-full p-0.5 shadow-lg ${
                            contributor.rank === 1 ? 'bg-gradient-to-r from-yellow-300 to-yellow-500' :
                            contributor.rank === 2 ? 'bg-gradient-to-r from-slate-300 to-slate-400' :
                            'bg-gradient-to-r from-orange-300 to-orange-500'
                          }`}>
                            <img
                              src={profileImageGenerator.generateProfileImage(contributor.rank, contributor.name)}
                              alt={contributor.name}
                              className="w-full h-full rounded-full object-cover"
                            />
                          </div>
                          <div className={`absolute -top-2 -right-2 rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold shadow-lg ${
                            contributor.rank === 1 ? 'bg-yellow-500 text-white' :
                            contributor.rank === 2 ? 'bg-slate-400 text-white' :
                            'bg-orange-500 text-white'
                          }`}>
                            {contributor.rank}
                          </div>
                          {contributor.rank === 1 && (
                            <Crown className="absolute -top-3 -left-1 h-6 w-6 text-yellow-500 animate-bounce" />
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-gray-800 flex items-center space-x-3">
                            <span className="text-lg">{contributor.name}</span>
                            <span className="text-2xl">
                              {contributor.rank === 1 ? '👑' : contributor.rank === 2 ? '🥈' : '🥉'}
                            </span>
                          </div>
                          <div className="text-sm font-medium text-gray-600">{contributor.area}</div>
                          <div className="text-xs text-gray-500 font-medium">{contributor.reports} reports submitted</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-black text-2xl ${
                          contributor.rank === 1 ? 'text-yellow-600' :
                          contributor.rank === 2 ? 'text-slate-600' :
                          'text-orange-600'
                        }`}>
                          {contributor.points.toLocaleString()}
                        </div>
                        <div className="text-sm font-semibold text-gray-600">points</div>
                      </div>
                    </div>
                  </div>
                ))}

                {/* User's position pinned after top 3 */}
                <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-l-4 border-blue-500 sticky top-0 z-10">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-400 to-purple-500 p-0.5">
                          <img
                            src={profileImageGenerator.generateProfileImage(23, "Karan Shetty")}
                            alt="Karan Shetty"
                            className="w-full h-full rounded-full object-cover"
                          />
                        </div>
                        <div className="absolute -top-1 -right-1 bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">23</div>
                        <div className="absolute -bottom-1 -left-1 bg-green-500 rounded-full w-4 h-4 flex items-center justify-center">
                          <span className="text-white text-xs">👤</span>
                        </div>
                      </div>
                      <div>
                        <div className="font-bold text-gray-800 flex items-center space-x-2">
                          <span>Karan Shetty</span>
                          <span className="bg-blue-500 text-white px-2 py-0.5 rounded-full text-xs font-bold">YOU</span>
                        </div>
                        <div className="text-sm text-gray-600">Electronic City</div>
                        <div className="text-xs text-gray-500">33 reports • Platinum | Star Contributor</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-blue-600 text-lg">1,650</div>
                      <div className="text-xs text-gray-500">points</div>
                    </div>
                  </div>
                </div>

                {/* Rest of the rankings */}
                {[
                  { rank: 4, name: "Arjun Nair", area: "HSR Layout", points: 7650, reports: 153, id: 104 },
                  { rank: 5, name: "Deepika Singh", area: "Marathahalli", points: 7320, reports: 146, id: 105 },
                  { rank: 6, name: "Vikram Patel", area: "Banashankari", points: 6980, reports: 139, id: 106 },
                  { rank: 7, name: "Ananya Iyer", area: "Jayanagar", points: 6750, reports: 135, id: 107 },
                  { rank: 8, name: "Rohit Krishnan", area: "Malleshwaram", points: 6420, reports: 128, id: 108 },
                  { rank: 9, name: "Kavya Rao", area: "Rajajinagar", points: 6150, reports: 123, id: 109 },
                  { rank: 10, name: "Suresh Gowda", area: "Basavanagudi", points: 5850, reports: 117, id: 110 },
                  { rank: 11, name: "Meera Joshi", area: "BTM Layout", points: 5540, reports: 111, id: 111 },
                  { rank: 12, name: "Ravi Shankar", area: "Yelahanka", points: 5280, reports: 106, id: 112 },
                  { rank: 13, name: "Pooja Hegde", area: "Sarjapur", points: 4950, reports: 99, id: 113 },
                  { rank: 14, name: "Kiran Kumar", area: "Hebbal", points: 4680, reports: 94, id: 114 },
                  { rank: 15, name: "Lakshmi Nair", area: "JP Nagar", points: 4420, reports: 88, id: 115 },
                  { rank: 16, name: "Manoj Gowda", area: "Vijayanagar", points: 4180, reports: 84, id: 116 },
                  { rank: 17, name: "Divya Rao", area: "RT Nagar", points: 3950, reports: 79, id: 117 },
                  { rank: 18, name: "Sanjay Reddy", area: "Yeshwanthpur", points: 3720, reports: 74, id: 118 },
                  { rank: 19, name: "Neha Patel", area: "Banaswadi", points: 3480, reports: 70, id: 119 },
                  { rank: 20, name: "Ramesh Kumar", area: "Nagarbhavi", points: 3250, reports: 65, id: 120 },
                  { rank: 21, name: "Sowmya Iyer", area: "Chandapura", points: 3020, reports: 60, id: 121 },
                  { rank: 22, name: "Gopal Singh", area: "Bommanahalli", points: 2800, reports: 56, id: 122 },
                  { rank: 24, name: "Rashid Ahmed", area: "Frazer Town", points: 1580, reports: 32, id: 124 },
                  { rank: 25, name: "Varsha Joshi", area: "Domlur", points: 1520, reports: 30, id: 125 },
                  { rank: 26, name: "Harish Gowda", area: "KR Puram", points: 1460, reports: 29, id: 126 },
                  { rank: 27, name: "Shweta Sharma", area: "Attiguppe", points: 1400, reports: 28, id: 127 },
                  { rank: 28, name: "Naveen Kumar", area: "Hongasandra", points: 1340, reports: 27, id: 128 },
                  { rank: 29, name: "Preethi Rao", area: "Kumaraswamy Layout", points: 1280, reports: 26, id: 129 },
                  { rank: 30, name: "Sunil Reddy", area: "Begur", points: 1220, reports: 24, id: 130 },
                ].map((contributor) => (
                  <div 
                    key={contributor.rank} 
                    className="p-3 border-b border-gray-100 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <div className="w-10 h-10 rounded-full p-0.5 bg-gray-200">
                            <img
                              src={profileImageGenerator.generateProfileImage(contributor.rank, contributor.name)}
                              alt={contributor.name}
                              className="w-full h-full rounded-full object-cover"
                            />
                          </div>
                          <div className="absolute -top-1 -right-1 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold bg-gray-500 text-white">
                            {contributor.rank}
                          </div>
                        </div>
                        <div>
                          <div className="font-medium text-gray-800 flex items-center space-x-2">
                            <span>{contributor.name}</span>
                          </div>
                          <div className="text-sm text-gray-600">{contributor.area}</div>
                          <div className="text-xs text-gray-500">{contributor.reports} reports</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-lg text-gray-700">
                          {contributor.points}
                        </div>
                        <div className="text-xs text-gray-500">points</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Refer a Friend Bar - Only on Leaderboard Tab */}
      {activeTab === "leaderboard" && (
        <div className="fixed bottom-20 left-4 right-4 z-40 max-w-sm mx-auto">
          <div className="bg-gradient-to-r from-emerald-500 to-green-500 rounded-xl p-3 shadow-lg border-2 border-white/20 backdrop-blur-sm hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="bg-white/20 rounded-full p-1.5">
                  <UserPlus className="h-4 w-4 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-xs">Refer a Friend</h3>
                  <p className="text-white/90 text-xs">Get 500 bonus points each!</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-1 bg-white/20 rounded-full px-2 py-1">
                  <Coins className="h-3 w-3 text-yellow-300" />
                  <span className="text-white text-xs font-bold">+500</span>
                </div>
                <Button size="sm" className="bg-white text-emerald-600 hover:bg-white/90 font-bold px-3 py-1.5 rounded-full text-xs">
                  Refer
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <BottomNavigation onEvidenceClick={() => setShowEvidencePopup(true)} />
      
      <EvidencePopup 
        isOpen={showEvidencePopup} 
        onClose={() => setShowEvidencePopup(false)} 
      />
    </div>
  );
}
