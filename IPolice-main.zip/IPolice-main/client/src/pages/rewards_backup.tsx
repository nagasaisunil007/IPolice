import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import TopHUD from "@/components/layout/top-hud";
import BottomNavigation from "@/components/layout/bottom-navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Gift, 
  Star, 
  Crown,
  Medal,
  Award,
  Shield,
  Target,
  Zap,
  Filter
} from "lucide-react";

// Mock current user ID
const CURRENT_USER_ID = 1;

export default function Rewards() {
  const [activeTab, setActiveTab] = useState("store");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: rewards, isLoading: isLoadingRewards } = useQuery<any[]>({
    queryKey: ["/api/rewards"],
  });

  const { data: leaderboard, isLoading: isLoadingLeaderboard } = useQuery<any[]>({
    queryKey: ["/api/leaderboard"],
    queryFn: () => fetch("/api/leaderboard?limit=10").then(res => res.json()),
  });

  const { data: user, isLoading: isLoadingUser } = useQuery<any>({
    queryKey: ["/api/users", CURRENT_USER_ID],
  });

  const { data: userStats, isLoading: isLoadingStats } = useQuery<any>({
    queryKey: ["/api/users", CURRENT_USER_ID, "stats"],
  });

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-5 w-5 text-yellow-500" />;
      case 2:
        return <Medal className="h-5 w-5 text-gray-400" />;
      case 3:
        return <Award className="h-5 w-5 text-orange-500" />;
      default:
        return <Trophy className="h-4 w-4 text-gray-500" />;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-yellow-500";
      case 2:
        return "bg-gray-400";
      case 3:
        return "bg-orange-500";
      default:
        return "bg-blue-500";
    }
  };

  const filteredRewards = selectedCategory === "all" 
    ? (rewards || []) 
    : (rewards || []).filter((reward: any) => reward.category === selectedCategory);

  const categories = ["all", "Electronics", "Vouchers", "Education", "Home & Living", "Safety", "Automotive", "Tools", "Health"];

  const progressPercentage = userStats ? 
    (((userStats as any).points % 500) / 500) * 100 : 0;

  // Function to get proper image for reward items
  const getRewardImage = (category: string, name: string) => {
    const lowerName = name.toLowerCase();
    
    // Safety items
    if (lowerName.includes('helmet') || lowerName.includes('reflective') || lowerName.includes('safety') || lowerName.includes('vest')) {
      return 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop&auto=format';
    }
    
    // Automotive items
    if (lowerName.includes('car') || lowerName.includes('auto') || lowerName.includes('tire') || lowerName.includes('freshener') || category === 'Automotive') {
      return 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=300&h=200&fit=crop&auto=format';
    }
    
    // Cleaning items
    if (lowerName.includes('cleaner') || lowerName.includes('cleaning') || lowerName.includes('glass')) {
      return 'https://images.unsplash.com/photo-1563453392212-326f5e854473?w=300&h=200&fit=crop&auto=format';
    }
    
    // Electronics
    if (lowerName.includes('headphone') || lowerName.includes('earphone')) return 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('laptop')) return 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('phone') || lowerName.includes('mobile')) return 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('watch') || lowerName.includes('smartwatch')) return 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('tablet') || lowerName.includes('ipad')) return 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('camera')) return 'https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('speaker') || lowerName.includes('bluetooth')) return 'https://images.unsplash.com/photo-1589492477829-5e65395b66cc?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('keyboard')) return 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('mouse')) return 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=300&h=200&fit=crop&auto=format';
    if (lowerName.includes('charger') || lowerName.includes('cable')) return 'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=300&h=200&fit=crop&auto=format';
    
    // Tools and gadgets
    if (lowerName.includes('tool') || lowerName.includes('kit') || lowerName.includes('gadget')) {
      return 'https://images.unsplash.com/photo-1609881434458-c2fb5dfc2522?w=300&h=200&fit=crop&auto=format';
    }
    
    // Books and education
    if (lowerName.includes('book') || lowerName.includes('course') || lowerName.includes('education')) {
      return 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=200&fit=crop&auto=format';
    }
    
    // Vouchers and gift cards
    if (lowerName.includes('amazon') || lowerName.includes('flipkart') || lowerName.includes('voucher') || lowerName.includes('gift')) {
      return 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=300&h=200&fit=crop&auto=format';
    }
    
    // Food and beverages
    if (lowerName.includes('coffee') || lowerName.includes('starbucks') || lowerName.includes('food') || lowerName.includes('zomato') || lowerName.includes('swiggy')) {
      return 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=300&h=200&fit=crop&auto=format';
    }
    
    // Travel and transportation
    if (lowerName.includes('travel') || lowerName.includes('uber') || lowerName.includes('ola')) {
      return 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=300&h=200&fit=crop&auto=format';
    }
    
    // Entertainment
    if (lowerName.includes('movie') || lowerName.includes('netflix') || lowerName.includes('entertainment')) {
      return 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&h=200&fit=crop&auto=format';
    }
    
    // Health and wellness
    if (lowerName.includes('health') || lowerName.includes('medical') || lowerName.includes('wellness')) {
      return 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=300&h=200&fit=crop&auto=format';
    }
    
    // Category-based fallbacks
    const categoryImages: Record<string, string> = {
      'Electronics': 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=300&h=200&fit=crop&auto=format',
      'Vouchers': 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=300&h=200&fit=crop&auto=format',
      'Education': 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=200&fit=crop&auto=format',
      'Home & Living': 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&h=200&fit=crop&auto=format',
      'Safety': 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop&auto=format',
      'Automotive': 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=300&h=200&fit=crop&auto=format',
      'Tools': 'https://images.unsplash.com/photo-1609881434458-c2fb5dfc2522?w=300&h=200&fit=crop&auto=format',
      'Health': 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=300&h=200&fit=crop&auto=format',
    };

    return categoryImages[category] || 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=300&h=200&fit=crop&auto=format';
  };

  // Function to get colorful category badge colors
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Electronics':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Vouchers':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Education':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Home & Living':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Safety':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Automotive':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Tools':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'Health':
        return 'bg-pink-100 text-pink-800 border-pink-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (isLoadingRewards || isLoadingLeaderboard || isLoadingUser || isLoadingStats) {
    return (
      <div className="min-h-screen bg-gray-50">
        <TopHUD />
        <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
          <div className="animate-pulse space-y-4 p-4">
            <div className="h-12 bg-gray-200 rounded-lg"></div>
            <div className="h-48 bg-gray-200 rounded-lg"></div>
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <TopHUD />
      
      <main className="max-w-md mx-auto bg-white min-h-screen pb-20">
        {/* Header with Toggle Buttons */}
        <div className="px-4 pt-6 pb-4">
          <div className="flex items-center space-x-2 bg-gray-100 rounded-xl p-1">
            <Button
              onClick={() => setActiveTab("store")}
              className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                activeTab === "store"
                  ? "bg-white text-[var(--police-blue)] shadow-sm"
                  : "bg-transparent text-gray-600 hover:text-gray-800"
              }`}
              variant="ghost"
            >
              <Gift className="h-4 w-4 mr-2" />
              Reward Store
            </Button>
            <Button
              onClick={() => setActiveTab("leaderboard")}
              className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all ${
                activeTab === "leaderboard"
                  ? "bg-white text-[var(--police-blue)] shadow-sm"
                  : "bg-transparent text-gray-600 hover:text-gray-800"
              }`}
              variant="ghost"
            >
              <Trophy className="h-4 w-4 mr-2" />
              Leaderboard
            </Button>
          </div>
        </div>

        {activeTab === "store" && (
          <div className="px-4 space-y-6">
            {/* User Profile Card - Compact */}
            <Card className="bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 text-white border-0 shadow-xl">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <img
                        src={(user as any)?.profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100"}
                        alt="Profile"
                        className="w-12 h-12 rounded-full border-2 border-white shadow-lg"
                      />
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white flex items-center justify-center">
                        <Shield className="h-2 w-2 text-white" />
                      </div>
                    </div>
                    <div>
                      <h2 className="text-lg font-bold">{(user as any)?.name || "User"}</h2>
                      <p className="text-blue-100 text-xs">Level {((userStats as any)?.level || 1)}</p>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <Badge className="bg-yellow-500 text-yellow-900 hover:bg-yellow-500 px-2 py-1 text-xs">
                      <Star className="h-2 w-2 mr-1" />
                      Top
                    </Badge>
                    <Badge className="bg-green-500 text-green-900 hover:bg-green-500 px-2 py-1 text-xs">
                      <Target className="h-2 w-2 mr-1" />
                      Expert
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mb-3">
                  <div className="text-center">
                    <div className="text-xl font-bold">{(userStats as any)?.points || 0}</div>
                    <div className="text-xs text-blue-100">Points</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-yellow-300">{(userStats as any)?.totalReports || 0}</div>
                    <div className="text-xs text-blue-100">Reports</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-green-300">#{(userStats as any)?.rank || 0}</div>
                    <div className="text-xs text-blue-100">Rank</div>
                  </div>
                </div>

                {/* Progress Bar - Compact */}
                <div className="bg-white/20 rounded-lg p-2">
                  <div className="flex justify-between text-xs mb-1">
                    <span>Level {((userStats as any)?.level || 1) + 1}</span>
                    <span>{(userStats as any)?.points || 0} / {(((userStats as any)?.level || 1) + 1) * 500}</span>
                  </div>
                  <Progress value={progressPercentage} className="h-1.5 bg-white/30" />
                </div>
              </CardContent>
            </Card>

            {/* Category Filter - Horizontal Scrollable */}
            <div className="flex space-x-2 overflow-x-auto pb-2 px-1 scrollbar-hide">
              {categories.map((category) => (
                <Button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  variant="outline"
                  size="sm"
                  className={`flex-shrink-0 text-xs px-4 py-2 ${
                    selectedCategory === category
                      ? "bg-[var(--police-blue)] text-white border-[var(--police-blue)]"
                      : "text-gray-600 hover:text-[var(--police-blue)] bg-white"
                  }`}
                >
                  {category === "all" ? "All" : category}
                </Button>
              ))}
            </div>

            {/* Favorites Section */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                <h3 className="text-lg font-bold text-gray-900">Favorites</h3>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {/* iPhone 15 Pro */}
                <div className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden border border-gray-100">
                  <div className="relative overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=300&h=200&fit=crop&auto=format"
                      alt="iPhone 15 Pro"
                      className="w-full h-32 object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="absolute top-3 right-3">
                      <Badge variant="secondary" className="text-xs px-2 py-1 font-medium backdrop-blur-sm shadow-sm bg-blue-100 text-blue-800 border-blue-200">
                        Electronics
                      </Badge>
                    </div>
                    <div className="absolute top-3 left-3">
                      <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    </div>
                  </div>
                  
                  <div className="p-4 space-y-3">
                    <div className="space-y-1">
                      <h3 className="font-bold text-gray-900 text-sm leading-tight line-clamp-1">
                        iPhone 15 Pro
                      </h3>
                      <p className="text-xs text-gray-500 line-clamp-1">
                        Latest flagship smartphone
                      </p>
                    </div>
                    
                    <Button 
                      size="sm" 
                      className="w-full h-10 text-sm font-medium bg-gradient-to-r from-[var(--police-blue)] to-blue-600 hover:from-blue-600 hover:to-[var(--police-blue)] shadow-md hover:shadow-lg transition-all duration-300"
                      disabled={((userStats as any)?.points || 0) < 50000}
                    >
                      {((userStats as any)?.points || 0) >= 50000 ? (
                        <div className="flex items-center justify-center w-full space-x-2">
                          <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                            50,000
                          </span>
                          <Zap className="h-3 w-3" />
                          <span>Redeem</span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center w-full space-x-2">
                          <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                            50,000
                          </span>
                          <Shield className="h-3 w-3" />
                          <span>Need More</span>
                        </div>
                      )}
                    </Button>
                  </div>
                </div>

                {/* 4K Dash Cam */}
                <div className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden border border-gray-100">
                  <div className="relative overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=300&h=200&fit=crop&auto=format"
                      alt="4K Dash Cam"
                      className="w-full h-32 object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="absolute top-3 right-3">
                      <Badge variant="secondary" className="text-xs px-2 py-1 font-medium backdrop-blur-sm shadow-sm bg-red-100 text-red-800 border-red-200">
                        Automotive
                      </Badge>
                    </div>
                    <div className="absolute top-3 left-3">
                      <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    </div>
                  </div>
                  
                  <div className="p-4 space-y-3">
                    <div className="space-y-1">
                      <h3 className="font-bold text-gray-900 text-sm leading-tight line-clamp-1">
                        4K Dash Cam
                      </h3>
                      <p className="text-xs text-gray-500 line-clamp-1">
                        High-quality car security camera
                      </p>
                    </div>
                    
                    <Button 
                      size="sm" 
                      className="w-full h-10 text-sm font-medium bg-gradient-to-r from-[var(--police-blue)] to-blue-600 hover:from-blue-600 hover:to-[var(--police-blue)] shadow-md hover:shadow-lg transition-all duration-300"
                      disabled={((userStats as any)?.points || 0) < 15000}
                    >
                      {((userStats as any)?.points || 0) >= 15000 ? (
                        <div className="flex items-center justify-center w-full space-x-2">
                          <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                            15,000
                          </span>
                          <Zap className="h-3 w-3" />
                          <span>Redeem</span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center w-full space-x-2">
                          <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                            15,000
                          </span>
                          <Shield className="h-3 w-3" />
                          <span>Need More</span>
                        </div>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Regular Rewards Grid - Modern Design */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Gift className="h-5 w-5 text-[var(--police-blue)]" />
                <h3 className="text-lg font-bold text-gray-900">All Rewards</h3>
              </div>
              
              <div className="max-h-96 overflow-y-auto scrollbar-hide">
                <div className="grid grid-cols-2 gap-4 pr-2">
                {filteredRewards?.map((reward: any) => (
                  <div key={reward.id} className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden border border-gray-100">
                    {/* Image Section */}
                    <div className="relative overflow-hidden">
                      <img
                        src={reward.imageUrl || reward.image_url}
                        alt={reward.name}
                        className="w-full h-32 object-cover transition-transform duration-300 group-hover:scale-105"
                        onError={(e) => {
                          e.currentTarget.src = 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=300&h=200&fit=crop&auto=format';
                        }}
                      />
                      {/* Gradient Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      
                      {/* Category Badge - Floating */}
                      <div className="absolute top-3 right-3">
                        <Badge variant="secondary" className={`text-xs px-2 py-1 font-medium backdrop-blur-sm shadow-sm ${getCategoryColor(reward.category)}`}>
                          {reward.category}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Content Section */}
                    <div className="p-4 space-y-3">
                      {/* Title and Description - Close together */}
                      <div className="space-y-1">
                        <h3 className="font-bold text-gray-900 text-sm leading-tight line-clamp-1">
                          {reward.name}
                        </h3>
                        <p className="text-xs text-gray-500 line-clamp-1">
                          {reward.description}
                        </p>
                      </div>
                      
                      {/* Redeem Button with Points */}
                      <Button 
                        size="sm" 
                        className="w-full h-10 text-sm font-medium bg-gradient-to-r from-[var(--police-blue)] to-blue-600 hover:from-blue-600 hover:to-[var(--police-blue)] shadow-md hover:shadow-lg transition-all duration-300"
                        disabled={((userStats as any)?.points || 0) < reward.pointsCost}
                      >
                        {((userStats as any)?.points || 0) >= reward.pointsCost ? (
                          <div className="flex items-center justify-center w-full space-x-2">
                            <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                              {reward.pointsCost}
                            </span>
                            <Zap className="h-3 w-3" />
                            <span>Redeem</span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center w-full space-x-2">
                            <span className="bg-white/20 px-2 py-1 rounded-full text-xs font-bold">
                              {reward.pointsCost}
                            </span>
                            <Shield className="h-3 w-3" />
                            <span>Need More</span>
                          </div>
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* How to Earn Points - Compact */}
            <Card className="border border-green-100 bg-green-50">
              <CardContent className="p-3">
                <h4 className="text-sm font-medium text-green-800 mb-2">How to Earn Points?</h4>
                <ul className="text-xs text-green-700 space-y-0.5">
                  <li>• Submit reports: +10 pts • Verified: +25 pts bonus</li>
                  <li>• Quality evidence: +5 pts • Regular use: Weekly bonus</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "leaderboard" && (
          <div className="px-4 space-y-4">
            <Card className="border border-gray-100 shadow-md">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Trophy className="h-5 w-5 mr-2 text-[var(--police-blue)]" />
                  Top Contributors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {(leaderboard || []).map((contributor: any, index: number) => (
                    <div key={contributor.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <img
                            src={contributor.profilePicture || `https://images.unsplash.com/photo-150${7 + index}003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100`}
                            alt={contributor.name}
                            className="w-12 h-12 rounded-full border-2 border-white shadow-sm"
                          />
                          <div className={`absolute -top-1 -right-1 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold ${getRankBadgeColor(index + 1)}`}>
                            {index + 1}
                          </div>
                        </div>
                        <div>
                          <div className="font-medium text-gray-800 flex items-center space-x-2">
                            <span>{contributor.name}</span>
                            {index < 3 && getRankIcon(index + 1)}
                          </div>
                          <div className="text-xs text-gray-500">{contributor.location}</div>
                          <div className="text-xs text-gray-500">{contributor.reportCount || 0} reports</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-[var(--police-blue)] text-lg">
                          {contributor.points}
                        </div>
                        <div className="text-xs text-gray-500">points</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* User's Position */}
            {user && userStats && (
              <Card className="border border-blue-100 bg-blue-50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <img
                        src={(user as any).profilePicture || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100"}
                        alt={(user as any).name}
                        className="w-10 h-10 rounded-full border-2 border-white shadow-sm"
                      />
                      <div>
                        <div className="font-medium text-gray-800">{(user as any).name}</div>
                        <div className="text-xs text-gray-600">Your Position</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-[var(--police-blue)]">#{userStats.rank}</div>
                      <div className="text-xs text-gray-600">{userStats.points} pts</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </main>

      <BottomNavigation />
    </div>
  );
}
