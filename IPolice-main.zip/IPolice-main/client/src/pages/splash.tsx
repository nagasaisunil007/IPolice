import { useEffect } from 'react';
import { useLocation } from 'wouter';

export default function Splash() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const timer = setTimeout(() => {
      // Always go to login screen after splash
      setLocation('/login');
    }, 2500);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 flex items-center justify-center relative overflow-hidden">
      {/* Mobile-optimized container with proper safe areas */}
      <div className="w-full max-w-sm mx-auto px-6 py-8 text-center space-y-6 sm:space-y-8 animate-fade-in relative z-10">
        {/* App Logo/Icon - Responsive sizing */}
        <div className="relative flex justify-center">
          <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full flex items-center justify-center shadow-2xl">
            <svg 
              className="w-10 h-10 sm:w-12 sm:h-12 text-blue-600" 
              fill="currentColor" 
              viewBox="0 0 24 24"
            >
              <path d="M12 2L13.09 8.26L20 9L13.09 9.74L12 16L10.91 9.74L4 9L10.91 8.26L12 2Z"/>
              <path d="M12 10C13.1 10 14 10.9 14 12S13.1 14 12 14 10 13.1 10 12 10.9 10 12 10Z"/>
            </svg>
          </div>
          {/* Pulse animation rings - Responsive */}
          <div className="absolute inset-0 w-20 h-20 sm:w-24 sm:h-24 mx-auto rounded-full border-2 border-white/30 animate-ping"></div>
          <div className="absolute inset-0 w-28 h-28 sm:w-32 sm:h-32 mx-auto -mt-4 -ml-4 rounded-full border border-white/20 animate-pulse"></div>
        </div>

        {/* App Name - Responsive text sizing */}
        <div className="space-y-2">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight">
            iPolice
          </h1>
          <p className="text-base sm:text-lg text-blue-100 leading-tight px-2">
            Revolutionizing Traffic Management in Bengaluru
          </p>
        </div>

        {/* Loading Spinner */}
        <div className="flex justify-center py-2">
          <div className="w-8 h-8 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
        </div>

        {/* Tagline - Mobile optimized */}
        <p className="text-xs sm:text-sm text-blue-200/80 px-4">
          Empowering Citizens • Building Safer Communities
        </p>
      </div>

      {/* Background decorative elements - Hidden on very small screens */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/5 rounded-full"></div>
        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-white/5 rounded-full"></div>
        <div className="absolute top-1/3 -right-5 w-20 h-20 bg-white/5 rounded-full"></div>
      </div>
    </div>
  );
}