import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { firebaseRealtime } from "@/lib/firebase-realtime";
import TopHUD from "@/components/layout/top-hud";
import BottomNavigation from "@/components/layout/bottom-navigation";
import EvidencePopup from "@/components/shared/evidence-popup";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  FileText, 
  MapPin, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Calendar,
  Star,
  TrendingUp,
  Award,
  AlertTriangle,
  Eye,
  Filter,
  BarChart3,
  ChevronDown,
  X,
  Phone,
  User,
  Hash,
  Heart,
  MessageCircle,
  Share2,
  ThumbsUp,
  Bookmark
} from "lucide-react";

// Mock current user ID
const CURRENT_USER_ID = 1;

interface Report {
  id: number;
  title: string;
  description: string;
  location: string;
  violationType: string;
  status: string;
  points: number;
  createdAt: string;
  verifiedAt?: string;
  mediaUrl?: string;
  mediaType?: string;
}

export default function ViewReports() {
  const [showEvidencePopup, setShowEvidencePopup] = useState(false);
  const [likedReports, setLikedReports] = useState<number[]>([]);
  const [bookmarkedReports, setBookmarkedReports] = useState<number[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: reports, isLoading } = useQuery<Report[]>({
    queryKey: ["/api/reports"],
    queryFn: () => firebaseRealtime.getAllReports(),
  });

  // Like report functionality
  const toggleLike = (reportId: number) => {
    setLikedReports(prev => 
      prev.includes(reportId) 
        ? prev.filter(id => id !== reportId)
        : [...prev, reportId]
    );
    
    toast({
      title: likedReports.includes(reportId) ? "Like Removed" : "Report Liked",
      description: likedReports.includes(reportId) ? "Removed from your liked reports" : "Added to your liked reports",
    });
  };

  // Bookmark report functionality
  const toggleBookmark = (reportId: number) => {
    setBookmarkedReports(prev => 
      prev.includes(reportId) 
        ? prev.filter(id => id !== reportId)
        : [...prev, reportId]
    );
    
    toast({
      title: bookmarkedReports.includes(reportId) ? "Bookmark Removed" : "Report Bookmarked",
      description: bookmarkedReports.includes(reportId) ? "Removed from your bookmarks" : "Saved to your bookmarks",
    });
  };

  // Share report functionality
  const shareReport = (report: Report) => {
    if (navigator.share) {
      navigator.share({
        title: report.title,
        text: `Check out this traffic violation report: ${report.description}`,
        url: window.location.href,
      });
    } else {
      // Fallback to copying to clipboard
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Report link copied to clipboard",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "verified":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      default:
        return "bg-yellow-100 text-yellow-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "verified":
        return <CheckCircle className="h-4 w-4" />;
      case "rejected":
        return <XCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const filterReports = (reports: Report[], status?: string) => {
    if (!status) return reports;
    return reports.filter(report => report.status === status);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <TopHUD />
        <div className="max-w-md mx-auto bg-white min-h-screen pb-20">
          <div className="animate-pulse space-y-4 p-4">
            <div className="h-12 bg-gray-200 rounded-lg"></div>
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
        <BottomNavigation onEvidenceClick={() => setShowEvidencePopup(true)} />
      </div>
    );
  }

  const allReports: Report[] = reports || [];
  const pendingReports = filterReports(allReports, "pending");
  const verifiedReports = filterReports(allReports, "verified");
  const rejectedReports = filterReports(allReports, "rejected");

  const ReportCard = ({ report }: { report: Report }) => {
    const [isExpanded, setIsExpanded] = React.useState(false);
    
    const getViolationEmoji = (type: string) => {
      switch (type.toLowerCase()) {
        case 'parking': return '🚗';
        case 'traffic': return '🚦';
        case 'noise': return '🔊';
        case 'waste': return '🗑️';
        case 'construction': return '🚧';
        default: return '⚠️';
      }
    };

    const getStatusBadge = (status: string) => {
      switch (status) {
        case "verified": 
          return <div className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-medium">✓ Verified</div>;
        case "rejected": 
          return <div className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium">✕ Rejected</div>;
        default: 
          return <div className="bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-medium">⏱ Pending</div>;
      }
    };

    return (
      <Card className="shadow-md hover:shadow-lg transition-all duration-200 mb-3 bg-white border border-gray-100 rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <div className="flex relative">
            {/* Thumbnail Section - Full Height */}
            <div className="w-24 bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center flex-shrink-0">
              {report.mediaUrl ? (
                report.mediaType === "image" ? (
                  <img
                    src={report.mediaUrl}
                    alt="Evidence"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                    <div className="text-center text-white">
                      <FileText className="h-6 w-6 mx-auto mb-1" />
                      <span className="text-xs">Video</span>
                    </div>
                  </div>
                )
              ) : (
                <span className="text-2xl">{getViolationEmoji(report.violationType)}</span>
              )}
            </div>

            {/* Content Section */}
            <div className="flex-1 p-4 relative">
              {/* Top Status Badge */}
              <div className="absolute top-2 right-2 flex flex-col items-end space-y-1">
                {getStatusBadge(report.status)}
                {report.status === "verified" && report.points > 0 && (
                  <div className="text-xs text-gray-700 flex items-center justify-end space-x-1">
                    <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                    <span className="font-bold">{report.points} pts</span>
                  </div>
                )}
              </div>

              <div className="pr-20 mb-3">
                <h3 className="font-semibold text-gray-800 text-base line-clamp-1 mb-2">{report.title}</h3>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 text-xs text-gray-600">
                    <MapPin className="h-3 w-3 text-blue-500" />
                    <span className="truncate">{report.location}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs text-gray-600">
                    <Calendar className="h-3 w-3 text-green-500" />
                    <span>{new Date(report.createdAt).toLocaleDateString('en-IN', { 
                      weekday: 'short', 
                      month: 'short', 
                      day: 'numeric',
                      year: 'numeric'
                    })}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs text-gray-600">
                    <AlertTriangle className="h-3 w-3 text-orange-500" />
                    <span className="capitalize">{report.violationType} violation</span>
                  </div>
                </div>
              </div>

              {/* Bottom Row - Interaction Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1 h-8 w-8"
                    onClick={() => toggleLike(report.id)}
                  >
                    <Heart className={`h-4 w-4 ${likedReports.includes(report.id) ? 'text-red-500 fill-red-500' : 'text-gray-400'}`} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1 h-8 w-8"
                    onClick={() => toggleBookmark(report.id)}
                  >
                    <Bookmark className={`h-4 w-4 ${bookmarkedReports.includes(report.id) ? 'text-blue-500 fill-blue-500' : 'text-gray-400'}`} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1 h-8 w-8"
                    onClick={() => shareReport(report)}
                  >
                    <Share2 className="h-4 w-4 text-gray-400" />
                  </Button>
                </div>
                <button 
                  onClick={() => setIsExpanded(!isExpanded)}
                  className="text-xs text-gray-400 hover:text-gray-600 transition-colors flex items-center space-x-1"
                >
                  <span>{isExpanded ? 'Less' : 'Details'}</span>
                  <ChevronDown className={`h-3 w-3 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                </button>
              </div>

              {/* Expanded Content */}
              {isExpanded && (
                <div className="fixed top-16 bottom-16 left-0 right-0 bg-white z-50 overflow-y-auto max-w-md mx-auto border-t border-b border-gray-200">
                  {/* Header */}
                  <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-semibold">Report Details</h2>
                      <div className="flex items-center space-x-2 mt-1">
                        <Hash className="h-3 w-3" />
                        <span className="text-sm opacity-90">ID: RPT-{String(report.id).padStart(6, '0')}</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => setIsExpanded(false)}
                      className="p-2 hover:bg-white/20 rounded-full transition-colors"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>

                  <div className="p-4 space-y-6">
                    {/* Evidence Section - Always show */}
                    <div className="bg-purple-50 rounded-xl p-4">
                      <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                        <Eye className="h-4 w-4 mr-2 text-purple-600" />
                        Evidence ({report.mediaUrl ? (report.mediaType === 'image' ? 'Image' : 'Video') : 'No Evidence'})
                      </h3>
                      <div className="bg-white rounded-lg p-3">
                        {report.mediaUrl ? (
                          <>
                            {report.mediaType === 'image' ? (
                              <img
                                src={report.mediaUrl}
                                alt="Evidence"
                                className="w-full h-40 object-cover rounded-lg"
                              />
                            ) : (
                              <div className="w-full h-40 bg-gray-800 rounded-lg flex items-center justify-center">
                                <div className="text-center text-white">
                                  <FileText className="h-8 w-8 mx-auto mb-2" />
                                  <span className="text-sm">Video Evidence</span>
                                </div>
                              </div>
                            )}
                            <div className="mt-3 text-sm text-gray-700">
                              <p><span className="font-medium">Captured:</span> {new Date(report.createdAt).toLocaleDateString('en-IN', { 
                                weekday: 'short', 
                                month: 'short', 
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}</p>
                              <p><span className="font-medium">Quality:</span> High Resolution</p>
                            </div>
                          </>
                        ) : (
                          <div className="w-full h-40 bg-gray-100 rounded-lg flex items-center justify-center">
                            <div className="text-center text-gray-500">
                              <Eye className="h-8 w-8 mx-auto mb-2" />
                              <span className="text-sm">No evidence submitted</span>
                              <p className="text-xs mt-1">Report submitted without media</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Map Section */}
                    <div className="bg-blue-50 rounded-xl p-4">
                      <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                        <MapPin className="h-4 w-4 mr-2 text-blue-600" />
                        Location Details
                      </h3>
                      <div className="bg-gradient-to-br from-blue-50 to-green-50 h-48 rounded-lg mb-3 relative overflow-hidden border border-gray-200">
                        {/* Enhanced Interactive Map */}
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-100 via-green-50 to-yellow-50">
                          {/* Street Grid */}
                          <div className="absolute inset-0">
                            {/* Major Roads */}
                            <div className="absolute top-12 left-0 right-0 h-6 bg-gray-600 opacity-70 rounded-sm"></div>
                            <div className="absolute top-32 left-0 right-0 h-4 bg-gray-500 opacity-60 rounded-sm"></div>
                            <div className="absolute top-0 bottom-0 left-16 w-5 bg-gray-600 opacity-70 rounded-sm"></div>
                            <div className="absolute top-0 bottom-0 left-32 w-3 bg-gray-500 opacity-60 rounded-sm"></div>
                            
                            {/* Lane markings */}
                            <div className="absolute top-14 left-0 right-0 h-0.5 bg-white opacity-80"></div>
                            <div className="absolute top-34 left-0 right-0 h-0.5 bg-white opacity-80"></div>
                            <div className="absolute top-0 bottom-0 left-18 w-0.5 bg-white opacity-80"></div>
                            
                            {/* Buildings and Landmarks */}
                            <div className="absolute top-4 left-4 w-10 h-6 bg-blue-400 opacity-70 rounded shadow-sm"></div>
                            <div className="absolute top-20 left-36 w-8 h-8 bg-red-300 opacity-70 rounded shadow-sm"></div>
                            <div className="absolute top-36 left-8 w-6 h-12 bg-yellow-400 opacity-70 rounded shadow-sm"></div>
                            <div className="absolute top-6 left-24 w-12 h-4 bg-green-400 opacity-70 rounded shadow-sm"></div>
                            
                            {/* Traffic elements */}
                            <div className="absolute top-11 left-15 w-1 h-3 bg-gray-800 rounded-full"></div>
                            <div className="absolute top-31 left-31 w-1 h-3 bg-gray-800 rounded-full"></div>
                            
                            {/* Violation location with pulsing effect */}
                            <div className="absolute top-16 left-20 transform -translate-x-1/2 -translate-y-1/2">
                              <div className="relative">
                                <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse absolute"></div>
                                <div className="w-8 h-8 bg-red-500 rounded-full opacity-30 animate-ping absolute -top-2 -left-2"></div>
                                <div className="w-6 h-6 bg-red-600 rounded-full border-2 border-white shadow-lg flex items-center justify-center relative z-10">
                                  <div className="w-2 h-2 bg-white rounded-full"></div>
                                </div>
                                <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-red-600 text-white text-xs px-2 py-1 rounded-md whitespace-nowrap shadow-lg z-20">
                                  🚨 Violation Site
                                  <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-red-600 rotate-45"></div>
                                </div>
                              </div>
                            </div>
                            
                            {/* Interactive Elements */}
                            <div className="absolute bottom-4 left-4 bg-white bg-opacity-90 rounded-lg px-2 py-1 text-xs text-gray-700 shadow">
                              📍 Bengaluru, Karnataka
                            </div>
                            
                            {/* Compass */}
                            <div className="absolute top-4 left-4 w-8 h-8 bg-white bg-opacity-90 rounded-full shadow flex items-center justify-center text-xs font-bold">
                              N
                            </div>
                            
                            {/* Zoom controls */}
                            <div className="absolute top-4 right-4 flex flex-col space-y-1">
                              <button className="w-8 h-8 bg-white bg-opacity-90 rounded shadow flex items-center justify-center text-sm font-bold hover:bg-opacity-100 transition-all">+</button>
                              <button className="w-8 h-8 bg-white bg-opacity-90 rounded shadow flex items-center justify-center text-sm font-bold hover:bg-opacity-100 transition-all">-</button>
                            </div>
                            
                            {/* Scale */}
                            <div className="absolute bottom-4 right-4 flex items-center space-x-2 bg-white bg-opacity-90 rounded px-2 py-1 text-xs">
                              <div className="w-8 h-0.5 bg-gray-700"></div>
                              <span>100m</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-sm text-gray-700">
                        <p><span className="font-medium">Address:</span> {report.location}</p>
                        <p><span className="font-medium">Coordinates:</span> 12.9716° N, 77.5946° E</p>
                      </div>
                    </div>

                    {/* Violation Details */}
                    <div className="bg-red-50 rounded-xl p-4">
                      <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2 text-red-600" />
                        Violation Details
                      </h3>
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm font-medium text-gray-800">{report.title}</p>
                          <p className="text-xs text-gray-600 mt-1 leading-relaxed">{report.description}</p>
                        </div>
                        <div className="text-sm text-gray-700">
                          <p><span className="font-medium">Category:</span> {report.violationType.charAt(0).toUpperCase() + report.violationType.slice(1)} Violation</p>
                          <p><span className="font-medium">Severity:</span> Medium Priority</p>
                          <p><span className="font-medium">Fine Amount:</span> ₹{report.violationType === 'parking' ? '500' : '1000'}</p>
                        </div>
                      </div>
                    </div>

                    {/* Status Timeline */}
                    <div className="bg-green-50 rounded-xl p-4">
                      <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                        <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                        Processing Status
                      </h3>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-800">Report Submitted</p>
                            <p className="text-xs text-gray-500">2 hours ago</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${report.status !== 'pending' ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-800">Under Review</p>
                            <p className="text-xs text-gray-500">{report.status !== 'pending' ? '1.5 hours ago' : 'In progress'}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${report.status === 'verified' ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-800">Verified & Processed</p>
                            <p className="text-xs text-gray-500">
                              {report.status === 'verified' && report.verifiedAt 
                                ? new Date(report.verifiedAt).toLocaleDateString('en-IN', { 
                                    month: 'short', 
                                    day: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })
                                : 'Pending verification'
                              }
                            </p>
                          </div>
                        </div>
                        {report.status === 'verified' && (
                          <div className="flex items-center space-x-3">
                            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-800">Points Awarded</p>
                              <p className="text-xs text-gray-500">+{report.points} community points earned</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>



                    {/* Action Buttons */}
                    <div className="flex space-x-3 pt-4">
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => toggleLike(report.id)}
                      >
                        <Heart className={`h-4 w-4 mr-2 ${likedReports.includes(report.id) ? 'text-red-500 fill-red-500' : ''}`} />
                        {likedReports.includes(report.id) ? 'Liked' : 'Like'}
                      </Button>
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => shareReport(report)}
                      >
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                      <button 
                        onClick={() => setIsExpanded(false)}
                        className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors"
                      >
                        Close Details
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100">
      <TopHUD />
      
      <main className="max-w-md mx-auto bg-white min-h-screen pb-20 shadow-xl">
        {/* Modern Header Section */}
        <div className="bg-gradient-to-r from-[var(--police-blue)] to-blue-600 text-white px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold">My Reports</h1>
              <p className="text-blue-100 text-sm">Track your civic contributions</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3">
              <BarChart3 className="h-6 w-6" />
            </div>
          </div>
        </div>

        {/* Compact Stats Section */}
        <div className="px-4 -mt-4 mb-4">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-4">
            <div className="grid grid-cols-4 gap-3">
              <div className="text-center">
                <div className="text-xl font-bold text-gray-800">{allReports.length}</div>
                <div className="text-xs text-gray-500 flex items-center justify-center">
                  <FileText className="h-3 w-3 mr-1 text-blue-500" />
                  Total
                </div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-green-600">{verifiedReports.length}</div>
                <div className="text-xs text-gray-500 flex items-center justify-center">
                  <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                  Verified
                </div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-yellow-600">{pendingReports.length}</div>
                <div className="text-xs text-gray-500 flex items-center justify-center">
                  <Clock className="h-3 w-3 mr-1 text-yellow-500" />
                  Pending
                </div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-purple-600">
                  {allReports.length > 0 ? Math.round((verifiedReports.length / allReports.length) * 100) : 0}%
                </div>
                <div className="text-xs text-gray-500 flex items-center justify-center">
                  <TrendingUp className="h-3 w-3 mr-1 text-purple-500" />
                  Success
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 pb-6">{/* Filter Tabs Section */}

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-100 p-1 rounded-xl shadow-inner">
              <TabsTrigger 
                value="all" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-md data-[state=active]:text-[var(--police-blue)] rounded-lg font-medium transition-all"
              >
                All
              </TabsTrigger>
              <TabsTrigger 
                value="pending" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-md data-[state=active]:text-yellow-600 rounded-lg font-medium transition-all"
              >
                Pending
              </TabsTrigger>
              <TabsTrigger 
                value="verified" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-md data-[state=active]:text-green-600 rounded-lg font-medium transition-all"
              >
                Verified
              </TabsTrigger>
              <TabsTrigger 
                value="rejected" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-md data-[state=active]:text-red-600 rounded-lg font-medium transition-all"
              >
                Rejected
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              {allReports.length === 0 ? (
                <Card className="bg-gradient-to-br from-gray-50 to-gray-100 border-2 border-dashed border-gray-300 shadow-lg">
                  <CardContent className="p-8 text-center">
                    <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <FileText className="h-8 w-8 text-blue-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-2">No reports yet</h3>
                    <p className="text-gray-600 mb-6">Start making a difference in your community by reporting violations</p>
                    <Button className="bg-gradient-to-r from-[var(--police-blue)] to-blue-600 hover:from-blue-700 hover:to-blue-800 text-white px-6 py-2 rounded-xl shadow-lg transition-all">
                      Submit Your First Report
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4 pb-4">
                  {allReports.map((report: Report) => (
                    <ReportCard key={report.id} report={report} />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="pending" className="mt-6">
              {pendingReports.length === 0 ? (
                <Card className="bg-gradient-to-br from-yellow-50 to-amber-50 border-2 border-dashed border-yellow-300 shadow-lg">
                  <CardContent className="p-8 text-center">
                    <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Clock className="h-8 w-8 text-yellow-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-2">No pending reports</h3>
                    <p className="text-gray-600">All your reports have been processed</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4 pb-4">
                  {pendingReports.map((report: Report) => (
                    <ReportCard key={report.id} report={report} />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="verified" className="mt-6">
              {verifiedReports.length === 0 ? (
                <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-dashed border-green-300 shadow-lg">
                  <CardContent className="p-8 text-center">
                    <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <CheckCircle className="h-8 w-8 text-green-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-2">No verified reports yet</h3>
                    <p className="text-gray-600">Keep reporting to earn verification badges</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4 pb-4">
                  {verifiedReports.map((report: Report) => (
                    <ReportCard key={report.id} report={report} />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="rejected" className="mt-6">
              {rejectedReports.length === 0 ? (
                <Card className="bg-gradient-to-br from-red-50 to-rose-50 border-2 border-dashed border-red-300 shadow-lg">
                  <CardContent className="p-8 text-center">
                    <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <XCircle className="h-8 w-8 text-red-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-2">No rejected reports</h3>
                    <p className="text-gray-600">Great job maintaining quality reports!</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4 pb-4">
                  {rejectedReports.map((report: Report) => (
                    <ReportCard key={report.id} report={report} />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <BottomNavigation onEvidenceClick={() => setShowEvidencePopup(true)} />
      
      <EvidencePopup 
        isOpen={showEvidencePopup} 
        onClose={() => setShowEvidencePopup(false)} 
      />
    </div>
  );
}
