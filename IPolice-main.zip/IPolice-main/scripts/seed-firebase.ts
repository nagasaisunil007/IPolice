import { database } from '../shared/firebase';
import { ref, set } from 'firebase/database';

const seedData = {
  users: {
    user1: {
      id: 1,
      username: "rajesh.kumar",
      password: "password123",
      name: "Karan Singh",
      location: "Koramangala, Bengaluru",
      profilePicture: null,
      points: 1250,
      rank: 1,
      level: 3,
      pointsToNextLevel: 250
    },
    user2: {
      id: 2,
      username: "priya.sharma",
      password: "password123",
      name: "Priya Sharma",
      location: "Indiranagar, Bengaluru",
      profilePicture: null,
      points: 980,
      rank: 2,
      level: 2,
      pointsToNextLevel: 20
    },
    user3: {
      id: 3,
      username: "amit.tech",
      password: "password123",
      name: "Amit Patel",
      location: "Whitefield, Bengaluru",
      profilePicture: null,
      points: 750,
      rank: 3,
      level: 2,
      pointsToNextLevel: 250
    },
    user4: {
      id: 4,
      username: "sarah.wilson",
      password: "password123",
      name: "Sarah Wilson",
      location: "HSR Layout, Bengaluru",
      profilePicture: null,
      points: 620,
      rank: 4,
      level: 2,
      pointsToNextLevel: 380
    },
    user5: {
      id: 5,
      username: "david.chen",
      password: "password123",
      name: "David Chen",
      location: "Electronic City, Bengaluru",
      profilePicture: null,
      points: 540,
      rank: 5,
      level: 2,
      pointsToNextLevel: 460
    }
  },
  reports: {
    report1: {
      id: 1,
      userId: 1,
      title: "Illegal Parking in No-Parking Zone",
      description: "Multiple vehicles parked in a clearly marked no-parking zone outside Metro Station",
      location: "MG Road Metro Station, Bengaluru",
      violationType: "illegal_parking",
      status: "verified",
      points: 50,
      mediaUrl: null,
      mediaType: null,
      createdAt: new Date("2025-01-20T10:30:00Z"),
      verifiedAt: new Date("2025-01-20T14:15:00Z")
    },
    report2: {
      id: 2,
      userId: 1,
      title: "Traffic Light Violation",
      description: "Car ran through red light at busy intersection during peak hours",
      location: "Silk Board Junction, Bengaluru",
      violationType: "traffic_signal",
      status: "verified",
      points: 75,
      mediaUrl: null,
      mediaType: null,
      createdAt: new Date("2025-01-19T16:45:00Z"),
      verifiedAt: new Date("2025-01-19T18:30:00Z")
    },
    report3: {
      id: 3,
      userId: 1,
      title: "Wrong Way Driving",
      description: "Motorcycle driving against traffic flow on one-way street",
      location: "Brigade Road, Bengaluru",
      violationType: "wrong_way",
      status: "pending",
      points: 0,
      mediaUrl: null,
      mediaType: null,
      createdAt: new Date("2025-01-21T12:20:00Z"),
      verifiedAt: null
    },
    report4: {
      id: 4,
      userId: 5,
      title: "Overspeeding in School Zone",
      description: "Vehicle speeding through school zone during school hours",
      location: "Near DPS School, Indiranagar",
      violationType: "overspeeding",
      status: "verified",
      points: 100,
      mediaUrl: null,
      mediaType: null,
      createdAt: new Date("2025-01-18T08:15:00Z"),
      verifiedAt: new Date("2025-01-18T10:45:00Z")
    }
  },
  rewards: {
    reward1: {
      id: 114,
      name: "Reflective Sticker",
      description: "High-visibility reflective sticker for vehicle safety",
      pointsCost: 50,
      category: "safety",
      imageUrl: null,
      available: true
    },
    reward2: {
      id: 115,
      name: "Traffic Safety Handbook",
      description: "Comprehensive guide to road safety and traffic rules",
      pointsCost: 100,
      category: "education",
      imageUrl: null,
      available: true
    },
    reward3: {
      id: 116,
      name: "Emergency Kit",
      description: "Basic emergency kit for vehicles including first aid supplies",
      pointsCost: 200,
      category: "safety",
      imageUrl: null,
      available: true
    },
    reward4: {
      id: 117,
      name: "Dashcam Discount Voucher",
      description: "25% discount voucher for dashboard camera purchase",
      pointsCost: 300,
      category: "technology",
      imageUrl: null,
      available: true
    },
    reward5: {
      id: 118,
      name: "Traffic Police Appreciation Certificate",
      description: "Official certificate of appreciation from Bengaluru Traffic Police",
      pointsCost: 500,
      category: "recognition",
      imageUrl: null,
      available: true
    }
  },
  activities: {
    activity1: {
      id: 1,
      userId: 1,
      type: "report_verified",
      title: "Report Verified",
      description: "Your illegal parking report has been verified. You earned 50 points!",
      points: 50,
      createdAt: new Date("2025-01-20T14:15:00Z"),
      metadata: JSON.stringify({ reportId: 1, location: "MG Road Metro Station" })
    },
    activity2: {
      id: 2,
      userId: 1,
      type: "report_verified",
      title: "Report Verified",
      description: "Your traffic light violation report has been verified. You earned 75 points!",
      points: 75,
      createdAt: new Date("2025-01-19T18:30:00Z"),
      metadata: JSON.stringify({ reportId: 2, location: "Silk Board Junction" })
    },
    activity3: {
      id: 3,
      userId: 1,
      type: "level_up",
      title: "Level Up!",
      description: "Congratulations! You've reached Level 3. Keep up the great work!",
      points: 0,
      createdAt: new Date("2025-01-19T18:35:00Z"),
      metadata: JSON.stringify({ newLevel: 3, totalPoints: 1250 })
    }
  }
};

export async function seedFirebase() {
  try {
    console.log('Starting Firebase data seeding...');
    
    // Set all data at once
    await set(ref(database), seedData);
    
    console.log('Firebase database seeded successfully!');
    console.log('Sample data includes:');
    console.log(`- ${Object.keys(seedData.users).length} users`);
    console.log(`- ${Object.keys(seedData.reports).length} reports`);
    console.log(`- ${Object.keys(seedData.rewards).length} rewards`);
    console.log(`- ${Object.keys(seedData.activities).length} activities`);
  } catch (error) {
    console.error('Error seeding Firebase:', error);
    throw error;
  }
}

// Run seeding
seedFirebase().then(() => process.exit(0)).catch(() => process.exit(1));