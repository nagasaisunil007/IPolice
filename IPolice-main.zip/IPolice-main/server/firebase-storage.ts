import { database } from '../shared/firebase';
import { ref, push, set, get, query, orderByChild, limitToLast, equalTo, orderByKey, update } from 'firebase/database';
import type { User, Report, Reward, Activity, InsertUser, InsertReport, InsertReward, InsertActivity } from '../shared/types';

export class FirebaseStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const user = await this.getUserById(id);
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const usersRef = ref(database, 'users');
    const newUserRef = push(usersRef);
    const id = parseInt(newUserRef.key!.replace(/[^0-9]/g, '').slice(-6)) || Date.now() % 1000000;
    
    const newUser: User = { 
      ...user, 
      id,
      points: user.points || 0,
      rank: user.rank || 0,
      level: user.level || 1,
      pointsToNextLevel: user.pointsToNextLevel || 500
    };
    await set(newUserRef, newUser);
    return newUser;
  }

  async getUserById(id: number): Promise<User | null> {
    const usersRef = ref(database, 'users');
    const snapshot = await get(usersRef);
    const users = snapshot.val();
    
    if (!users) return null;
    
    const userEntry = Object.entries(users).find(([_, user]: [string, any]) => user.id === id);
    return userEntry ? userEntry[1] as User : null;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const usersRef = ref(database, 'users');
    const snapshot = await get(query(usersRef, orderByChild('username'), equalTo(username)));
    const users = snapshot.val();
    
    if (!users) return undefined;
    
    const userKey = Object.keys(users)[0];
    return users[userKey] as User;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | null> {
    const user = await this.getUserById(id);
    if (!user) return null;

    const usersRef = ref(database, 'users');
    const snapshot = await get(usersRef);
    const users = snapshot.val();
    
    const userEntry = Object.entries(users).find(([_, u]: [string, any]) => u.id === id);
    if (!userEntry) return null;

    const userKey = userEntry[0];
    const updatedUser = { ...user, ...updates };
    
    await update(ref(database, `users/${userKey}`), updatedUser);
    return updatedUser;
  }

  async updateUserPoints(id: number, points: number): Promise<User | undefined> {
    const level = Math.floor(points / 500) + 1;
    const pointsToNextLevel = (level * 500) - points;
    
    const result = await this.updateUser(id, { points, level, pointsToNextLevel });
    return result || undefined;
  }

  async updateUserRank(id: number, rank: number): Promise<User | undefined> {
    const result = await this.updateUser(id, { rank });
    return result || undefined;
  }

  async getTopUsers(limit: number): Promise<User[]> {
    return this.getLeaderboard(limit);
  }

  // Reports
  async createReport(report: Omit<Report, 'id'>): Promise<Report> {
    const reportsRef = ref(database, 'reports');
    const newReportRef = push(reportsRef);
    const id = parseInt(newReportRef.key!.replace(/[^0-9]/g, '').slice(-6)) || Date.now() % 1000000;
    
    const newReport = { ...report, id, createdAt: new Date() };
    await set(newReportRef, newReport);
    return newReport;
  }

  async getReportById(id: number): Promise<Report | null> {
    const reportsRef = ref(database, 'reports');
    const snapshot = await get(reportsRef);
    const reports = snapshot.val();
    
    if (!reports) return null;
    
    const reportEntry = Object.entries(reports).find(([_, report]: [string, any]) => report.id === id);
    return reportEntry ? reportEntry[1] as Report : null;
  }

  async getReports(): Promise<Report[]> {
    try {
      const reportsRef = ref(database, 'reports');
      const snapshot = await get(reportsRef);
      const reports = snapshot.val();
      
      if (!reports) return [];
      
      return Object.values(reports)
        .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) as Report[];
    } catch (error) {
      console.error('Error in getReports:', error);
      throw error;
    }
  }

  async getReportsByUser(userId: number): Promise<Report[]> {
    try {
      const reportsRef = ref(database, 'reports');
      const snapshot = await get(reportsRef);
      const reports = snapshot.val();
      
      if (!reports) return [];
      
      return Object.values(reports)
        .filter((report: any) => report.userId === userId) as Report[];
    } catch (error) {
      console.error('Error in getReportsByUser:', error);
      throw error;
    }
  }

  async updateReport(id: number, updates: Partial<Report>): Promise<Report | null> {
    const report = await this.getReportById(id);
    if (!report) return null;

    const reportsRef = ref(database, 'reports');
    const snapshot = await get(reportsRef);
    const reports = snapshot.val();
    
    const reportEntry = Object.entries(reports).find(([_, r]: [string, any]) => r.id === id);
    if (!reportEntry) return null;

    const reportKey = reportEntry[0];
    const updatedReport = { ...report, ...updates };
    
    await update(ref(database, `reports/${reportKey}`), updatedReport);
    return updatedReport;
  }

  async getReportsByUserId(userId: number): Promise<Report[]> {
    return this.getReportsByUser(userId);
  }

  async getReport(id: number): Promise<Report | undefined> {
    const report = await this.getReportById(id);
    return report || undefined;
  }

  async updateReportStatus(id: number, status: string, points?: number): Promise<Report | undefined> {
    const updates: Partial<Report> = { status };
    if (status === 'verified') {
      updates.verifiedAt = new Date();
      if (points) {
        // Also update user points
        const report = await this.getReportById(id);
        if (report) {
          const user = await this.getUserById(report.userId);
          if (user) {
            await this.updateUserPoints(user.id, user.points + points);
          }
        }
      }
    }
    const result = await this.updateReport(id, updates);
    return result || undefined;
  }

  async getAllReports(): Promise<Report[]> {
    return this.getReports();
  }

  // Rewards
  async createReward(reward: Omit<Reward, 'id'>): Promise<Reward> {
    const rewardsRef = ref(database, 'rewards');
    const newRewardRef = push(rewardsRef);
    const id = parseInt(newRewardRef.key!.replace(/[^0-9]/g, '').slice(-6)) || Date.now() % 1000000;
    
    const newReward = { ...reward, id };
    await set(newRewardRef, newReward);
    return newReward;
  }

  async getAllRewards(): Promise<Reward[]> {
    return this.getRewards();
  }

  async getRewards(): Promise<Reward[]> {
    const rewardsRef = ref(database, 'rewards');
    const snapshot = await get(rewardsRef);
    const rewards = snapshot.val();
    
    if (!rewards) return [];
    
    return Object.values(rewards) as Reward[];
  }

  async getReward(id: number): Promise<Reward | undefined> {
    const reward = await this.getRewardById(id);
    return reward || undefined;
  }

  async getRewardById(id: number): Promise<Reward | null> {
    const rewardsRef = ref(database, 'rewards');
    const snapshot = await get(rewardsRef);
    const rewards = snapshot.val();
    
    if (!rewards) return null;
    
    const rewardEntry = Object.entries(rewards).find(([_, reward]: [string, any]) => reward.id === id);
    return rewardEntry ? rewardEntry[1] as Reward : null;
  }

  // Activities
  async createActivity(activity: Omit<Activity, 'id'>): Promise<Activity> {
    const activitiesRef = ref(database, 'activities');
    const newActivityRef = push(activitiesRef);
    const id = parseInt(newActivityRef.key!.replace(/[^0-9]/g, '').slice(-6)) || Date.now() % 1000000;
    
    const newActivity = { ...activity, id, createdAt: new Date() };
    await set(newActivityRef, newActivity);
    return newActivity;
  }

  async getActivitiesByUser(userId: number): Promise<Activity[]> {
    try {
      const activitiesRef = ref(database, 'activities');
      const snapshot = await get(activitiesRef);
      const activities = snapshot.val();
      
      if (!activities) return [];
      
      return Object.values(activities)
        .filter((activity: any) => activity.userId === userId) as Activity[];
    } catch (error) {
      console.error('Error in getActivitiesByUser:', error);
      throw error;
    }
  }

  async getActivitiesByUserId(userId: number, limit?: number): Promise<Activity[]> {
    const activities = await this.getActivitiesByUser(userId);
    return limit ? activities.slice(0, limit) : activities;
  }

  // Leaderboard
  async getLeaderboard(limit: number = 10): Promise<User[]> {
    try {
      const usersRef = ref(database, 'users');
      const snapshot = await get(usersRef);
      const users = snapshot.val();
      
      if (!users) return [];
      
      return Object.values(users)
        .sort((a: any, b: any) => (b.points || 0) - (a.points || 0))
        .slice(0, limit) as User[];
    } catch (error) {
      console.error('Error in getLeaderboard:', error);
      throw error;
    }
  }

  // User stats
  async getUserStats(userId: number): Promise<{
    totalReports: number;
    verifiedReports: number;
    pendingReports: number;
    points: number;
    rank: string;
    level: number;
  } | null> {
    try {
      const user = await this.getUserById(userId);
      if (!user) return null;

      const reports = await this.getReportsByUser(userId);
      const totalReports = reports.length;
      const verifiedReports = reports.filter(r => r.status === 'verified').length;
      const pendingReports = reports.filter(r => r.status === 'pending').length;

      return {
        totalReports,
        verifiedReports,
        pendingReports,
        points: user.points || 0,
        rank: (user.rank || 1).toString(),
        level: user.level || 1
      };
    } catch (error) {
      console.error('Error in getUserStats:', error);
      throw error;
    }
  }
}