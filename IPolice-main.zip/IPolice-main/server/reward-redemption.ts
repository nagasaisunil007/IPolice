import { storage } from './storage';

export interface RedemptionRequest {
  userId: number;
  rewardId: number;
}

export interface RedemptionResult {
  success: boolean;
  rewardName: string;
  pointsDeducted: number;
  userPointsRemaining: number;
  redemptionId: string;
  message: string;
}

export async function processRewardRedemption(request: RedemptionRequest): Promise<RedemptionResult> {
  try {
    // Get user and reward details
    const user = await storage.getUserById(request.userId);
    const reward = await storage.getRewardById(request.rewardId);

    if (!user) {
      throw new Error('User not found');
    }

    if (!reward) {
      throw new Error('Reward not found');
    }

    // Check if user has enough points
    if (user.points < reward.pointsCost) {
      throw new Error(`Insufficient points. You need ${reward.pointsCost - user.points} more points.`);
    }

    // Deduct points from user
    const newPointsTotal = user.points - reward.pointsCost;
    await storage.updateUserPoints(request.userId, newPointsTotal);

    // Create activity log for redemption
    await storage.createActivity({
      userId: request.userId,
      type: 'reward_redeemed',
      title: 'Reward Redeemed',
      description: `You redeemed ${reward.name} for ${reward.pointsCost} points`,
      points: -reward.pointsCost,
      metadata: JSON.stringify({
        rewardId: reward.id,
        rewardName: reward.name,
        pointsCost: reward.pointsCost,
        redemptionTime: new Date().toISOString()
      }),
      createdAt: new Date()
    });

    // Generate redemption ID
    const redemptionId = `RD${Date.now()}${request.userId}${request.rewardId}`;

    return {
      success: true,
      rewardName: reward.name,
      pointsDeducted: reward.pointsCost,
      userPointsRemaining: newPointsTotal,
      redemptionId,
      message: `Successfully redeemed ${reward.name}! Your reward will be processed and shipped to your registered address.`
    };
  } catch (error) {
    throw error;
  }
}