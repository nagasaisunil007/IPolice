import type { Express } from "express";
import { createServer, type Server } from "http";
import express from "express";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { z } from "zod";

// Firebase-compatible validation schemas
const insertUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().min(2, "Name must be at least 2 characters"),
  location: z.string().min(3, "Location is required"),
  profilePicture: z.string().optional(),
});

const insertReportSchema = z.object({
  title: z.string().min(10, "Title must be at least 10 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  location: z.string().min(3, "Location is required"),
  violationType: z.string().min(1, "Violation type is required"),
  mediaUrl: z.string().optional(),
  mediaType: z.string().optional(),
});

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'video/webm'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only images and videos are allowed.'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Ensure uploads directory exists
  const uploadsDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  // Serve uploaded files
  app.use('/uploads', express.static(uploadsDir));

  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      res.json({ user: { ...user, password: undefined } });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json({ user: { ...user, password: undefined } });
    } catch (error) {
      res.status(400).json({ message: "Registration failed" });
    }
  });

  // User routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ ...user, password: undefined });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/users/:id/stats", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const reports = await storage.getReportsByUserId(id);
      const verifiedReports = reports.filter(r => r.status === "verified");
      const pendingReports = reports.filter(r => r.status === "pending");
      
      res.json({
        totalReports: reports.length,
        verifiedReports: verifiedReports.length,
        pendingReports: pendingReports.length,
        points: user.points,
        rank: user.rank,
        level: user.level,
        pointsToNextLevel: user.pointsToNextLevel,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  app.get("/api/leaderboard", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const topUsers = await storage.getTopUsers(limit);
      
      // Add mock data for top contributors with Indian names and profile pictures
      const enhancedUsers = topUsers.map((user, index) => {
        if (index === 0 && user.id !== 1) {
          return {
            ...user,
            name: "Priya Sharma",
            location: "Mumbai Police Station",
            profilePicture: "https://images.unsplash.com/photo-1494790108755-2616b612b786?auto=format&fit=crop&w=100&h=100",
            points: 2847,
            reportCount: 156,
          };
        } else if (index === 1 && user.id !== 1) {
          return {
            ...user,
            name: "Arjun Patel",
            location: "Delhi Traffic Police",
            profilePicture: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=100&h=100",
            points: 2156,
            reportCount: 143,
          };
        } else if (index === 2 && user.id !== 1) {
          return {
            ...user,
            name: "Kavita Singh",
            location: "Bangalore Traffic",
            profilePicture: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=100&h=100",
            points: 1923,
            reportCount: 128,
          };
        }
        return {
          ...user,
          reportCount: Math.floor(user.points / 20), // Approximate report count
        };
      });
      
      res.json(enhancedUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  // Profile picture upload route
  app.post("/api/users/profile-picture", upload.single('profilePicture'), async (req, res) => {
    try {
      const userId = parseInt(req.body.userId);
      if (!userId || !req.file) {
        return res.status(400).json({ message: "User ID and profile picture are required" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Generate file URL
      const fileExtension = path.extname(req.file.originalname);
      const fileName = `profile_${userId}_${Date.now()}${fileExtension}`;
      const newPath = path.join(process.cwd(), 'uploads', fileName);
      
      // Move file to permanent location
      fs.renameSync(req.file.path, newPath);
      const profilePictureUrl = `/uploads/${fileName}`;

      // Update user profile picture in database
      const updatedUser = await storage.updateUser(userId, { profilePicture: profilePictureUrl });
      
      res.json({ 
        message: "Profile picture updated successfully",
        profilePicture: profilePictureUrl,
        user: { ...updatedUser, password: undefined }
      });
    } catch (error) {
      console.error("Error uploading profile picture:", error);
      res.status(500).json({ message: "Failed to upload profile picture" });
    }
  });

  // Profile update route
  app.put("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { name, location } = req.body;

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const updatedUser = await storage.updateUser(userId, { name, location });
      
      res.json({ 
        message: "Profile updated successfully",
        user: { ...updatedUser, password: undefined }
      });
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Report routes
  app.post("/api/reports", upload.single('media'), async (req, res) => {
    try {
      const reportData = insertReportSchema.parse(req.body);
      const userId = parseInt(req.body.userId);
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      // Handle file upload
      let mediaUrl = "";
      let mediaType = "";
      
      if (req.file) {
        mediaUrl = `/uploads/${req.file.filename}`;
        mediaType = req.file.mimetype.startsWith('image/') ? 'image' : 'video';
      }
      
      const report = await storage.createReport({
        ...reportData,
        userId,
        mediaUrl,
        mediaType,
      });
      
      res.status(201).json(report);
    } catch (error) {
      res.status(400).json({ message: "Failed to create report" });
    }
  });

  app.get("/api/reports/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const reports = await storage.getReportsByUserId(userId);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.get("/api/reports", async (req, res) => {
    try {
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.patch("/api/reports/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, points } = req.body;
      
      const report = await storage.updateReportStatus(id, status, points);
      
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to update report status" });
    }
  });

  // Reward routes
  app.get("/api/rewards", async (req, res) => {
    try {
      const rewards = await storage.getAllRewards();
      res.json(rewards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rewards" });
    }
  });

  app.post("/api/rewards/redeem", async (req, res) => {
    try {
      const { processRewardRedemption } = await import("./reward-redemption");
      const result = await processRewardRedemption(req.body);
      res.json(result);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to redeem reward" });
    }
  });

  // Activity routes
  app.get("/api/activities/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = parseInt(req.query.limit as string) || 10;
      const activities = await storage.getActivitiesByUserId(userId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
