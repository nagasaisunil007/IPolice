import { FirebaseStorage } from './firebase-storage';

// Export only Firebase storage instance
export const storage = new FirebaseStorage();