import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

// Clean database URL to ensure it points to root
const cleanDatabaseUrl = (url: string) => {
  if (!url) return url;
  // Remove any path after .firebaseio.com or .europe-west1.firebasedatabase.app
  const match = url.match(/(https:\/\/.*?(?:firebaseio\.com|firebasedatabase\.app))/);
  return match ? match[1] : url;
};

const databaseUrl = process.env.FIREBASE_DATABASE_URL || import.meta.env.VITE_FIREBASE_DATABASE_URL;

const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY || import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN || import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  databaseURL: cleanDatabaseUrl(databaseUrl),
  projectId: process.env.FIREBASE_PROJECT_ID || import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET || import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID || import.meta.env.VITE_FIREBASE_APP_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Realtime Database and get a reference to the service
export const database = getDatabase(app);
export default app;