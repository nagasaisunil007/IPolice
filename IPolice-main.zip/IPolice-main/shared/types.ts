// Firebase-compatible type definitions for the iPolice app

export interface User {
  id: number;
  username: string;
  password: string;
  name: string;
  location: string;
  profilePicture?: string;
  points: number;
  rank: number;
  level: number;
  pointsToNextLevel: number;
}

export interface Report {
  id: number;
  userId: number;
  title: string;
  description: string;
  location: string;
  violationType: string;
  status: string; // pending, verified, rejected
  mediaUrl?: string;
  mediaType?: string; // image, video
  points: number;
  createdAt: string;
  verifiedAt?: string;
}

export interface Reward {
  id: number;
  name: string;
  description: string;
  pointsCost: number;
  imageUrl: string;
  category: string;
  available: boolean;
}

export interface Activity {
  id: number;
  userId: number;
  type: string; // report_verified, report_submitted, rank_achieved, reward_claimed
  title: string;
  description: string;
  points: number;
  metadata?: string; // JSON string for additional data
  createdAt: string;
}

// Insert types (for creating new records)
export type InsertUser = Omit<User, 'id' | 'points' | 'rank' | 'level' | 'pointsToNextLevel'> & {
  points?: number;
  rank?: number;
  level?: number;
  pointsToNextLevel?: number;
};

export type InsertReport = Omit<Report, 'id' | 'points' | 'createdAt' | 'verifiedAt'> & {
  points?: number;
};

export type InsertReward = Omit<Reward, 'id'>;

export type InsertActivity = Omit<Activity, 'id' | 'createdAt'>;